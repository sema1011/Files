fft = True
bar_width = 10
bar_spacing = 5
fg_color = 0.0, 0.6, 1.0, 0.8

import math

def on_draw(audio_sample_array, cr, widget):
    cr.set_source_rgba(fg_color[0], fg_color[1], fg_color[2], fg_color[3])

    _w, _h = widget.get_width(), widget.get_height()
    _nbars = int(_w /(bar_width +bar_spacing))
    _nrows = int(_h /(bar_width +bar_spacing))
    l = len(audio_sample_array) /(_nbars -1)

    for i in range(0, len(audio_sample_array), l):
        rows = audio_sample_array[i+1] *_nrows
        r = rows *10.0 #!amplify
        if r <= _nrows: rows = r
        if r < 1: rows = 1
        bar = i /l
        for row in range(0, int(rows)):
            x, y = bar *(bar_width +bar_spacing), row *(bar_width +bar_spacing)
            print x, y
            cr.arc(bar_width +x, _h -bar_width -y,
                min(bar_width,bar_width) /2, 0, 2 *math.pi)
        cr.fill()
        cr.stroke()
