# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import dbus

from players import Player, Track

COVER, PLAYER, STATE, TIME, TRACK = range(5)
STARTED, PLAYING, PAUSED, STOPPED, CLOSED = range(5)

class Banshee(Player):

    __doc__ = 'Banshee music player plugin'

    DBUS_NAME       = 'org.bansheeproject.Banshee'
    DBUS_PLAYER     = '/org/bansheeproject/Banshee/PlayerEngine'
    DBUS_CONTROLLER = '/org/bansheeproject/Banshee/PlaybackController'

    capabilities = ('rating', 'time', 'seek', 'volume')

    _controller = None
    _player = None
    _signals = []
    _state = None

    def connect(self):
        if self._player:
            return True
        try:
            proxy = dbus.SessionBus().get_object(self.DBUS_NAME, self.DBUS_PLAYER)
            self._player = dbus.Interface(proxy,
            'org.bansheeproject.Banshee.PlayerEngine')

            proxy = dbus.SessionBus().get_object(self.DBUS_NAME,
                self.DBUS_CONTROLLER)
            self._controller = dbus.Interface(proxy,
                'org.bansheeproject.Banshee.PlaybackController')

            self._signals.append(self._player.connect_to_signal(
                'StateChanged', self.state_changed))
            self._signals.append(self._player.connect_to_signal(
                'EventChanged', self.event_changed))
            return True
        except:
            self._player = None
            return False

    def disconnect(self):
        for signal in self._signals:
            signal.remove()

        self._player = None
        self._controller = None
        self._signals = []
        self.connected = False

    def get_state(self, state=None):
        if not state:
            try: state = self._player.GetCurrentState()
            except: return CLOSED
        if state == 'idle' or state == 'stopped':
            return STOPPED
        elif state == 'playing':
            return PLAYING
        elif state == 'paused':
            return PAUSED

    def previous(self):
        if self.connected:
            self._controller.Previous(True)

    def play(self):
        if self.connected:
            self._player.TogglePlaying()

    def next(self):
        if self.connected:
            self._controller.Next(True)

    def get_track(self, data=None):
        if not data:
            data = self._player.GetCurrentTrack()

        try:    data['arturl'] = data['artwork-id']
        except: pass
        try:    data['url'] = data['URI']
        except: pass
        try:    data['title'] = data['name']
        except: pass

        return Track(data)

    def get_position(self):
        try:
            return self._player.GetPosition() /1000
        except:
            return 0

    def set_position(self, time):
        self._player.SetPosition(dbus.UInt32(time *1000))

    def get_volume(self):
        try:
            return self._player.GetVolume()
        except:
            return 0

    def set_volume(self, volume):
        self._player.SetVolume(dbus.UInt16(volume))

    def set_rating(self, rating):
        if 0 <= rating and rating <= 5:
            self._player.SetRating(dbus.Byte(rating))

    def state_changed(self, message, *args):
        state = self.get_state(message)
        if state in (PLAYING, PAUSED):
            self._state = state
        elif self._state == PLAYING and state == STOPPED:
            return
        self.THREAD.update(STATE, state)

    def event_changed(self, message, *args):
        if message in ('startofstream', 'trackinfoupdated'):
            self.THREAD.update(TRACK, self.get_track())
