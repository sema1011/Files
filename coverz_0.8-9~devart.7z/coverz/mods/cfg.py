# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import os

from ConfigParser import SafeConfigParser

SRC_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
EXEC = os.path.basename(SRC_PATH)
HOME = os.path.expanduser('~')
USR_PATH = '/'.join((HOME, '.'+EXEC))
CONFIG = '/'.join((USR_PATH, '.cfg'))

class SafeParser(SafeConfigParser):

    _cfgs = []
    _mtime = 0

    def __init__(self):
        SafeConfigParser.__init__(self)
        self.load_default()

    def load_default(self):
        self.add_section('APP')
        self.set('APP', 'autoplug',  '1')
        self.set('APP', 'debug',     '0')
        self.set('APP', 'player',    'Soundz')
        self.set('APP', 'plugins',   'Lastfm,Musixmatch')
        self.set('APP', 'ontop',     '0')
        self.set('APP', 'stick',     '1')
        self.set('APP', 'position',  '10,10')

        self.add_section('MPD')
        self.set('MPD', 'host', 'localhost')
        self.set('MPD', 'port', '6600')
        self.set('MPD', 'password', '')
        self.set('MPD', 'path', HOME +'/Music')
        self.set('MPD', 'timeout', '4')
        self.set('MPD', 'fade', '0')

    def load(self):
        if os.path.exists(CONFIG):
            #self._mtime = os.path.getmtime(CONFIG)
            self.read(CONFIG)
            self._cfgs = self.items('APP')
        else:
            if not os.path.exists(USR_PATH):
                os.mkdir(USR_PATH)
            self.save()

    def save(self):
        #if os.path.exists(CONFIG):
        #    _mtime = os.path.getmtime(CONFIG)
        #else: _mtime = 0
        #if _mtime == self._mtime:
        if self._cfgs != self.items('APP'):
            self._cfgs = self.items('APP')
            with open(CONFIG, 'w') as f:
                self.write(f)

    def edit(self):
        import subprocess
        subprocess.Popen(['xdg-open', CONFIG])

def listdir(dir):
    return sorted([f[:-3] for f in os.listdir(os.path.join(SRC_PATH, dir)) \
        if not f.startswith('_') and f.endswith('.py')])

def install(tit):
    import gtk
    bts = gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK
    dlg = gtk.FileChooserDialog(tit, None, gtk.FILE_CHOOSER_ACTION_OPEN, bts)
    dlg.set_current_folder(HOME)
    dlg.set_select_multiple(False)

    f = gtk.FileFilter()
    f.set_name('7z | zip')
    for p in ('*.7z','*.zip'):
        f.add_pattern(p)
    dlg.add_filter(f)

    _file = None
    if dlg.run() == gtk.RESPONSE_OK:
        _file = dlg.get_filename()
        if _file: unzip(_file)
    dlg.destroy()

def unzip(file):
    import subprocess
    unzip = subprocess.Popen(['7z','e',file,'-o'+USR_PATH,'-y'])#,
    #    stderr=subprocess.PIPE)
    #while unzip.poll() != None:
    #    print unzip.stderr.read()
