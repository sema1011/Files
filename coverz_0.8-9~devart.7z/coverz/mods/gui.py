# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import cairo
import gtk
gtk.gdk.threads_init()

from mods import cfg
from mods import configs
from mods import log

class Window(gtk.Window):

    _pt = False
    _px = 0
    _py = 0

    _ontop = False
    _stick = False
    _menu  = None

    def __init__(self, thread, skin):
        super(Window, self).__init__()
        self.THREAD = thread

        self.set_app_paintable(True)
        self.set_colormap(self.get_screen().get_rgba_colormap())
        self.set_decorated(False)
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_UTILITY)
        #self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_NOTIFICATION)#_DOCK)

        self.set_title('Coverz')#!
        self.set_icon_from_file(cfg.SRC_PATH +'/skins/coverz.png')

        self.set_property('accept-focus', False)#???
        #self.set_ontop(False)
        #self.set_stick(True)
        self.set_ontop(configs.getboolean('APP', 'ontop'))
        self.set_stick(configs.getboolean('APP', 'stick'))

        #!add transparent background
        self.connect('expose-event', self.expose_event)

        self.add_events(gtk.gdk.BUTTON_PRESS_MASK)
        self.add_events(gtk.gdk.BUTTON_RELEASE_MASK)
        self.add_events(gtk.gdk.POINTER_MOTION_MASK)
        #self.add_events(gtk.gdk.ENTER_NOTIFY_MASK)

        self.connect('button-press-event', self.show_menu)
        self.connect('button-press-event', self.button_press)
        self.connect('button-release-event', self.button_release)
        self.connect('motion-notify-event', self.motion_notify)
        #self.connect('enter-notify-event', self.enter_notify)
        #self.connect('leave-notify-event', self.leave_notify)
        #if configs.getboolean('APP', 'trayicon'):
        #    self._status_icon = gtk.status_icon_new_from_file(
        #        cfg.SRC_PATH +'/tray.png')
        #    self._status_icon.connect('button-press-event', self.show_menu)
        #log.info('Loading skin...')
        self.set_skin(skin)

    def button_press(self, widget, event):
        if event.button == 1 and not self._stick:
            self._pt = True
            self._px, self._py = self.get_position()
            self._px = event.x_root - self._px
            self._py = event.y_root - self._py
        return False

    def button_release(self, widget, event):
        if event.button == 1:
            self._pt = False
            self.save_configs()
        return False

    def motion_notify(self, widget, event):
        if self._pt:
            self.move(int(event.x_root-self._px), int(event.y_root-self._py))
        return False

    def enter_notify(self, widget, event):
        return False

    def leave_notify(self, widget, event):
        return False

    def expose_event(self, widget, event):
        cr = self.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        cr.clip()
        cr.set_operator(cairo.OPERATOR_CLEAR)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        return False

    def show_menu(self, widget, event):
        if event.button == 2:
            self.THREAD.update_lyric()
        if event.button != 3:
            return
        if self._menu == None:
            self._menu = gtk.Menu()

            item = gtk.CheckMenuItem('Stick desktop')
            item.connect ('activate', lambda w: self.set_stick(w.active))
            self._menu.__stick = item
            self._menu.append(item)

            install = gtk.ImageMenuItem('Install skin...')
            install.connect ('activate',
                lambda w: cfg.install('Install skin...'))
            install.set_image(gtk.image_new_from_stock(
                gtk.STOCK_NEW, gtk.ICON_SIZE_MENU))
            self._menu.append(install)

            edit = gtk.ImageMenuItem('Edit config')
            edit.set_image(gtk.image_new_from_stock(
                gtk.STOCK_EDIT, gtk.ICON_SIZE_MENU))
            edit.connect ('activate',
                lambda w: configs.edit())
            self._menu.append(edit)

            reinit = gtk.ImageMenuItem('Reload')
            reinit.set_image(gtk.image_new_from_stock(
                gtk.STOCK_REFRESH, gtk.ICON_SIZE_MENU))
            reinit.connect ('activate',
                lambda w: self.quit(True))
            self._menu.append(reinit)

            self._menu.append(gtk.SeparatorMenuItem())
            quit = gtk.ImageMenuItem(gtk.STOCK_QUIT)
            quit.connect ('activate',
                lambda w: self.quit(False))
            self._menu.append(quit)
            self._menu.show_all()

        self._menu.__stick.set_active(self._stick)
        self._menu.popup(None, None, None, event.button, event.time)

    def set_ontop(self, ontop):
        self.set_keep_above(ontop)
        self.set_keep_below(not ontop)
        self._ontop = ontop

    def set_stick(self, stick):
        self.stick() if stick else self.unstick()
        self.set_skip_taskbar_hint(stick)
        self.set_skip_pager_hint(stick)           
        self._stick = stick

    def set_skin(self, skin):
        self.fixed = gtk.Fixed()
        for w,n in skin.widgets:
            self.fixed.put(w, w.get_x(), w.get_y())

        self.add(self.fixed)
        self.set_size_request(*skin.size)
        x, y = configs.get('APP', 'position').split(',')
        self.move(int(x), int(y))
        self.show_all()

        gtk.main()

    def save_configs(self):
        configs.set('APP', 'position', '%d,%d' % self.window.get_position())
        configs.set('APP', 'stick', str(int(self._stick)))
        configs.save()

    def quit(self, restart=False):
        self.save_configs()

        gtk.main_quit()
        if restart:
            import subprocess
            subprocess.Popen(['coverz'])
