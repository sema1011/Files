# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

from xml.dom import minidom

from mods.widgets.button import Button, StateButton
from mods.widgets.image import Image
from mods.widgets.rating import HRating, VRating
from mods.widgets.seekbar import HSlider, VSlider
from mods.widgets.text import Text
from mods.widgets import Rectangle, Reflection

COVER, PLAYER, STATE, TIME, TRACK = range(5)
STARTED, PLAYING, PAUSED, STOPPED, CLOSED = range(5)

class Skin:

    servers = []
    widgets = []

    def __init__(self, thread):
        self.THREAD = thread

    def get_skin_xml(self, path):
        dom = minidom.parse(path +'/skin.xml')
        skin = dom.getElementsByTagName('skin')[0]

        self.src = path
        self.size = int(skin.getAttribute('width')), \
            int(skin.getAttribute('height'))

        for domitem in skin.childNodes:
            if domitem.nodeType == 1:
                item = domitem.nodeName
                if item == 'cover':
                    self.add_image(domitem, True)
                elif item == 'image':
                    self.add_image(domitem)
                elif item in ('text','artist','album','title','genre'):
                    self.add_text(domitem, item)
                elif item in ('time','length','number','year'):
                    self.add_text(domitem, item)
                elif item in ('prev','next','play'):
                    self.add_button(domitem)
                elif item == 'seekbar':
                    self.add_seekbar(domitem)
                elif item == 'rating':
                    self.add_rating(domitem)
                elif item == 'widget':
                    self.add_widget(domitem)

        _widgets = [w for w,n in self.widgets if n == 1]
        ob = self.THREAD.attach(STATE, self.get_visible, _widgets)
        self.servers.append(ob)

    def get_item_size(self, domitem):
        x, y = domitem.getAttribute('x'), domitem.getAttribute('y')
        w, h = domitem.getAttribute('width'), domitem.getAttribute('height')
        print '%s: %s,%s' % (domitem.nodeName,w,h)

        try: return Rectangle(int(x), int(y), int(w), int(h))
        except: return Rectangle(0, 0, int(w), int(h))

    def get_rgba_color(self, rgb, a=1.0):
        rgba = []            
        for c in (rgb[1:3], rgb[3:5], rgb[5:7]):
            rgba.append(int(c, 16) /255.0)
        rgba.append(a)
        return rgba

    def get_visible(self, state, widgets):
        for w in widgets:
            w.set_visible(state == PLAYING or state == PAUSED)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def add_button(self, domitem):
        item = domitem.nodeName
        if item == 'play':
            data = {}
            for state in ('normal','hover','pressed'):
                src = domitem.getAttribute(
                    state.replace('normal','src'))
                data[state] = self.src +'/' +src if src else None
            button = StateButton(self.get_item_size(domitem))
            button.add_state(PAUSED, **data)

            data = {}
            for state in ('normal','hover','pressed'):
                src = domitem.getAttribute(
                    state.replace('normal','src') +'pause')
                data[state] = self.src +'/' +src if src else None
            button.add_state(PLAYING, **data)

            ob = self.THREAD.attach(STATE, self.change_state, button)
            self.servers.append(ob)
        else:
            data = {}
            for state in ('normal','hover','pressed'):
                src = domitem.getAttribute(
                    state.replace('normal','src'))
                data[state] = self.src +'/' +src if src else None
            button = Button(self.get_item_size(domitem), **data)

        reflect = domitem.getAttribute('reflect')
        if reflect: button.set_reflect(Reflection(reflect))

        if item == 'play':
            button.connect('clicked', lambda w: self.THREAD.player.play())
        elif item == 'prev':
            button.connect('clicked', lambda w: self.THREAD.player.previous())
        elif item == 'next':
            button.connect('clicked', lambda w: self.THREAD.player.next())

        self.widgets.append((button, 1))

    def change_state(self, state, button):
        if state == PLAYING:
            button.set_state(state)
        elif state in (PAUSED, STOPPED, CLOSED):
            button.set_state(PAUSED)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def add_image(self, domitem, cover=False):           
        src = domitem.getAttribute('src')
        if src: src = self.src +'/' +src
        elif cover: src = None

        image = Image(self.get_item_size(domitem))

        clip = domitem.getAttribute('clip')
        if clip: image.set_clip(clip.split(','))

        mask = domitem.getAttribute('mask')
        if mask: image.set_mask(self.src +'/' +mask)

        reflect = domitem.getAttribute('reflect')
        if reflect: image.set_reflect(Reflection(reflect))

        opacity = domitem.getAttribute('opacity')
        if opacity: image.set_opacity(float(opacity)/100)

        rotate = domitem.getAttribute('rotate')
        if rotate and cover:
            import math
            rotate = int(rotate)
            if rotate <= 180:
                radians = math.pi /180 *rotate
            elif rotate <= 360:
                radians = -(math.pi /180 *(rotate -180))
            image.set_rotate((radians))

        radius = domitem.getAttribute('round')
        if radius: image.set_round(int(radius))

        image.set_image(src)

        if cover:
            self.THREAD.cover = src
            ob = self.THREAD.attach(COVER, lambda p: image.set_image(p))
            self.servers.append(ob)

        self.widgets.append((image, 0))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def add_rating(self, domitem):
        star = self.src +'/' +domitem.getAttribute('src')
        starred = self.src +'/' +domitem.getAttribute('starred')

        size = self.get_item_size(domitem)
        spacing = domitem.getAttribute('spacing')

        if domitem.getAttribute('rotate'):
            rating = VRating(star, starred, size, int(spacing) if spacing else 0)
        else:
            rating = HRating(star, starred, size, int(spacing) if spacing else 0)

        rating.connect('set_rating', self.update_rating)
        rating.set_rating(self.THREAD.track.rating)

        ob = self.THREAD.attach(TRACK, self.change_rating, rating)
        self.servers.append(ob)
        ob = self.THREAD.attach(PLAYER, True, rating)
        self.servers.append(ob)
        self.widgets.append((rating, 1))

    def change_rating(self, track, rating):
        rating.set_rating(track.rating)

    def update_rating(self, widget, rating):
        if 'rating' in self.THREAD.player.capabilities:
            self.THREAD.player.set_rating(rating)
        else:
            widget.set_rating(rating)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def add_seekbar(self, domitem):
        src = domitem.getAttribute('src')
        if src: src = self.src +'/' +src
        filled = domitem.getAttribute('filled')
        if filled: filled = self.src +'/' +filled

        size = self.get_item_size(domitem)
        if size.width > size.height:
            seekbar = HSlider(src, filled, size)
        else:
            seekbar = VSlider(src, filled, size)

        for item in domitem.childNodes:
            if item.nodeType == 1 and item.nodeName == 'thumb':
                thumb = self.src +'/' +item.getAttribute('src')
                seekbar.set_thumb(thumb, self.get_item_size(item))
                break        

        seekbar.set_max(self.THREAD.track.length)
        seekbar.set_value(self.THREAD.time)
        seekbar.connect('value-changed',
            lambda w, v: self.THREAD.player.set_position(v))

        ob = self.THREAD.attach(TIME,
            lambda t: seekbar.set_value(t))
        self.servers.append(ob)
        ob = self.THREAD.attach(TRACK,
            lambda t: seekbar.set_max(t.length))
        self.servers.append(ob)
        self.widgets.append((seekbar, 1))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def add_text(self, domitem, item):
        text = Text(self.get_item_size(domitem))

        text.set_font(domitem.getAttribute('font'))
        color = domitem.getAttribute('color')
        opacity = domitem.getAttribute('opacity')
        opacity = float(opacity)/100 if opacity else 1
        if color:
            text.set_color(self.get_rgba_color(color, opacity))
        elif opacity:
            text.set_color((1, 1, 1, opacity))

        shadow_color = domitem.getAttribute('shadow')
        if shadow_color:
            text.set_shadow_color(self.get_rgba_color(shadow_color, opacity))
        shadow_offset = domitem.getAttribute('shadowoffset')
        if shadow_offset:
            shadow_x, shadow_y = shadow_offset.split(',')
            text.set_shadow_offset(int(shadow_x), int(shadow_y))

        align = domitem.getAttribute('align')
        if align: text.set_align(align)
        valign = domitem.getAttribute('valign')
        if valign: text.set_valign(valign)

        ellipsize = domitem.getAttribute('ellipsize')
        if ellipsize == 'char':
            text.set_ellipsize(Text.ELLIPSIZE_CHAR)
            try: text.set_maxchars(int(domitem.getAttribute('maxchars')))
            except: pass
        elif ellipsize == 'word':
            text.set_ellipsize(Text.ELLIPSIZE_WORD)
        elif ellipsize == 'wrap':
            text.set_ellipsize(Text.ELLIPSIZE_WORD)
            text.set_wrap(True)
        else:
            text.set_scroll(ellipsize == 'scroll')

        reflect = domitem.getAttribute('reflect')
        if reflect: text.set_reflect(Reflection(reflect))

        if item == 'time':
            self.change_time(self.THREAD.time, text)
            ob = self.THREAD.attach(TIME, self.change_time, text)            
        else:
            fmt = domitem.getAttribute('format')
            self.change_text(self.THREAD.track, text, item, fmt)
            ob = self.THREAD.attach(TRACK, self.change_text, text, item, fmt)
        self.servers.append(ob)
        self.widgets.append((text, 1))

    def change_text(self, track, text, attr, fmt=''):
        if attr == 'length':
            text.set_text(track.sec2str(track.length))
        elif attr == 'text':
            text.set_text(track.fmt2str(fmt))
        else:
            text.set_text(str(getattr(track, attr)))

    def change_time(self, time, text):
        text.set_time(time)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def add_widget(self, domitem):
        import sys
        sys.path.append(self.src)# +'/.libs')
        #sys.path[0:0] = self.src # puts dir at the start of your path
        import widget

        attrs = {}
        attrs['size'] = self.get_item_size(domitem)
        for k, v in domitem.attributes.items():
            if 'color' in k:
                color, opacity = v.split(',')
                v = str(self.get_rgba_color(color, float(opacity) /100))
            try: attrs[k] = eval(v)
            except: attrs[k] = str(v)

        widget = widget.Skin(attrs)

        ob = self.THREAD.attach(STATE, widget.change_state)
        self.servers.append(ob)

        self.widgets.append((widget, 0))
