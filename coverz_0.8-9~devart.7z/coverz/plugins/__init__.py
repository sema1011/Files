# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

import os
import socket
import urllib2

from mods import cfg

TMP_PATH = cfg.USR_PATH +'/.tmp'
if not os.path.exists(TMP_PATH):
    os.mkdir(TMP_PATH)

COVER, PLAYER, STATE, TIME, TRACK = range(5)

class Plugin(object):

    def __init__(self, thread):
        super(Plugin, self).__init__()
        self.THREAD = thread

    def get(self, track):
        raise NotImplementedError

    def abs_hash(self, string):
        " Return the absolute hash of a string """
        return abs(hash(string.lower()))

    def encode(self, string):
        """ Return the encoded url """
        string = string.encode('utf-8')
        mask  = '%%%X' *len(string)
        bytes = tuple([ord(c) for c in string])
        return mask % bytes

    def read(self, string, timeout=7):
        """ Read the data by the given url """
        socket.setdefaulttimeout(timeout)
        return urllib2.urlopen(string).read()
        #user_agent = 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008072820 Firefox/3.0.1'
        #request = urllib2.Request(string, headers={'User-Agent': user_agent})
        #return urllib2.urlopen(request).read()
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class CoverPlugin(Plugin):

    def get(self, track):
        path = self.find(track)
        self.update(path)

    def fpath(self, track):
        return os.path.join(TMP_PATH, '%d.jpg' % 
            self.abs_hash(track.artist +track.album))

    def find(self, track):
        path = self.fpath(track)
        if not os.path.exists(path) and track.path.startswith('/'):
            path = None
            #!find covers into track directory
            dir_name = os.path.dirname(track.path)
            for f in os.listdir(dir_name):
                if f[f.rfind('.'):] in ('.jpg','.jpeg','.png','.gif',):
                    path = os.path.join(dir_name, f)
                    break
        return path

    def save(self, track, data):
        #!save image data to jpg file
        path = self.fpath(track)
        pbl = gtk.gdk.PixbufLoader()
        #pbl.set_size(126, 126)
        pbl.write(data)
        pbuf = pbl.get_pixbuf()
        #pbuf.scale_simple(126, 126, gtk.gdk.INTERP_BILINEAR)
        pbl.close()
        pbuf.save(path, 'jpeg', {'quality':'100'})
        return path

    def update(self, path):
        self.THREAD.update(COVER, path if path else self.THREAD.cover)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class LyricPlugin(Plugin):

    widget = None

    def _set_widget(self, text, title):
        if self.widget == None:          
            from mods.widgets.dialog import TextDialog
            self.widget = TextDialog()
            self.widget.show_all()

        self.widget.set_text(text if text else 'Searching...')
        self.widget.set_title(title)
        self.widget.present()

    def get(self, track):
        text = self.find(track)
        self.update(text, track.title)

    def fpath(self, track):
        return os.path.join(TMP_PATH, '%d.txt' %
            self.abs_hash(track.artist +track.title))

    def find(self, track):
        path = self.fpath(track)
        if os.path.exists(path):
            with open(path, 'r') as f:
                text = f.read()
            return text
        return None

    def save(self, track, text):
        path = self.fpath(track)
        with open(path, 'w') as f:
            f.write(str(text))
        return path

    def update(self, text, title):
        gtk.gdk.threads_enter()
        try:
            self._set_widget(text, title)
        finally:
            gtk.gdk.threads_leave()

    def unescape(self, text):
        """ Removes HTML or XML character references and entities from a text.
            from Fredrik Lundh http://effbot.org/zone/re-sub.htm#unescape-html
            @return a plain text by the given HTML (or XML) source.
        """
        import htmlentitydefs
        import re

        def fixup(m):
            text = m.group(0)
            if text[:2] == "&#":
                try:
                    if text[:3] == "&#x":
                        return unichr(int(text[3:-1], 16))
                    else:
                        return unichr(int(text[2:-1]))
                except ValueError:
                    pass
            else:
                try:
                    text = unichr(htmlentitydefs.name2codepoint[text[1:-1]])
                except KeyError:
                    pass
            return text
        return re.sub("&#?\w+;", fixup, text)
