# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

from mods import log
from plugins import LyricPlugin

class Musixmatch(LyricPlugin):

    api_key = 'ee8bbc6dc0e2fe951912a710640053ce'
    api_url = 'http://api.musixmatch.com/ws/1.1'
    query = '%s/matcher.lyrics.get?q_track=%s&q_artist=%s&apikey=%s&format=xml'

    def get(self, track):
        """ Download lyrics from musiXmatch.com """
        text = self.find(track)
        self.update(text, track.title)
        if text == None:
            try:
                text = self._get_lyric(track)
                if not '</' in text:
                    path = self.save(track, text)
                self.update(text, track.title)
            except:
                log.error("URLError")

    def _get_lyric(self, track):
        artist, title = self.encode(track.artist), self.encode(track.title)

        url = self.query % (self.api_url, title, artist, self.api_key)
        xml = self.read(url)
        sst = '<lyrics_body>'
        start = xml.find(sst)
        end = xml.find('*******', start)#'</lyrics_body>'
        text = xml[start+len(sst):end]

        return text.replace('&#13;', '')
