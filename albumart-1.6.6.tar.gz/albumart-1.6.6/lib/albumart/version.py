# -*- coding: iso-8859-1 -*-
__program__ = "Album Cover Art Downloader"
__author__ = "Sami Ky�stil� (sami.kyostila@gmail.com)"
__url__ = "http://unrealvoodoo.org/hiteck/projects/albumart"
__version__ = "1.6.6"
__copyright__ = "Copyright (c) 2003-2008 by Sami Ky�stil�"
__license__ = "GPL"
