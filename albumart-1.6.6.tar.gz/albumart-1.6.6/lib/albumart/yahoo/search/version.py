#
# Define some meta data for this release/version.
#
version = "1.3"
authorName = "Leif Hedstrom"
authorMail = "leif@ogre.com"
maintainerName = "Leif Hedstrom"
maintainerMail = "leif@ogre.com"
credits = """- The entire Yahoo search team, of course.
"""

author = "%s <%s>" % (authorName, authorMail)



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
