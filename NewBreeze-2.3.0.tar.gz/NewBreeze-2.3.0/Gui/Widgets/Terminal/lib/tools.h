#ifndef TOOLS_H
#define TOOLS_H

#include <QString>

QString get_kb_layout_dir();
QString get_color_schemes_dir();


#endif
