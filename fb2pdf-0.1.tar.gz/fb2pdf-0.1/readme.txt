To compile just type make.

To change fonts, sizes etc edit fb2pdf.c source code.
Note that fb2pdf.c has the font name Octava hardcoded
so you may want to edit it to change to your desired font.

To run use fb2pdf.sh shell wrapper:

fb2pdf.sh example.fb2 example.pdf


