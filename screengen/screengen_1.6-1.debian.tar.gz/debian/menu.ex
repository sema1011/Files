?package(screengen):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="screengen" command="/usr/bin/screengen"
