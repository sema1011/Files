<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU">
<context>
    <name>QObject</name>
    <message>
        <location filename="src/main.cpp" line="338"/>
        <source>Mb</source>
        <translation>Мб</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="358"/>
        <source>File name:</source>
        <translation>Имя файла:</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="360"/>
        <source>Size:</source>
        <translation>Размер:</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="362"/>
        <source>General info:</source>
        <translation>Информация:</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="364"/>
        <source>Video:</source>
        <translation>Видео:</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="366"/>
        <source>Audio:</source>
        <translation>Аудио:</translation>
    </message>
    <message>
        <location filename="src/qffmpeg.cpp" line="15"/>
        <location filename="src/qffmpeg.cpp" line="100"/>
        <source>kb/s</source>
        <translation>кбит/с</translation>
    </message>
    <message>
        <location filename="src/qffmpeg.cpp" line="15"/>
        <source>Streams:</source>
        <translation>Потоков:</translation>
    </message>
    <message>
        <location filename="src/qffmpeg.cpp" line="15"/>
        <source>Full bitrate:</source>
        <translation>Общий битрейт:</translation>
    </message>
    <message>
        <location filename="src/qffmpeg.cpp" line="92"/>
        <source>fps</source>
        <translation>кадров/с</translation>
    </message>
    <message>
        <location filename="src/qffmpeg.cpp" line="101"/>
        <source>kHz</source>
        <translation>кГц</translation>
    </message>
    <message>
        <location filename="src/qffmpeg.cpp" line="103"/>
        <source>Not present</source>
        <translation>Отсутствует</translation>
    </message>
</context>
</TS>
