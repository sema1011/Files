#ifndef SINGLETONDOWNLOADER_H
#define SINGLETONDOWNLOADER_H
#include<QString>
#include<QWidget>
#include <QEventLoop>
#include <QFile>
#include <QHttp>
#include <QNetworkAccessManager>
#include <QNetworkProxy>
#include <QUrl>
class SingletonDownloader :public QNetworkAccessManager
{
    Q_OBJECT

public:
    static SingletonDownloader* getInstance();
    bool syncGet(QString url, QByteArray *byteArray);
    void proxySet (QString proxyName, unsigned int port);
    void proxyRemove ();

protected slots:
    virtual void finished(QNetworkReply* reply);

private:
    SingletonDownloader();
    QUrl redirectUrl(const QUrl& possibleRedirectUrl, const QUrl& oldRedirectUrl) const;

    static SingletonDownloader*  _instance;
    QNetworkProxy proxy;
    /// event loop used to block until request finished
    QEventLoop loop;
    QByteArray respData;
    QUrl _urlRedirectedTo;
};


#endif // SINGLETONDOWNLOADER_H
