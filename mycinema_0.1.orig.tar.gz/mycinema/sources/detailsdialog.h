#ifndef DETAILSDIALOG_H
#define DETAILSDIALOG_H

#include <QDialog>
#include <QTextEdit>
#include "db.h"
#include "tmdbscraper.h"
#include "filmupscraper.h"
#include "scraperinterface.h"
#include <QTreeView>
#include "updatedialog.h"
#include "storedialog.h"
#include "movie.h"
namespace Ui {
    class DetailsDialog;
}

class DetailsDialog : public QDialog {
    Q_OBJECT
public:
    DetailsDialog(QWidget *parent , Db* movieDb, QTableView * treeView);
    ~DetailsDialog();

protected:
    void changeEvent(QEvent *e);
    void closeEvent ( QCloseEvent * e );

public slots:
    void setInfoOnScreen(Movie movie);
    void on_thumbsButton_clicked();
    void popupThumbs(QList <QPixmap> thumbsList);


private slots:    
    void on_storeAsNewButton_clicked();
    void on_updateButton_clicked();
    void updateMovie(QMap< QString, bool > updateFields, QString PKey);
    void insertMovie(QString code, QString name, QString res, QString format, QString location, QString category);

signals:
    void deleteMe(DetailsDialog * details);
    void updateMovie(QMap< QString, bool > updateFields, QString pKey, Movie movieup);
    void insertMovie(Movie movie);
    void downloadThumbs();


private:
    storeDialog* stDialog;
    QImage image;
    updateDialog* upDialog;
    Ui::DetailsDialog *ui;
    QList<QLabel*> frames;
    Movie movie;
    Db* movieDb;
    QTableView * treeView;

};

#endif // DETAILSDIALOG_H
