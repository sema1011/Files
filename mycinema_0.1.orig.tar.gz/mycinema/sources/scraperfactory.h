#ifndef SCRAPERFACTORY_H
#define SCRAPERFACTORY_H
#include<QString>
#include<QWidget>
#include "scraperinterface.h"
#include "filmupscraper.h"
#include "tmdbscraper.h"

namespace Ui {
    class ScraperFactory;
}

class ScraperFactory : public QObject {
    Q_OBJECT
    public:
        ScraperFactory();
        static MovieScraper* getInstance();
    public slots:
        static void setScraper(QString name);

    private:
       static QString scraper;

};

#endif // SCRAPERFACTORY_H
