#include "tmdbscraper.h"
#include <iostream>
#include <QFile>
#include <QList>
#include <QVariant>
#include <QTextStream>
#include "path.h"
#include "singletondownloader.h"
#include "loadingdialog.h"
#include <QBuffer>

TmdbScraper::TmdbScraper(){
    downloader = SingletonDownloader::getInstance();
    apiKey="acc9b5bcf1fc97e703a789488960e0cb";
    hostName= "http://api.themoviedb.org";
    posterHostName= "http://images.themoviedb.org";
    searchPath = "/2.1/Movie.search/en/xml/"+apiKey+"/";
    infoPath="/2.1/Movie.getInfo/en/xml/"+apiKey+"/";
    ID="TMDB";
    lastError="";
}

//http://api.themoviedb.org/2.1/Movie.getInfo/en/xml/acc9b5bcf1fc97e703a789488960e0cb/238
//http://api.themoviedb.org/2.1/Movie.search/en/xml/acc9b5bcf1fc97e703a789488960e0cb/the%20godfather
bool TmdbScraper::search(QString name){
    searchResp.clear();
    if (!downloader->syncGet(hostName+searchPath+nameReplace(name),&searchResp)) {
        lastError="cannot retrieve api search response";
        return false;
    }else{
        return parseSearchResult();
    }
}
QList<QPixmap> TmdbScraper::getThumbs(){
    return this->thumbsList;
}

bool TmdbScraper::downloadThumbs(){
    thumbsList.clear();
    LoadingDialog * dialog = new LoadingDialog();
    dialog->setValues(0,thumbsUrl.length(),0);
    dialog->showIt();
    for(int i = 0; i< this->thumbsUrl.length(); i++){
        QByteArray bytes;
        downloader->syncGet(thumbsUrl.at(i),&bytes);
        QImage image;
        image.loadFromData(bytes);
        if (image.width() > 195 || image.height()>305 )image = image.scaled(195,305,Qt::KeepAspectRatio,Qt::SmoothTransformation);
        this->thumbsList.append(QPixmap::fromImage(image));
        dialog->nextStep();
    }
    dialog->close();
    delete dialog;
    emit thumbs(thumbsList);
    return true;

}

bool TmdbScraper::downloadInfo(QString code){
    infoResp.clear();
    if (!downloader->syncGet(hostName+infoPath+code,&infoResp)) {
        lastError="Cannot retrieve api info response";
        return false;
    }else{
        return parseMovieInfo();
    }
}

bool TmdbScraper::parseSearchResult(){
    results.clear();
    QBuffer buff(&searchResp);

    if (! buff.open(QIODevice::ReadOnly)) {
        lastError="Cannot read search response.";
        return false;
    }

    reader.setDevice(&buff);

    if(!reader.readNextStartElement ()){
        lastError="Can't read server response.\nThis seems to be a Connection issue.\nOr maybe you've inserted a non-valid TMDB APIKEY.";
        return false;
    }

    while (!reader.atEnd()) {
        reader.readNext();

        if (reader.name() == "totalResults" && reader.readElementText() =="0") {
            lastError="No Results.\nTry with different keywords.";
            return false;
        }

        if(reader.name()== "movie"){
            reader.readNext();
            MovieHeader header;
            while(reader.name()!="movie"){

                if (reader.name() == "id") header.setID(reader.readElementText());
                if (reader.name() == "original_name")  header.setName(reader.readElementText());
                if (reader.name() =="released") header.setDate(reader.readElementText());
                if (reader.name() =="alternative_name")header.setAltName(reader.readElementText());

                reader.readNext();
            }
            results.append(header);
        }
    }

    buff.close();
    return true;
}


bool TmdbScraper::parseMovieInfo(){

    movie.clear();
    thumbsUrl.clear();
    QBuffer buff(&infoResp);
    QString cast ="";
    QString genre = "";

    if (!buff.open(QIODevice::ReadOnly)) {
        lastError="Cannot read movie detail response";
        return false;
    }

    reader.setDevice(&buff);
    while (!reader.atEnd()) {
        reader.readNext();

        if (movie.getOrigTitle().isEmpty() && reader.name() == "original_name") {
            movie.setOrigTitle(reader.readElementText());
        }

        if (movie.getAltTitle().isEmpty() && reader.name() == "alternative_name") {
            movie.setAltTitle(reader.readElementText());
        }

        if (movie.getPlot().isEmpty() && reader.name() == "overview" ) {
            movie.setPlot(reader.readElementText());
        }

        if (movie.getDate().isEmpty()  && reader.name() == "released") {
            movie.setDate(reader.readElementText());
        }

        if (movie.getTime().isEmpty() && reader.name() == "runtime" ) {
            movie.setTime(reader.readElementText());
        }

        if (movie.getPage().isEmpty() && reader.name() == "url") {
            movie.setPage(reader.readElementText());
        }

        if (movie.getRating().isEmpty() &&  reader.name() == "rating" ) {
            movie.setRating(reader.readElementText());
        }

        if (movie.getCountry().isEmpty() &&  reader.name() == "country" ) {
            if (reader.attributes().hasAttribute("name") ){
                movie.setCountry(reader.attributes().value("name").toString());
            }
        }

        if (movie.getDirector().isEmpty() &&  reader.name() == "person" ) {
            if ((reader.attributes().value("job").toString()) == "Director" ){
                movie.setDirector( reader.attributes().value("name").toString());
            }
        }

        if ( reader.name() == "category") {
            if ((reader.attributes().hasAttribute("name")) ){
                genre +=(""+(reader.attributes().value("name").toString())+", ");
            }
        }

        if (reader.name() == "person") {
            if ((reader.attributes().value("job").toString()) == "Actor" ){
                cast += (""+(reader.attributes().value("name").toString())+", ");

            }
        }

        if (reader.name() == "image") {

            if (((reader.attributes().value("type").toString()) == "poster") && ((reader.attributes().value("size").toString()) == "mid" )){
                if (movie.getThumb().isNull()) {
                    QByteArray bytes;
                    downloader->syncGet(reader.attributes().value("url").toString(),&bytes);
                    thumbsUrl.append(reader.attributes().value("url").toString());
                    QImage image;
                    image.loadFromData(bytes);
                    if (image.width() > 195 || image.height()>305 )image = image.scaled(195,305,Qt::KeepAspectRatio,Qt::SmoothTransformation);
                    movie.setThumb(QPixmap::fromImage(image));


                }else {
                    this->thumbsUrl.append(reader.attributes().value("url").toString());
                }
            }
        }
    }
    genre.remove(genre.length()-2,2);
    cast.remove(cast.length()-2,2);
    if(!cast.isEmpty())cast.insert(cast.length()," .");
    movie.setGenre(genre);
    movie.setCast(cast);
    buff.close();
    return true;
}

QList< MovieHeader > TmdbScraper::getSearchResult(){

    return results;
}

Movie TmdbScraper::getMovie(){
    return movie;
}

QString TmdbScraper::getParserID(){
    return ID;
}

QString TmdbScraper::getLastError(){
    return lastError;
}


QString TmdbScraper::nameReplace(QString name){

    for(int i=0; i<name.length();i++){

        if((name.at(i)).isSpace()){

            name.replace(i,1,"%20");}

        if(((QString)name.at(i)).toUtf8()=="ò" || ((QString)name.at(i)).toUtf8()=="ó" ){

            name.replace(i,1,"o");}

        if(((QString)name.at(i)).toUtf8()=="à"){
            name.replace(i,1,"a");}

        if(((QString)name.at(i)).toUtf8()=="è" || ((QString)name.at(i)).toUtf8()=="é" ){
            name.replace(i,1,"e");}

        if(((QString)name.at(i)).toUtf8()=="ì" ){
            name.replace(i,1,"i");}

        if(((QString)name.at(i)).toUtf8()=="ù" ){
            name.replace(i,1,"u");}

    }

    return name;
}
