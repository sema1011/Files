#include "singletondownloader.h"
#include <iostream>
#include <QVariant>
#include <QBuffer>
#include <QNetworkReply>
#include <QNetworkProxy>




SingletonDownloader::SingletonDownloader()
{

    proxy.setType(QNetworkProxy::HttpProxy);
    QObject::connect(this, SIGNAL(finished(QNetworkReply*)),this, SLOT(finished(QNetworkReply*)));

}

/// the instance of the object that will be returned, needs to be istantieted in the body file to be created.
SingletonDownloader*  SingletonDownloader::_instance = 0;


SingletonDownloader* SingletonDownloader::getInstance()
{
    if (_instance == 0) {
        _instance = new SingletonDownloader;
    }
    return _instance;
}


bool SingletonDownloader::syncGet(QString url, QByteArray *BA){
    this->get(QNetworkRequest(QUrl(url)));
    loop.exec();
    *BA=respData;
    return true;
}

void SingletonDownloader::proxySet (QString pr, unsigned int po){
    proxy.setHostName(pr);
    proxy.setPort(po);
    this->setProxy(proxy);

}


void SingletonDownloader::proxyRemove (){

    this->setProxy(QNetworkProxy::NoProxy);

}



void SingletonDownloader::finished(QNetworkReply* reply){

    /*
     * Reply is finished!
     * We'll ask for the reply about the Redirection attribute
     */
    QVariant possibleRedirectUrl =
            reply->attribute(QNetworkRequest::RedirectionTargetAttribute);

    /* We'll deduct if the redirection is valid in the redirectUrl function */
    _urlRedirectedTo = this->redirectUrl(possibleRedirectUrl.toUrl(),_urlRedirectedTo);

    /* If the URL is not empty, we're being redirected. */
    if(!_urlRedirectedTo.isEmpty()) {
        /* We'll do another request to the redirection url. */
        this->get(QNetworkRequest(_urlRedirectedTo));
    }
    else {
        /*
             * We weren't redirected anymore
             * so we arrived to the final destination...
             */
        respData=reply->readAll();
        /*Escape from the loop that blocks SyncGet excecution*/
        loop.exit();
        /* ...so this can be cleared. */
        _urlRedirectedTo.clear();

    }
    /* Clean up. */
    reply->deleteLater();
}

QUrl SingletonDownloader::redirectUrl(const QUrl& possibleRedirectUrl, const QUrl& oldRedirectUrl) const {
    QUrl redirectUrl;

    if(!possibleRedirectUrl.isEmpty() && possibleRedirectUrl != oldRedirectUrl) {
        redirectUrl = possibleRedirectUrl;
    }
    return redirectUrl;
}
