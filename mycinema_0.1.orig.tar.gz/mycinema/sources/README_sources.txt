    Source code available at:
    https://sites.google.com/site/mycinemaproject/source

    Copyright (C) 2010-2012  Gianluigi Biancucci.
    Contact: Gianluigi85@gmail.com
