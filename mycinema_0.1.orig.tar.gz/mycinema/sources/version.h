#ifndef VERSION_H
#define VERSION_H

#define VERSION "12.05.07"

#endif // VERSION_H
