#include <QtGui/QApplication>
#include "mycinema.h"
#include "path.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.addLibraryPath(APPLPATH+"lib");
    MyCinema w;
    w.show();

    return a.exec();
}
