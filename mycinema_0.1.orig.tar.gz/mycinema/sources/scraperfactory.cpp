#include "scraperfactory.h"
#include "scraperinterface.h"
#include "tmdbscraper.h"
#include "filmupscraper.h"
ScraperFactory::ScraperFactory()
{
}

QString ScraperFactory::scraper="";

MovieScraper* ScraperFactory::getInstance(){

    if(scraper == "Filmup.it"){
        return new  FilmupScraper();
    }

    if(scraper == "TMDB.org"){

        return new  TmdbScraper();

    }
    return new  TmdbScraper();
}

void ScraperFactory::setScraper(QString name){
    scraper = name;
}

