#include "movieheader.h"

MovieHeader::MovieHeader()
{
}

void MovieHeader::setID(QString movID){
    this->movieID=movID;
}

void MovieHeader::setDate(QString movieDate){
    this->date = movieDate;
}
void MovieHeader::setCode(QString movieCode){
    this->code=movieCode;
}

void MovieHeader::setName(QString movieTitle){
    this->name=movieTitle;
}

void MovieHeader::setAltName(QString movieTitle){
    this->altName=movieTitle;
}
QString MovieHeader::getID(){
    return this->movieID;
}
QString MovieHeader::getCode(){
    return this->code;
}

QString MovieHeader::getName(){
    return this->name;
}

QString MovieHeader::getAltName(){
    return this->altName;
}

QString MovieHeader::getDate(){
    return this->date;
}

void MovieHeader::clear(){

    movieID="";
    date="";
    code="";
    name="";
    altName="";
}
