#include "adddialog.h"
#include "ui_adddialog.h"
#include <iostream>
#include <QMessageBox>
#include "path.h"
#include "movie.h"

AddDialog::AddDialog(QWidget *parent) :
        QDialog(parent),
        ui(new Ui::AddDialog)
{
    ui->setupUi(this);
    for (int i =2;i<18;i++){
      ui->tableWidget->setColumnHidden(i,true);
    }
    ui->tableWidget->setColumnWidth(1,335);
    ui->tableWidget->setColumnWidth(0,95);
    QObject::connect(ui->tableWidget, SIGNAL(cellChanged(int,int)),this,SLOT(setEditedRows(int,int)));
    this->editDialog=0;
}

AddDialog::~AddDialog()
{
    delete ui;
}
void AddDialog::closeEvent ( QCloseEvent * e )  {

    this->QDialog::closeEvent(e);
    emit deleteMe(this);

}
void AddDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void AddDialog::on_cancelButton_clicked()  {

    this->close();
}

void AddDialog::setEditedRows(int row, int column){

    QString string = ui->tableWidget->model()->index(row,column).data().toString();
    QString code = ui->tableWidget->model()->index(row,0).data().toString();
    QString name = ui->tableWidget->model()->index(row,1).data().toString();
    if(!string.isNull() && !string.isEmpty() && string.at(0).isSpace()){
        ui->tableWidget->item(row,column)->setData(Qt::EditRole,ui->tableWidget->model()->index(row,column).data().toString().remove(0,1));
    }

    if(  (code.isEmpty() && !name.isEmpty()) || (!code.isEmpty() && name.isEmpty()) ) {
        bool isPresent=false;
        for ( int i =0; i<toCompleteRows.length();i++){

            if(toCompleteRows.at(i) == row) {
                isPresent=true;
                std::cerr << "!!!";
            }

        }
        if(!isPresent) toCompleteRows.append(row);

    }
    else{
        for ( int i =0; i<toCompleteRows.length();i++){

            if(toCompleteRows.at(i) == row) {
                toCompleteRows.removeAt(i);
                break;
            }

        }
    }

    if(!code.isEmpty() && !name.isEmpty()){

        if (editedRows.isEmpty()) editedRows.append(row);
        else {
            for(int i =0;i< editedRows.length();i++){

                if (row == editedRows.at(i)){
                    break;
                }
                if (row < editedRows.at(i)){
                    editedRows.insert(i,row);
                    break;
                }
                if(i == editedRows.length()-1){
                    editedRows.append(row);
                    break;
                }                
            }
        }
    }else{
        for ( int i =0; i<editedRows.length();i++){
            if(editedRows.at(i) == row) {editedRows.removeAt(i);break;
            }
        }
    }
}

void AddDialog::on_dvdRadio_clicked(){
    ui->hd1Radio->setDisabled(true);
    ui->hd2Radio->setDisabled(true);
    ui->sdRadio->setChecked(true);
    ui->sdRadio->setEnabled(true);

}

void AddDialog::on_fileRadio_clicked(){
    ui->hd1Radio->setEnabled(true);
    ui->hd2Radio->setEnabled(true);
    ui->sdRadio->setEnabled(true);
}

void AddDialog::on_bdRadio_clicked(){
    ui->hd1Radio->setDisabled(true);
    ui->sdRadio->setDisabled(true);
    ui->hd2Radio->setEnabled(true);
    ui->hd2Radio->setChecked(true);
}

QString AddDialog::getResolution(){
    if(ui->sdRadio->isChecked())return "SD";
    if(ui->hd1Radio->isChecked())return "720";
    if(ui->hd2Radio->isChecked())return "1080";
    return "";

}

QString AddDialog::getFormat(){
    if(ui->fileRadio->isChecked())return "FILE";
    if(ui->dvdRadio->isChecked())return "DVD";
    if(ui->bdRadio->isChecked())return "BD";
    return "";
}

QString AddDialog::getCategory(){
    if(ui->moviesRadio->isChecked())return "MOVIE";
    if(ui->tvRadio->isChecked())return "TV";
    if(ui->toonRadio->isChecked())return "TOON";
    return "";
}


void AddDialog::on_editButton_clicked(){
    if(this->editDialog!=0) delete editDialog;
    editDialog= new EditDialog(this);
    QObject::connect(editDialog, SIGNAL(updateMovie(QMap<QString,bool>,QString,Movie)),this, SLOT(updateRow(QMap<QString,bool>,QString,Movie)));

    Movie movie;
    movie.setCode(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),0).data().toString());
    movie.setCustomName(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),1).data().toString());
    movie.setOrigTitle(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),2).data().toString());
    movie.setAltTitle(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),3).data().toString());
    movie.setCountry(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),4).data().toString());
    movie.setDate(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),5).data().toString());
    movie.setPage(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),6).data().toString());
    movie.setDirector(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),7).data().toString());
    movie.setTime(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),8).data().toString());
    movie.setGenre(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),9).data().toString());
    movie.setCast(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),10).data().toString());
    movie.setPlot(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),11).data().toString());
    movie.setRating(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),12).data().toString());
    movie.setRes(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),13).data().toString());
    movie.setFormat(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),14).data().toString());
    movie.setLocation(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),15).data().toString());
    movie.setCategory(ui->tableWidget->model()->index(ui->tableWidget->currentIndex().row(),16).data().toString());
    movie.setThumb(thumbMap.value(ui->tableWidget->currentIndex().row()));
    QVariant pKey = ui->tableWidget->currentIndex().row();
    editDialog->populateField(pKey.toString(), movie);
    editDialog->show();
}
void AddDialog::updateRow(QMap<QString,bool> updateFields, QString rowStr,Movie movie){
    QVariant rowV = rowStr;
    int row = rowV.toInt();
    for ( int i =0; i<18;i++){
        if(ui->tableWidget->item(row,i) == 0 ){
            QTableWidgetItem *item= new QTableWidgetItem(Qt::EditRole);
            ui->tableWidget->setItem(row,i,item);
        }
    }

    ui->tableWidget->item(row,0)->setData(Qt::EditRole,movie.getCode());
    ui->tableWidget->item(row,1)->setData(Qt::EditRole,movie.getCustomName());
    ui->tableWidget->item(row,2)->setData(Qt::EditRole,movie.getOrigTitle());


    if(updateFields.value("Thumb")){thumbMap.insert(row, movie.getThumb());
    std::cerr << "updateThumb";
    }
    ui->tableWidget->item(row,3)->setData(Qt::EditRole,movie.getAltTitle());
    ui->tableWidget->item(row,4)->setData(Qt::EditRole,movie.getCountry());
    ui->tableWidget->item(row,5)->setData(Qt::EditRole,movie.getDate());
    ui->tableWidget->item(row,6)->setData(Qt::EditRole,movie.getPage());
    ui->tableWidget->item(row,7)->setData(Qt::EditRole,movie.getDirector());
    ui->tableWidget->item(row,8)->setData(Qt::EditRole,movie.getTime());
    ui->tableWidget->item(row,9)->setData(Qt::EditRole,movie.getGenre());
    ui->tableWidget->item(row,10)->setData(Qt::EditRole,movie.getCast());
    ui->tableWidget->item(row,11)->setData(Qt::EditRole,movie.getPlot());
    ui->tableWidget->item(row,12)->setData(Qt::EditRole,movie.getRating());
    ui->tableWidget->item(row,13)->setData(Qt::EditRole,movie.getRes());
    ui->tableWidget->item(row,14)->setData(Qt::EditRole,movie.getFormat());
    ui->tableWidget->item(row,15)->setData(Qt::EditRole,movie.getLocation());
    ui->tableWidget->item(row,16)->setData(Qt::EditRole,movie.getCategory());
 //   if(movieData.contains(21))ui->tableWidget->item(row,17)->setData(Qt::EditRole,movieData.value(21));

}

void AddDialog::on_clearAllButton_clicked(){
    ui->tableWidget->clearContents();
    editedRows.clear();
    toCompleteRows.clear();
}
void AddDialog::on_clearButton_clicked(){
    for (int i =0;i<ui->tableWidget->selectedItems().length();i++){
        ui->tableWidget->selectedItems().at(i)->setData(Qt::EditRole,"");
    }

}
void AddDialog::on_storeButton_clicked(){
        if(toCompleteRows.isEmpty() && !editedRows.isEmpty()){
            this->setHidden(true);
            QList< Movie > movieList;
            for (int i =0;i<editedRows.length();i++){
                Movie movie;
                movie.setCode(ui->tableWidget->model()->index(editedRows.at(i),0).data().toString().toUpper());
                movie.setCustomName(ui->tableWidget->model()->index(editedRows.at(i),1).data().toString());
                movie.setOrigTitle(ui->tableWidget->model()->index(editedRows.at(i),2).data().toString());
                movie.setThumb(thumbMap.value(editedRows.at(i)));
                movie.setAltTitle((ui->tableWidget->model()->index(editedRows.at(i),3).data().toString()));
                movie.setCountry(ui->tableWidget->model()->index(editedRows.at(i),4).data().toString());
                movie.setDate(ui->tableWidget->model()->index(editedRows.at(i),5).data().toString());
                movie.setPage(ui->tableWidget->model()->index(editedRows.at(i),6).data().toString());
                movie.setDirector(ui->tableWidget->model()->index(editedRows.at(i),7).data().toString());
                movie.setTime(ui->tableWidget->model()->index(editedRows.at(i),8).data().toString());
                movie.setGenre(ui->tableWidget->model()->index(editedRows.at(i),9).data().toString());
                movie.setCast(ui->tableWidget->model()->index(editedRows.at(i),10).data().toString());
                movie.setPlot(ui->tableWidget->model()->index(editedRows.at(i),11).data().toString());
                movie.setRating(ui->tableWidget->model()->index(editedRows.at(i),12).data().toString());

                if(ui->tableWidget->model()->index(editedRows.at(i),13).data().toString().isEmpty())
                    movie.setRes(getResolution());
                else
                    movie.setRes(ui->tableWidget->model()->index(editedRows.at(i),13).data().toString());

                if(ui->tableWidget->model()->index(editedRows.at(i),14).data().toString().isEmpty())
                    movie.setFormat(getFormat());
                else
                    movie.setFormat(ui->tableWidget->model()->index(editedRows.at(i),14).data().toString());


                if(ui->tableWidget->model()->index(editedRows.at(i),15).data().toString().isEmpty())
                    movie.setLocation(ui->locationText->toPlainText());
                else
                    movie.setLocation(ui->tableWidget->model()->index(editedRows.at(i),15).data().toString());

                if(ui->tableWidget->model()->index(editedRows.at(i),16).data().toString().isEmpty())
                    movie.setCategory(getCategory());
                else
                    movie.setCategory(ui->tableWidget->model()->index(editedRows.at(i),16).data().toString());

              //  if(!ui->tableWidget->model()->index(editedRows.at(i),17).data().toString().isEmpty())
                //    movieData.insert(21,ui->tableWidget->model()->index(editedRows.at(i),17).data().toString());


                movieList.append(movie);
            }
            emit insertMovies(movieList);
            this->close();
        }else {if(!toCompleteRows.isEmpty()){
            QString rows=" ";
            for  (int i = 0; i < toCompleteRows.length(); i++){
                QVariant v = toCompleteRows.at(i)+1;
                rows+= ""+v.toString()+", ";
            }
            rows.remove(((rows.length())-2),2);
            QMessageBox msgBox;
            msgBox.setText("Code or Name missing in the following rows:"+rows+"");
            msgBox.exec();
            }else this->close();
        }

}









/* std::cerr << "EDITED: ";

 for  (int i = 0; i < editedRows.length(); i++){
     QVariant v = editedRows.at(i);
     std::cerr << qPrintable(v.toString()) << "  ";
 }
 std::cerr << "|";

 std::cerr << "COMPLETE: ";

 for  (int i = 0; i < toCompleteRows.length(); i++){
     QVariant v = toCompleteRows.at(i);
     std::cerr << qPrintable(v.toString()) << "  ";
 }
 std::cerr << "|";
*/
