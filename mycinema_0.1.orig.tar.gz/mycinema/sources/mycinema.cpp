#include <cstdlib>
#include <ctime>
#include "mycinema.h"
#include "ui_mycinema.h"
#include <QtGui/QApplication>
#include "db.h"
#include "filmupscraper.h"
#include <QPixmap>
#include <iostream>
#include <QLineEdit>
#include "scraperinterface.h"
#include "resultdialog.h"
#include "editdialog.h"
#include <QMainWindow>
#include <QDialog>
#include <QRadioButton>
#include "storedialog.h"
#include "updatedialog.h"
#include <QFileDialog>
#include "detailsdialog.h"
#include <QMessageBox>
#include "detailsdialog.h"
#include "adddialog.h"
#include <QScrollArea>
#include <QDir>
#include "proxydialog.h"
#include "aboutdialog.h"
#include "path.h"
#include "singletondownloader.h"
#include "movieheader.h"
#include "movie.h"
#include "QDesktopWidget"

MyCinema::MyCinema(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MyCinema)
{
    ui->setupUi(this);
    this->centerWidget(this);

    this->scraper=0;
    this->setScraper("TMDB.org");
    this->hdView="";
    this->categoryView="";
    this->formatView="";
    backgroundParsing = false;
    backgroundCurrInd=0;
    proxyDialog =0;
    ui->searchFieldCombo->setDisabled(true);
    ui->byLabel->setDisabled(true);
    ui->searchButton->setShortcut(QKeySequence(Qt::Key_Return));
    proxyModel.setSourceModel(&model);
    ui->treeView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->treeView->setCornerButtonEnabled(false);
    ui->treeView->verticalHeader()->setHidden(true);
    ui->treeView->setSortingEnabled(true);
    ui->treeView->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->treeView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->treeView->setStyleSheet("color: black ;selection-color: black ; selection-background-color: #99CCFF" );
    ui->treeView->setWordWrap(false);
    ui->treeView->setTextElideMode(Qt::ElideNone);
    ui->treeView->setModel(&proxyModel);
    ui->treeView->sortByColumn(0,Qt::AscendingOrder);


    QDir dir;
    dir = QDir ();

    if(!dir.exists(SETTINGSPATH))dir.mkpath(SETTINGSPATH);
    if(!dir.exists(DBPATH))dir.mkpath(DBPATH);
    if(!dir.exists(THUMBPATH))dir.mkpath(THUMBPATH);
    movieDb = new Db("QSQLITE","movies.db",DBPATH);

    frames.append((ui->titleText));
    frames.append((ui->nationText));
    frames.append((ui->dateText));
    frames.append((ui->webText));
    frames.append((ui->directorText));
    frames.append((ui->timeText));
    frames.append((ui->genreText));
    frames.append((ui->castText));
    frames.append((ui->plotText));
    frames.append((ui->ratingText));
    frames.append((ui->locationText));
    frames.append(ui->altTitleLabel);
    this->refresh("MovieDB");

    QImage addImg(DEFICONPATH+"add.gif");
    QImage rmImg(DEFICONPATH+"remove.gif");
    QImage editImg(DEFICONPATH+"edit.gif");
    QImage impImg(DEFICONPATH+"import.gif");
    QImage expImg(DEFICONPATH+"export.gif");
    QImage proxyImg(DEFICONPATH+"network.gif");
    QImage helpImg(DEFICONPATH+"help.gif");
    QImage aboutImg(DEFICONPATH+"info.gif");

    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(addImg)),"Add"), SIGNAL(triggered()),this, SLOT(add()));
    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(rmImg)),"Delete"), SIGNAL(triggered()),this, SLOT(remove()));
    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(editImg)),"Edit"), SIGNAL(triggered()),this, SLOT(edit()));
    ui->toolBar->addSeparator();
    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(impImg)),"Import List"), SIGNAL(triggered()),this, SLOT(import()));
    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(expImg)),"Export List"), SIGNAL(triggered()),this, SLOT(list()));
    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(proxyImg)),"Proxy Settings"), SIGNAL(triggered()),this, SLOT(setProxy()));
    ui->toolBar->addSeparator();
    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(helpImg)),"Help"), SIGNAL(triggered()),this, SLOT(help()));
    QObject::connect(ui->actionHelp, SIGNAL(triggered()),this, SLOT(help()));
    QObject::connect( ui->toolBar->addAction( QIcon (QPixmap::fromImage(aboutImg)),"About"), SIGNAL(triggered()),this, SLOT(about()));
    QObject::connect(ui->actionAdd_Movie_s, SIGNAL(triggered()),this, SLOT(add()));
    QObject::connect(ui->actionEdit_Selected_Movie, SIGNAL(triggered()),this, SLOT(edit()));
    QObject::connect(ui->actionExport_Movie_List, SIGNAL(triggered()),this, SLOT(list()));
    QObject::connect(ui->actionDelete_Selected_Movie_s, SIGNAL(triggered()),this, SLOT(remove()));
    QObject::connect(ui->actionExit, SIGNAL(triggered()),this, SLOT(close()));
    QObject::connect(ui->actionSet_Proxy, SIGNAL(triggered()),this, SLOT(setProxy()));
    QObject::connect(ui->actionAbout,SIGNAL(triggered()),this, SLOT(about()));
    QObject::connect(ui->parserCombo, SIGNAL(currentIndexChanged (QString)),this, SLOT(setScraper(QString)));
    QObject::connect(ui->treeView->selectionModel(), SIGNAL(currentRowChanged(QModelIndex , QModelIndex)),this, SLOT(selChanged(QModelIndex , QModelIndex)));
    QObject::connect(this->movieDb, SIGNAL(doneUp(bool,QString,QString)),this, SLOT(refreshPkey(bool,QString,QString)));
    QObject::connect(this->movieDb, SIGNAL(doneIns(bool,QString,QString)),this, SLOT(refreshPkey(bool,QString,QString)));
    this->fillQuotesPool();

}

MyCinema::~MyCinema()
{
    movieDb->getDb(true);
    delete ui;
}

void MyCinema::closeEvent ( QCloseEvent * e )  {
    QMessageBox msgBox;
    msgBox.setText("<b>"+this->getRandomQuote()+"</b>");
    msgBox.setTextFormat(Qt::RichText);
    msgBox.setFixedSize(450,150);
    this->centerWidget(&msgBox);
    msgBox.exec();
    this->QWidget::closeEvent(e);


}
void MyCinema::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}




void MyCinema::setProxy(){
    if(this->proxyDialog == 0) proxyDialog = new ProxyDialog(this);
    proxyDialog->show();
    proxyDialog->activateWindow();

}

void MyCinema::help(){

    QMessageBox msgBox;
    QString text = "Sorry. No help documentation present yet.\n\n";
    text += "But if you're asking 'What is the meaning of the 'code' field? And why it is\n";
    text +=" so crucial?'\n";
    text +="Well, the answer is simple: the purpose of this program it is to collect and\n";
    text +="to catalog all your movies, creating your own collection. And how you can\n";
    text +="catalog a collection without any code? You can't.\n\n";
    text +="For instance: a convenient way to use the code field is to refer it to the \n";
    text +="physical support (PC,DVD,CD,BD...) where the movie file (DIVX video file or whatsoever) is stored.\n";
    text +="In this way, when you're looking for a movie in your collection, you'll find in\n";
    text +="a few clicks, the exact support (i.e. DVD1,DVD2...MYROOMPC...etc) where the movie is stored";

    msgBox.setText(text);
    msgBox.exec();
}

void MyCinema::about(){

    aboutDialog* about = new aboutDialog(this);
    about->show();
    about->activateWindow();

}
void MyCinema::edit(){
    if(ui->treeView->currentIndex().row() != -1){

        QString pKey = ui->treeView->model()->index(ui->treeView->currentIndex().row(),13).data().toString();
        Movie movie;
        movieDb->selectMovie(pKey,&movie);
        EditDialog* secondWindow = new EditDialog(this);
        secondWindow->setModal(true);
        secondWindow->populateField(pKey, movie);
        secondWindow->show();
        QObject::connect(secondWindow, SIGNAL(updateMovie(QMap <QString, bool>,QString,Movie)),movieDb, SLOT(updateMovie(QMap <QString, bool>,QString,Movie)));
        QObject::connect(secondWindow, SIGNAL(deleteMe(EditDialog *)),this, SLOT(deleteThis(EditDialog*)));

    }else{

        QMessageBox msgBox;
        msgBox.setText("No movie selected!");
        msgBox.exec();
    }

}



void MyCinema::add(){
    AddDialog * addDialog = new AddDialog(this);
    addDialog->show();
    QObject::connect(addDialog, SIGNAL(insertMovies(QList <Movie>)),movieDb, SLOT(multiple_insert(QList<Movie>)));
    QObject::connect(addDialog, SIGNAL(deleteMe(AddDialog*)),this, SLOT(deleteThis(AddDialog*)));

}







void MyCinema::remove(){
    if(ui->treeView->currentIndex().row() != -1){
        QMessageBox msgBox;
        msgBox.addButton("Cancel",QMessageBox::RejectRole);
        msgBox.addButton("OK",QMessageBox::AcceptRole);
        msgBox.setText("Are you sure that you want to remove selected movies from DB ?");
        if(msgBox.exec()){
            QModelIndexList indexList = ui->treeView->selectionModel()->selectedRows();
            int row = indexList.at(0).row();
            row--;
            QList<QString> pkeyList;
            for(int i=0;i<indexList.length();i++){
                QString pkey = ui->treeView->model()->index(indexList.at(i).row(),13).data().toString();
                pkeyList.append(pkey);
            }
            movieDb->multiple_delete(pkeyList);
            QString pKey = ui->treeView->model()->index(row,13).data().toString();
            this->refreshPkey(true,"",pKey);
        }
    }else{
        QMessageBox msgBox;
        msgBox.setText("No movie selected!");
        msgBox.exec();
    }
}

void MyCinema::import(){
   QMessageBox msgBox;
    QString text = "With this function,(in a very experimental state), you can import a text file\n";
    text+= "containing your movie entries. Each row of the text file, has to be\n";
    text+="formatted in this way :\n'MOVIECODE[space]MOVIENAME'\nEverything after the space it will be interpreted as the movie name.";
    text+="In this way you can import hundred of movies in One click, to after retrieve detailed info.\n";
    text+="(take a look to 'Search&Store' function, to get and store automatically,in one click, hundred movie details)";
    msgBox.addButton("Cancel",QMessageBox::RejectRole);
    msgBox.addButton("OK",QMessageBox::AcceptRole);
    msgBox.setText(text);
    if(msgBox.exec()){


        QString fileName = QFileDialog::getOpenFileName(this, tr("Load File"),tr("Text file (*.txt)"));
        QFile inputFile(fileName);
        inputFile.open(QIODevice::ReadOnly);
        QTextStream in(&inputFile);
        while( in.atEnd()== false){
            QString code = in.readLine();
            QString name= code;
            int esc =0;
            for(int j = 0;j<code.length() && esc==0;j++){
                if(code.at(j).isSpace()){code.remove(j,code.length()-(j));esc=1;}
            }
            name.remove(0,code.length()+1);
            if(name.length()>100)name.remove(100,name.length());
            Movie movie;
            movie.setCustomName(name);
            movie.setCode(code);
            movieDb->insertMovie(movie);
        }
        inputFile.close();
        this->refresh("MovieDB");
    }
}

bool MyCinema::list(){

    QString header = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
    header +="<html><head>\n";
    header +="<meta content=\"text/html; charset=UTF-8\" http-equiv=\"content-type\">\n";
    header +="<title>MovieDB content list</title>\n";
    header +="</head><body>\n";
    header +="<div style=\"text-align: center;\">\n";
    header +="<h1>Movie list :</h1>\n";
    header +="</div>\n";
    header +="<br>\n";
    header +="<table style=\"text-align: left;  margin-left: auto; margin-right: auto;\" border=\"1\" cellpadding=\"2\" cellspacing=\"2\">\n";
    header +="<tbody>\n";
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save File"),tr("MovieList.html"));
    if(!fileName.isNull() && !fileName.isEmpty()){
        QFile outFile(fileName);
        outFile.open(QIODevice::WriteOnly);
        QTextStream out(&outFile);
        QTextCodec *tc = QTextCodec::codecForMib(106);

        out.setCodec(tc);
        // out.setAutoDetectUnicode(true);
        out << header ;

        refresh("MovieDB");
        int height=ui->treeView->model()->rowCount((ui->treeView->rootIndex()));
        for(int i =0; i < height; i++){
            QString name = ui->treeView->model()->index(i,1).data().toString();
            std::cerr << qPrintable(name) << "\n";
            QString code = ui->treeView->model()->index(i,0).data().toString();
            QString genre = ui->treeView->model()->index(i,9).data().toString();
            QString cast = ui->treeView->model()->index(i,10).data().toString();
            QString res = ui->treeView->model()->index(i,14).data().toString();
            QString format = ui->treeView->model()->index(i,15).data().toString();
            QString url = ui->treeView->model()->index(i,6).data().toString();
            //if (!url.isEmpty())t
            QString tableRow ="<tr>\n";
            tableRow += "<td style=\"vertical-align: top; width: 50px; height: 1px;\" ><small>"+code+"</small><br>\n";
            tableRow += "</td>\n";
            tableRow +="<td style=\"vertical-align: top; width: 400px; text-align: center; height: 1px;\">";
            if (!url.isEmpty())tableRow += "<a href=\""+url+"\" target=\"_blank\">";
            tableRow +="<small>"+name+"</small>";
            if (!url.isEmpty())tableRow +="</a>";
            tableRow += "<br>\n";
            tableRow +="</td>\n";
            tableRow +="<td style=\"vertical-align: top; width: 150px; text-align: center; height: 1px;\"><small>"+genre+"</small><br>\n";
            tableRow +="</td>\n";
            tableRow +="<td style=\"vertical-align: top; width: 150px; text-align: center; height: 1px;\"><small>"+cast.remove(43,cast.length()-43)+"...</small><br>\n";
            tableRow +="</td>\n";
            tableRow +="<td style=\"vertical-align: top; width: 100px; height: 1px;\"><small>"+format+", "+res+"</small><br>\n";
            tableRow +="</td>\n";
            tableRow +="</tr>\n";
            out << tableRow;

        }
        QString footer =   "</tbody>\n</table>\n<br>\n</body></html>";
        out << footer;

        outFile.close();
        return true;}
    return false;


}





void MyCinema::on_getstoreButton_clicked(){

    if(ui->treeView->currentIndex().row() != -1){

        QMessageBox msgBox;
        QString text = "This function,(in a very experimental state), automatically retrieve details";
        text+= "(from the selected site) of all the selected movies in the list, updating also the selected ";
        text+="entries. It overwrites every previous information of the selected movies. So it's suggested to";
        text+="use this, to update movies with no information.";
        msgBox.addButton("Cancel",QMessageBox::RejectRole);
        msgBox.addButton("OK",QMessageBox::AcceptRole);
        msgBox.setText(text);
        if(msgBox.exec()){
            LoadingDialog* loading = new LoadingDialog(this,"Downloading and saving details...");
            loading->showIt();
            QModelIndexList indexList = ui->treeView->selectionModel()->selectedRows();
            loading->setValues(0,indexList.length(),0);

            QList<QString> pKeyList;
            QList<QString> nameList;
            for(int i=0;i<indexList.length();i++){
                QString pKey = ui->treeView->model()->index(indexList.at(i).row(),13).data().toString();
                QString name = ui->treeView->model()->index(indexList.at(i).row(),1).data().toString();
                QString origTitle = ui->treeView->model()->index(indexList.at(i).row(),2).data().toString();

                pKeyList.append(pKey);

                if(name.isEmpty() && origTitle.isEmpty())nameList.append("");
                else {
                    if(origTitle.isEmpty())nameList.append(name);
                    else nameList.append(origTitle);
                }
            }
            QList<QString> pKeyUpdList;
            QList<Movie> movieUpdList;
            QList < QMap< QString, bool > >updateFieldsList;

            for(int i=0;i<pKeyList.length();i++){

                QList< MovieHeader  >results;
                if(scraper->search(nameList.at(i))){
                    results = scraper->getSearchResult();
                    MovieHeader h =  results.at(0);
                    scraper->downloadInfo(h.getID());
                    QMap< QString, bool > updateFields;
                    updateFields.insert("Cast",true);
                    updateFields.insert("Nation",true);
                    updateFields.insert("ReleaseDate",true);
                    updateFields.insert("Director",true);
                    updateFields.insert("Genre",true);
                    updateFields.insert("HomePage",true);
                    updateFields.insert("Plot",true);
                    updateFields.insert("Thumb",true);
                    updateFields.insert("Rating",true);
                    updateFields.insert("Runtime",true);
                    updateFields.insert("Title",true);
                    updateFields.insert("AltTitle",true);
                    Movie movie = scraper->getMovie();
                    pKeyUpdList.append(pKeyList.at(i));
                    movieUpdList.append(movie);
                    updateFieldsList.append(updateFields);
                }
                loading->nextStep();
            }
            movieDb->multiple_update(updateFieldsList,pKeyUpdList,movieUpdList);
            loading->close();
            delete loading;
        }

    }else { QMessageBox msgBox;
        msgBox.setText("No movie selected.");
        msgBox.exec();}

}


void MyCinema::on_comboBox_currentIndexChanged(QString index){

    if (index == "Local"){
        ui->searchFieldCombo->setEnabled(true);
        ui->byLabel->setEnabled(true);
    }else {
        ui->searchFieldCombo->setDisabled(true);
        ui->byLabel->setDisabled(true);
        ui->searchFieldCombo->setCurrentIndex(0);
    }

}


bool MyCinema::on_searchButton_clicked(){

    if( !ui->searchText->text().isEmpty()){
        if( ui->comboBox->currentText() == "Local" ){
            this->localSearch(ui->searchText->text());
        }
        else{
            this->onlineSearch(ui->searchText->text());
        }

    }else{
        QMessageBox msgBox;
        msgBox.setText("No Keyword inserted.");
        msgBox.exec();
    }
    return true;

}


void MyCinema::on_categoryCombo_currentIndexChanged(QString view){
    if(view == "All")categoryView = "";
    if(view == "Movies")categoryView = "MOVIE";
    if(view == "Tv Series")categoryView = "TV";
    if(view == "Toon Series")categoryView = "TOON";
    this->refresh(getCurrentView());
}

void MyCinema::on_formatCombo_currentIndexChanged(QString view){
    if(view == "All")formatView = "";
    if(view == "Video File")formatView = "FILE";
    if(view == "DVD")formatView = "DVD";
    if(view == "Blu Ray")formatView = "BD";
    this->refresh(getCurrentView());
}


void MyCinema::on_hdBox_clicked(){
    if(ui->hdBox->isChecked()) hdView="HD";
    else hdView = "";
    this->refresh(getCurrentView());

}



void MyCinema::refreshPkey(bool done,QString error,QString pKey){
    if(done){
        this->refresh(getCurrentView());
        if(!pKey.isEmpty())selectMovie(pKey2Row(pKey));
    }else{
        QMessageBox msgBox;
        msgBox.setText(error);
        msgBox.exec();
    }
}


void  MyCinema::refresh(QString view){

    currView=view;
    std::cerr<< "CURRVIEW: " << qPrintable (currView);
    model.clear();
    model.setQuery( "SELECT * FROM "+view+"", *movieDb->getDb(false));
    while (model.canFetchMore())model.fetchMore();

    for (int i =2;i<18;i++){
        ui->treeView->setColumnHidden(i,true);
    }
    ui->treeView->setColumnHidden(5,false);
    ui->treeView->setColumnHidden(12,false);
    ui->treeView->model()->setHeaderData(12,Qt::Horizontal,"R.");
    ui->treeView->model()->setHeaderData(5,Qt::Horizontal,"Date");
    ui->treeView->model()->setHeaderData(0,Qt::Horizontal,"Cod");
    ui->treeView->model()->setHeaderData(1,Qt::Horizontal,"Movie Name");
    ui->treeView->horizontalHeader()->setResizeMode(1,QHeaderView::Stretch);
    ui->treeView->setColumnWidth(0,47);
    // ui->treeView->setColumnWidth(1,200);
    ui->treeView->setColumnWidth(5,63);
    ui->treeView->setColumnWidth(12,24);
    ui->treeView->resizeRowsToContents();

}

QString MyCinema::getCurrentView(){
    QString view= hdView+categoryView+formatView;
    if(view == "") return "MovieDB";
    if(view == "HDDVD" || view == "HDMOVIEDVD" || view == "HDTVDVD" ||  view == "HDTOONDVD")view = "NOVIEW";
    if(view.at(view.length()-1)==view.at(1)) view.remove(0,2);    
    return(view);
}

void MyCinema::localSearch(QString keyWord){

    QList< MovieHeader >results;
    QString targetPKey;
    if(movieDb->searchMovie(ui->searchFieldCombo->currentText(),keyWord, &results)){

        if(results.length() >=2){
            ResultDialog  searchResultDialog;
            targetPKey=searchResultDialog.popupAlternatives(results);
            if(!targetPKey.isEmpty())this->refreshPkey(true,"",targetPKey);
        }
        else {
            if(results.length()==1){
                MovieHeader h = results.at(0);
                this->refreshPkey(true,"",h.getID());
            }
        }
    }else {
        QMessageBox msgBox;
        msgBox.setText(movieDb->getLastError());
        msgBox.exec();
    }

}



void MyCinema::onlineSearch(QString keyWord){

    QMessageBox msg;
    msg.setWindowTitle("Wait, please...");
    msg.setStandardButtons(0);
    msg.setText("<b>Searching...</b>");
    msg.show();

    if(scraper->search(keyWord)){
        QList< MovieHeader >results = scraper->getSearchResult();
        QString targetID;
        ResultDialog searchResultDialog;
        msg.close();
        targetID = searchResultDialog.popupAlternatives(results);
        if(!targetID.isEmpty()){
            msg.setText("<b>Retrieving movie details...</b>");
            msg.show();
            if(scraper->downloadInfo(targetID)){
                Movie movie = scraper->getMovie();
                DetailsDialog * movieDetails = new DetailsDialog(this, movieDb, ui->treeView);
                QObject::connect(movieDetails, SIGNAL(insertMovie(Movie)),this->movieDb, SLOT(insertMovie(Movie)));
                QObject::connect(movieDetails, SIGNAL(updateMovie(QMap< QString, bool >,QString, Movie)),this->movieDb, SLOT(updateMovie(QMap< QString, bool >,QString, Movie)));
                QObject::connect(movieDetails, SIGNAL(deleteMe(DetailsDialog*)),this, SLOT(deleteThis(DetailsDialog*)));
                QObject::connect(movieDetails, SIGNAL(downloadThumbs()),scraper, SLOT(downloadThumbs()));
                QObject::connect(scraper, SIGNAL(thumbs(QList<QPixmap>)),movieDetails, SLOT(popupThumbs(QList<QPixmap>)));
                msg.close();
                movieDetails->setInfoOnScreen(movie);
            }else {
                /// enter here if there are some errors retrieving specific movie details
                msg.close();
                QMessageBox msgBox;
                msgBox.setText(scraper->getLastError());
                msgBox.exec();
            }
        }

    } else {
        /// enter here if there is an Error or No Results
        msg.close();
        QMessageBox msgBox;
        msgBox.setText(scraper->getLastError());
        msgBox.exec();
    }

}

void MyCinema::deleteThis(DetailsDialog * dialog){
    delete dialog;
}

void MyCinema::deleteThis(EditDialog * dialog){
    delete dialog;
}

void MyCinema::deleteThis(AddDialog * dialog){
    delete dialog;
}

void MyCinema::setScraper (QString scraperName){
    if(scraper != 0) delete scraper;
    ScraperFactory::setScraper(scraperName);
    scraper=ScraperFactory::getInstance();
}


void MyCinema::selChanged(QModelIndex curr, QModelIndex prev){
    updateSearchText(curr.row());
    QString pKey = ui->treeView->model()->index(curr.row(),13).data().toString();
    showInfo(pKey);
}

void MyCinema::selectMovie(int row){
    ui->treeView->selectionModel()->select(ui->treeView->model()->index(row,1),QItemSelectionModel::ClearAndSelect);
    ui->treeView->setCurrentIndex(ui->treeView->model()->index(row,1));
    updateSearchText(row);
}



void MyCinema::showInfo(QString pKey){
    Movie movie;
    movieDb->selectMovie(pKey,&movie);
    for(int i=0;i<frames.length();i++){
        frames.at(i)->clear();
        frames.at(i)->text().toUtf8();
    }
    ui->imageLabel->clear();
    delete ui->imageLabel->pixmap();

    for(int i=0;i<=9;i++){
        frames.at(i)->setWordWrap(true);
    }
    frames.at(0)->setText(movie.getOrigTitle());
    frames.at(1)->setText(movie.getCountry());
    frames.at(2)->setText(movie.getDate());
    frames.at(3)->setText(movie.getPage());
    frames.at(4)->setText(movie.getDirector());
    frames.at(5)->setText(movie.getTime());
    frames.at(6)->setText(movie.getGenre());
    frames.at(7)->setText(movie.getCast());
    frames.at(8)->setText(movie.getPlot());
    frames.at(9)->setText(movie.getRating());
    frames.at(10)->setText(movie.getLocation());
    frames.at(11)->setText(movie.getAltTitle());
    QString alias =movie.getPage();
    if (movie.getPage().length()>33){alias.remove(22,((alias.length())-32));alias.insert(22,"...");}
    frames.at(3)->setText("<a href='"+movie.getPage()+"'>"+alias+"</a>");
    frames.at(3)->setWordWrap(true);
    ui->imageLabel->setPixmap(movie.getThumb());
    if(movie.getCategory()=="MOVIE")ui->categoryLabel->setText("Movies");
    if(movie.getCategory()=="TV")ui->categoryLabel->setText("TV Series");
    if(movie.getCategory()=="TOON")ui->categoryLabel->setText("Toon Series");
    if(movie.getRes()=="720")ui->resolutionLabel->setText("HD-Ready");
    if(movie.getRes()=="1080")ui->resolutionLabel->setText("Full-HD");
    if(movie.getRes()=="SD")ui->resolutionLabel->setText("Standard Def.");
    if(movie.getFormat()=="BD")ui->formatLabel->setText("Blu-ray");
    if(movie.getFormat()=="FILE")ui->formatLabel->setText("Video File");
    if(movie.getFormat()=="DVD")ui->formatLabel->setText("DVD-Video");
    frames[0]->setAlignment(Qt::AlignCenter);

}

void MyCinema::updateSearchText(int currRow){

    if(ui->treeView->model()->index(currRow,2).data().toString().isEmpty())ui->searchText->setText(ui->treeView->model()->index(currRow,1).data().toString());else
        ui->searchText->setText(ui->treeView->model()->index(currRow,2).data().toString());

}

int MyCinema::pKey2Row(QString pKey){
    int height1=ui->treeView->model()->rowCount((ui->treeView->rootIndex()));
    int targetRow=0;
    for (int i=0;i<height1;i++){
        if(ui->treeView->model()->index(i,13).data().toString()==pKey)targetRow = i;
    }
    return targetRow;
}

void MyCinema::fillQuotesPool(){
    this->quotesPool.append("\"1.21 gigawatts? 1.21 gigawatts? Great Scott!\"");
    this->quotesPool.append("\"Do or do not... there is no try.\"");
    this->quotesPool.append("\"Fifty years from now, when you're looking back at your life, don't you want to be able to say you had the guts to get in that car?\"");
    this->quotesPool.append("\"In this galaxy there's a mathematical probability of three million Earth-type planets. And in the universe, three million million galaxies like this. And in all that, and perhaps more...only one of each of us.\"");
    this->quotesPool.append("\"You're the wrong guy in the wrong place at the wrong time\"");
    this->quotesPool.append("\"The time-traveling is just too dangerous. Better that I devote myself to study the other great mystery of the universe: women!\"");
    this->quotesPool.append("\"Marty! What in the name of Sir Isaac H. Newton happened here?\"");
    this->quotesPool.append("\"Ah! What did I tell you? 88 miles per hour! The temporal displacement occurred exactly 1:20am and zero seconds!\"");
    this->quotesPool.append("\"Then where the hell *are* they?\"\n\"The appropriate question is, *When* the hell are they?\"");
    this->quotesPool.append("\"Time circuits on. Flux Capacitor... fluxxing. Engine running. All right!\"");

}

void MyCinema::centerWidget(QWidget* w){
    QDesktopWidget* dw = QApplication::desktop();
    const QRect screen = dw->screenGeometry();
    const QRect widget = w->rect();
    const QPoint newpos = screen.center() - widget.center();
    w->move(newpos);

}

QString MyCinema::getRandomQuote(){
    int nMax=this->quotesPool.length();
    std::cerr << nMax;
    srand(time(NULL));
    int ran = ( rand() % nMax );
    return this->quotesPool.at(ran);
}

