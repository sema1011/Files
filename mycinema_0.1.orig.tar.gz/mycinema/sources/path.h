#ifndef PATH_H
#define PATH_H
#include <QDir>
#include <QApplication>

//Fixed paths. Must not be changed.
#define APPLPATH QApplication::applicationDirPath()+"/"
#define DEFICONPATH APPLPATH+"icons/"
#define HOMEPATH QDir::homePath ()+"/"

//If the following paths doesn't exists, they are created in MyCinema constructor
//It's safe to change one or more of these path: no issue are reported and their content is re-created (with and empty DB).
#define DBPATH  HOMEPATH+".mycinema/db/sqlite/"
#define THUMBPATH  HOMEPATH+".mycinema/db/posters/"
#define SETTINGSPATH  HOMEPATH+".mycinema/"



#endif // PATH_H
