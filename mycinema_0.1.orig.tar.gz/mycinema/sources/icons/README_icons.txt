These icons are licensed under the GNU General Public License (GPL) v3.0.
If you’re using this set contact me at:

gianluigi85@gmail.com

