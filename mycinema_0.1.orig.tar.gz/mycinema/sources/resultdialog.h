#ifndef RESULTDIALOG_H
#define RESULTDIALOG_H

#include <QDialog>
#include <QLabel>
#include <QRadioButton>
#include <QPushButton>
#include <QVariant>
#include <QHBoxLayout>
#include <QSpacerItem>
#include "movieheader.h"
#include "QEventLoop"
namespace Ui {
    class ResultDialog;
}

class ResultDialog : public QDialog {
    Q_OBJECT
public:

    ResultDialog(QWidget *parent = 0);
    ~ResultDialog();
    void insertMovie(MovieHeader header);

    int getChoice();
    QString popupAlternatives(QList < MovieHeader >);

protected:
    void changeEvent(QEvent *e);
    void closeEvent ( QCloseEvent * e );

private slots:
    void on_okButton_clicked();
signals:
    void selectedMovie(QString pKey);
    void deleteMe(ResultDialog * results);

private:
    Ui::ResultDialog *ui;

    QList<QLabel*> movies;
    QList<QLabel*> altNames;
    QEventLoop loop;
    QList<QLabel*> dates;
    QList<QLabel*> ids;
    QList<QLabel*> codes;
    QList<QRadioButton*> radio;
    QList< QHBoxLayout*> HLay;
    QList< QSpacerItem*> spacer;
    QString targetID;
    int choice;
    int i;
};

#endif // RESULTDIALOG_H
