#include "db.h"
#include <iostream>
#include <QSortFilterProxyModel>
#include <QAbstractItemView>
#include <QVariant>
#include "movieheader.h"
#include "movie.h"
#include "path.h"
#include "QMessageBox"
Db::Db(QString newDbDriver, QString name, QString path){

    dbDriver= newDbDriver;
    dbPath= path;
    dbName= name;
    db_initialize();


}

QString Db::getPath(){
    return this->dbPath;
}


QSqlDatabase* Db::getDb( bool close )
{
    if ( close )
    {
        db.close();
        if(db.isOpen()) std::cerr << "db still open!";
    }

    return &db;
}



bool Db::insertMovie(Movie movie){

    if(!movie.getCode().isEmpty() && !movie.getCustomName().isEmpty()){        
        if(!this->ins(movie)){
            emit doneIns(false,this->lastError,"");
            return false;
        }else{
            emit doneIns(true,"",this->selectLastPkey());
            return true;
        }
    } else {
        lastError="Code or Name field Empty.";
        emit doneIns(false,this->lastError,"");
        return false;
    }    
}

bool  Db::multiple_insert(QList< Movie >movieList){

    for(int i = 0; i < movieList.length();i++){
        Movie movie = movieList.at(i);
        if(!movie.getCode().isEmpty() && !movie.getCustomName().isEmpty()){
            if(!this->ins(movie)){
                emit doneIns(false,this->lastError,"");
                return false;
            }
        }else{
            emit doneIns(false,this->lastError,"");
            return false;
        }
    }
    emit doneIns(true,"",this->selectLastPkey());
    return true;
}


bool Db::deleteMovie(QString pkey){

    QString query = "DELETE FROM MovieDB WHERE PKey LIKE '"+pkey+"'";

    QSqlQuery queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    if(queryResult.lastError().type()==0){
            this->removeThumb(pkey);
        emit doneDel(true,"","");
        return true;

    }
    else{

        lastError="Cannot execute delete query";
        emit doneDel(false,this->lastError,pkey);
        return false;
    }
}

bool Db::multiple_delete(QList<QString> pkeyList){
    QString query = "DELETE FROM MovieDB WHERE PKey IS ";

    for(int i =0; i < pkeyList.length();i++){
        query+= "'"+pkeyList.at(i)+"' OR PKey IS ";
    }
    query= query.remove(query.length()-12,11);
    QSqlQuery queryResult= db.exec (query);
    if(queryResult.lastError().type()==0){
        for(int i =0; i < pkeyList.length();i++){
            this->removeThumb(pkeyList.at(i));
        }
        emit doneDel(true,"","");
        return true;
    }
    else{
        lastError="Cannot execute multiple delete query";
        emit doneDel(false,this->lastError,pkeyList.first());
        return false;
    }

}

bool Db::updateMovie( QMap< QString, bool> updateFields, QString pKey, Movie movie){

    if(!this->upd(updateFields,pKey,movie)){
        emit doneUp(false, this->lastError, pKey);
        return false;
    }else{
        emit doneUp(true, "", pKey);
        return true;
    }

}




bool Db::multiple_update( QList < QMap< QString, bool> >updateFieldsList, QList< QString > pKeyList, QList< Movie > movieList){
    int n = pKeyList.length();
    if(updateFieldsList.length() == n && movieList.length() == n) {
    for(int i = 0; i< n ;i++){
        if (!this->upd(updateFieldsList.at(i),pKeyList.at(i),movieList.at(i))){
            std::cerr << "falseupd";
            emit doneUp(false, this->lastError, pKeyList.at(i));
            return false;
        }
    }
    emit doneUp(true, "", pKeyList.last());
    return true;
    }
    else {
        this->lastError= "Parameters not matching";
        emit doneUp(false, this->lastError, "");
        return false;
    }
}


bool Db::selectMovie(QString pKey, Movie* movie){
    movie->clear();

    QString query = "SELECT * FROM MovieDB WHERE PKey LIKE '"+pKey+"'";

    db.transaction();

    QSqlQuery queryResult= QSqlQuery (db);
    queryResult.exec (query);
    db.commit();
    queryResult.first();
    if(queryResult.lastError().type()==0){
        movie->setOrigTitle(queryResult.value(2).toString());
        movie->setAltTitle(queryResult.value(3).toString());
        movie->setCountry(queryResult.value(4).toString());
        movie->setDate(queryResult.value(5).toString());
        movie->setPage(queryResult.value(6).toString());
        movie->setDirector(queryResult.value(7).toString());
        movie->setTime(queryResult.value(8).toString());
        movie->setGenre(queryResult.value(9).toString());
        movie->setCast(queryResult.value(10).toString());
        movie->setPlot(queryResult.value(11).toString());
        movie->setRating(queryResult.value(12).toString());
        movie->setCode(queryResult.value(0).toString());
        movie->setCustomName(queryResult.value(1).toString());
        movie->setRes(queryResult.value(14).toString());
        movie->setFormat(queryResult.value(15).toString());
        movie->setLocation(queryResult.value(16).toString());
        movie->setCategory(queryResult.value(17).toString());
        QPixmap thumb;
        if(this->loadThumb(pKey, &thumb))
            movie->setThumb(thumb);
        else{
            lastError ="Cannot load thumb";
            return false;
        }
    } else {
        lastError= "Cannot execute select query";
        return false;
    }
    return true;

}


bool Db::searchMovie(QString searchField, QString keyW, QList < MovieHeader > *movieList){

    QString query = "SELECT Code, Name, PKey, ReleaseDate FROM MovieDB WHERE "+searchField+" LIKE '%"+esc(keyW)+"%' ";

    db.transaction();

    QSqlQuery queryResult= QSqlQuery (db);
    queryResult.exec (query);
    db.commit();
    if(queryResult.lastError().type()==0){
        if(queryResult.first()){
        while(!queryResult.isNull(0)){
            MovieHeader temp;
            temp.setID(queryResult.value(2).toString());
            temp.setName(queryResult.value(1).toString());
            temp.setCode(queryResult.value(0).toString());
            temp.setDate(queryResult.value(3).toString());
            movieList->append(temp);
            queryResult.next();
        }
        }else {
            lastError="No matches into local DB.";
            return false;
        }
    }else {
        lastError="Cannot execute search query";
        return false;
    }

    return true;

}



bool Db::db_initialize()
{
    //    db = QSqlDatabase::addDatabase(dbDriver);
    db = QSqlDatabase::addDatabase(dbDriver);

    db.setDatabaseName(dbPath + dbName);


    //  db.setDatabaseName(dbPath + dbName);

    db.open();
    if(!db.isOpen())std::cerr << "db closed!";
    QString query = "CREATE TABLE IF NOT EXISTS MovieDB ";
    query += "('Code' nvarchar(255), ";
    query += "'Name' nvarchar(255), ";
    query += "'Title' nvarchar(255), ";
    query += "'AltTitle' nvarchar(255), ";
    query += "'Nation' nvarchar(255), ";
    query += "'ReleaseDate' nvarchar(255), ";
    query += "'Homepage' nvarchar(255), ";
    query += "'Director' nvarchar(255), ";
    query += "'Runtime' int, ";
    query += "'Genre' nvarchar(255), ";
    query += "'Cast' nvarchar(1020), ";
    query += "'Plot' nvarchar(1020), ";
    query += "'Rating' nvarchar(255), ";
    query += "'PKey' integer primary key,";
    query += "'Resolution' nvarchar(255), ";
    query += "'Format' nvarchar(255), ";
    query += "'Location' nvarchar(255), ";
    query += "'Category' nvarchar(255) ) ";

    QSqlQuery queryResult= QSqlQuery (db);

    queryResult.exec (query);

    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS BD AS SELECT * FROM MOVIEDB WHERE Format = 'BD'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS DVD AS SELECT * FROM MOVIEDB WHERE Format = 'DVD'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS FILE AS SELECT * FROM MOVIEDB WHERE Format = 'FILE'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS HD AS SELECT * FROM MOVIEDB WHERE Resolution = '720' OR Resolution = '1080'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS HDFILE AS SELECT * FROM FILE WHERE Resolution = '720' OR Resolution = '1080'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS NOVIEW AS SELECT * FROM DVD WHERE Resolution ='720'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS MOVIE AS SELECT * FROM MOVIEDB WHERE Category = 'MOVIE'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS TV AS SELECT * FROM MOVIEDB WHERE Category = 'TV'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS TOON AS SELECT * FROM MOVIEDB WHERE Category = 'TOON'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS MOVIEDVD AS SELECT * FROM DVD WHERE Category = 'MOVIE'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS TVDVD AS SELECT * FROM DVD WHERE Category = 'TV'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS TOONDVD AS SELECT * FROM DVD WHERE Category = 'TOON'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS MOVIEFILE AS SELECT * FROM FILE WHERE Category = 'MOVIE'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS TVFILE AS SELECT * FROM FILE WHERE Category = 'TV'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS TOONFILE AS SELECT * FROM FILE WHERE Category = 'TOON'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS HDMOVIE AS SELECT * FROM HD WHERE Category = 'MOVIE'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS HDTV AS SELECT * FROM HD WHERE Category = 'TV'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS HDTOON AS SELECT * FROM HD WHERE Category = 'TOON'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    query = "CREATE VIEW IF NOT EXISTS HDMOVIEFILE AS SELECT * FROM HDFILE WHERE Category = 'MOVIE'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS HDTOONFILE AS SELECT * FROM HDFILE WHERE Category = 'TOON'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS HDTVFILE AS SELECT * FROM HDFILE WHERE Category = 'TV'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS MOVIEBD AS SELECT * FROM BD WHERE Category = 'MOVIE'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS TOONBD AS SELECT * FROM BD WHERE Category = 'TOON'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());
    query = "CREATE VIEW IF NOT EXISTS TVBD AS SELECT * FROM BD WHERE Category = 'TV'";
    queryResult= db.exec (query);
    std::cerr << qPrintable(queryResult.lastError().text());

    return true;

}

bool Db::ins(Movie movie){

    QString query = "INSERT INTO MovieDB (Code, Name, Title, AltTitle, Nation, ReleaseDate, Homepage, Director, Runtime, Genre, Cast, Plot, Rating, Resolution, Format, Location, Category) VALUES ( ";
    query += "'"+esc(movie.getCode()).toUpper()+"', ";
    query += "'"+esc(movie.getCustomName())+"', ";
    query += "'"+esc(movie.getOrigTitle())+"', ";
    query += "'"+esc(movie.getAltTitle())+"', ";
    query += "'"+esc(movie.getCountry())+"', ";
    query += "'"+esc(movie.getDate())+"', ";
    query += "'"+esc(movie.getPage())+"', ";
    query += "'"+esc(movie.getDirector())+"', ";
    query += "'"+esc(movie.getTime())+"', ";
    query += "'"+esc(movie.getGenre())+"', ";
    query += "'"+esc(movie.getCast())+"', ";
    query += "'"+esc(movie.getPlot())+"', ";
    query += "'"+esc(movie.getRating())+"', ";
    query += "'"+esc(movie.getRes())+"', ";
    query += "'"+esc(movie.getFormat())+"', ";
    query += "'"+esc(movie.getLocation())+"', ";
    query += "'"+esc(movie.getCategory())+"') ";

    db.transaction();


    QSqlQuery queryResult= QSqlQuery (db);
    queryResult.exec (query);
    db.commit();

    if(queryResult.lastError().type()==0){
        if(!movie.getThumb().isNull()){
            if(!this->storeThumb(movie.getThumb(), this->selectLastPkey())){
                lastError= "Movie "+movie.getCustomName()+" correctly inserted into db\nbut thumb not stored";
                return false;
            }
        }
    }else {
        this->lastError="Cannot execute insert query of "+movie.getCustomName()+".\n\nQuery error:\n"+queryResult.lastError().text();
        return false;
    }

    return true;


}

bool Db::upd( QMap< QString, bool> updateFields, QString pKey, Movie movie){

    QString query = "UPDATE MovieDB SET "+genUpdateQuery(updateFields, movie)+" WHERE PKey LIKE '"+pKey+"'";
    db.transaction();
    QSqlQuery queryResult= QSqlQuery (db);

    queryResult.exec (query);

    db.commit();

    if(queryResult.lastError().type()==0){
        if(!movie.getThumb().isNull() && updateFields.value("Thumb")){
            if(!this->storeThumb(movie.getThumb(), pKey)){
                lastError= "Movie "+movie.getCustomName()+" correctly inserted into db\nbut thumb not stored";
                return false;
            }
        }
    }else {
       this->lastError="Cannot execute update query of "+movie.getCustomName()+".\n\nQuery error:\n"+queryResult.lastError().text();
        return false;
    }
    return true;

}

QString Db::genUpdateQuery(QMap< QString, bool> updateFields, Movie movie){

    QString set="";
    if(updateFields.value("Code"))set += "Code = '"+esc(movie.getCode()).toUpper()+"', ";
    if(updateFields.value("Name"))set += "Name = '"+esc(movie.getCustomName())+"', ";
    if(updateFields.value("Title"))set += "Title = '"+esc(movie.getOrigTitle())+"', ";
    if(updateFields.value("AltTitle"))set += "AltTitle = '"+esc(movie.getAltTitle())+"', ";
    if(updateFields.value("Nation"))set += "Nation = '"+esc(movie.getCountry())+"', ";
    if(updateFields.value("ReleaseDate"))set += "ReleaseDate = '"+esc(movie.getDate())+"', ";
    if(updateFields.value("HomePage"))set += "Homepage = '"+esc(movie.getPage())+"', ";
    if(updateFields.value("Director"))set += "Director = '"+esc(movie.getDirector())+"', ";
    if(updateFields.value("Runtime"))set += "Runtime = '"+esc(movie.getTime())+"', ";
    if(updateFields.value("Genre"))set += "Genre = '"+esc(movie.getGenre())+"', ";
    if(updateFields.value("Cast"))set += "Cast = '"+esc(movie.getCast())+"', ";
    if(updateFields.value("Plot"))set += "Plot = '"+esc(movie.getPlot())+"', ";
    if(updateFields.value("Rating"))set += "Rating = '"+esc(movie.getRating())+"', ";
    if(updateFields.value("Resolution"))set += "Resolution = '"+esc(movie.getRes())+"', ";
    if(updateFields.value("Format"))set += "Format = '"+esc(movie.getFormat())+"', ";
    if(updateFields.value("Location"))set += "Location = '"+esc(movie.getLocation())+"', ";
    if(updateFields.value("Category"))set += "Category = '"+esc(movie.getCategory())+"', ";


    set.remove(set.length()-2,1);
    // std::cerr << qPrintable(set);
    return set;



}

QString Db::getLastError(){
    return this->lastError;
}

bool Db::loadThumb(QString pKey, QPixmap* out){

    QImage image(THUMBPATH+pKey+"_tn.png");
    QFile file(THUMBPATH+pKey+"_tn.png");
    if(!image.isNull()){
        *out=QPixmap::fromImage(image);
    }
    else if(file.exists())return false;

    return true;
}

bool Db::storeThumb(QPixmap thumb, QString pKey){
    QImage image = thumb.toImage();
    if (image.width() > 195 || image.height()>305 ) image = image.scaled(195,305,Qt::KeepAspectRatio,Qt::SmoothTransformation);
    if(image.save(THUMBPATH+pKey+"_tn.png","png",0))
        return true;
    else
        return false;
}

bool Db::removeThumb(QString pKey){

    QFile thumb (THUMBPATH+pKey+"_tn.png");
    if(thumb.exists()){
        thumb.remove();
        return true;
    }
    else return false;

}

QString Db::selectLastPkey(){
    QString query = "SELECT last_insert_rowid() ";

    db.transaction();

    QSqlQuery queryResult= QSqlQuery (db);
    std::cerr << "StartSEL";

    queryResult.exec (query);
    std::cerr << "DoneSEL";

    db.commit();
    std::cerr << qPrintable(queryResult.lastError().text());
    queryResult.first();

    return queryResult.value(0).toString();


}

QString Db::esc(QString string){

    if(string.isNull() || string.isEmpty())return "";

    if(!string.isNull() && !string.isEmpty() && string.at(0).isSpace())string.remove(0,1);

    const char* a ="'";
    for(int i=0;i<string.length();i++){
        if(string.at(i)==*a){
            string.insert(i,"'");
            i++;}
    }

 // Workaround : pasting some text into EditDialog QTextedit fields (when you edit a movie), in rarely cases it generates a
 // strange character that could be remove with this operation, also if this assignment
 // had to be LOSSLESS (in theory). Otherwise, the query cannot be performed.
   QString utf8Str = QString::fromUtf8(string.toUtf8());

   return utf8Str;
}



