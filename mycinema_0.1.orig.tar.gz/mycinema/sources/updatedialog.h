#ifndef UPDATEDIALOG_H
#define UPDATEDIALOG_H

#include <QDialog>
#include <QTreeView>
#include "db.h"
#include "resultdialog.h"
namespace Ui {
    class updateDialog;
}

class updateDialog : public QDialog {
    Q_OBJECT
public:
    updateDialog(QWidget *parent , QTableView* tview , Db* moviedb );
    ~updateDialog();
    void setView(   QTableView* treeview);

signals:
    void updateMovie(QMap< QString, bool > updateFileds, QString pkey);
protected:
    void changeEvent(QEvent *e);

private slots:
    void setTarget(QString pKey);
    void on_newRadio_clicked();
    void on_currentRadio_clicked();
    void on_storeButton_clicked();    
    void on_searchButton_clicked();
    void on_cancelButton_clicked();

private:
    Ui::updateDialog *ui;
    QTableView* treeview;
    QString selCode;
    QString selName;
    QString selPKey;
    QString newCode;
    QString newName;
    QString newPKey;
    QString targetPKey;
    Db* movieDb;
    ResultDialog* searchResultDialog;

};

#endif // UPDATEDIALOG_H
