#ifndef ADDDIALOG_H
#define ADDDIALOG_H
#include <QMap>
#include <QDialog>
#include "editdialog.h"
namespace Ui {
    class AddDialog;
}

class AddDialog : public QDialog {
    Q_OBJECT
public:
    AddDialog(QWidget *parent = 0);
    ~AddDialog();
    QString getResolution();
    QString getFormat();
    QString getCategory();
public slots:
    void on_cancelButton_clicked();
    void setEditedRows(int row, int column);
    void on_storeButton_clicked();
    void on_dvdRadio_clicked();
    void on_fileRadio_clicked();
    void on_editButton_clicked();
    void on_bdRadio_clicked();
    void on_clearAllButton_clicked();
    void on_clearButton_clicked();
    void updateRow(QMap<QString,bool>, QString rowStr,Movie movie);

protected:
    void changeEvent(QEvent *e);
    void closeEvent ( QCloseEvent * e ) ;

signals:
    void insertMovies(QList < Movie > movieList);
    void deleteMe(AddDialog * addDialog);

private:
    Ui::AddDialog *ui;
    EditDialog* editDialog;

    QList<int> editedRows;
    QList<int> toCompleteRows;
    QMap<int, QPixmap> thumbMap;
};

#endif // ADDDIALOG_H
