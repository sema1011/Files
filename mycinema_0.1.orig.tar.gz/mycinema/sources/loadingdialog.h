#ifndef LOADINGDIALOG_H
#define LOADINGDIALOG_H

#include <QDialog>
#include <QProgressBar>
namespace Ui {
    class LoadingDialog;
}

class LoadingDialog : public QDialog {
    Q_OBJECT
public:
    LoadingDialog(QWidget *parent = 0, QString message="Please Wait...", int size = 14);
    ~LoadingDialog();
    QProgressBar* progressBar();
    void nextStep();
    void setValues(int min, int max, int start);
    void setText(QString text);

public slots:
    void showIt();

protected:
    void changeEvent(QEvent *e);
    void closeEvent ( QCloseEvent * e )  ;
private:
    Ui::LoadingDialog *ui;
    QFont liberSans;

};

#endif // LOADINGDIALOG_H
