#include "proxydialog.h"
#include "ui_proxydialog.h"
#include <QMessageBox>
#include "singletondownloader.h"

ProxyDialog::ProxyDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProxyDialog)
{
    ui->setupUi(this);
    this->proxy="";
    this->port="";

}

ProxyDialog::~ProxyDialog()
{
    delete ui;
}

void ProxyDialog::closeEvent ( QCloseEvent * e )  {

    this->QDialog::closeEvent(e);
 //   delete this;

}

void ProxyDialog::showEvent ( QShowEvent * e )  {

    this->QDialog::showEvent(e);
    ui->proxyEdit->clear();
    ui->portEdit->clear();
    if(proxy!=""){
        ui->proxyCheck->setEnabled(true);
        ui->proxyEdit->setText(this->proxy);
        ui->portEdit->setText(this->port);
    }

}

void ProxyDialog::on_proxyCheck_clicked(){

    if(ui->proxyEdit->isEnabled()){
        ui->proxyEdit->setEnabled(false);
        ui->portEdit->setEnabled(false);
        ui->label_11->setEnabled(false);
        ui->label_12->setEnabled(false);
        ui->label_14->setEnabled(false);
    }else {
        ui->proxyEdit->setEnabled(true);
        ui->portEdit->setEnabled(true);
        ui->label_11->setEnabled(true);
        ui->label_12->setEnabled(true);
        ui->label_14->setEnabled(true);
    }

}
void ProxyDialog::on_setProxyButton_clicked(){
    if(ui->proxyCheck->isChecked()){
        if(ui->proxyEdit->text().isEmpty() || ui->portEdit->text().isEmpty()){
            QMessageBox msgBox;
            msgBox.setText("Proxy and Port field are mandatory.");
            msgBox.exec();
        }else {
        QVariant v = ui->portEdit->text();
        SingletonDownloader* downloader = SingletonDownloader::getInstance();
        downloader->proxySet(ui->proxyEdit->text(),v.toUInt());
        this->proxy= ui->proxyEdit->text();
        this->port=ui->portEdit->text();
        QMessageBox msgBox;
        msgBox.setText("Proxy Setted.");
        msgBox.exec();
    }
    }else{
        SingletonDownloader* downloader = SingletonDownloader::getInstance();
        downloader->proxyRemove();
        this->proxy = "";
        this->port = "";
        QMessageBox msgBox;
        msgBox.setText("Proxy Removed.");
        msgBox.exec();
    }
}

void ProxyDialog::on_closeButton_clicked(){
    this->close();
}

