#include "editdialog.h"
#include "ui_editdialog.h"
#include <iostream>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include "path.h"
#include "movie.h"
EditDialog::EditDialog(QWidget *parent) :
        QDialog(parent),
        ui(new Ui::EditDialog)
{

    ui->setupUi(this);
    QWidget::setTabOrder(ui->codeText,ui->nameText);
    QWidget::setTabOrder(ui->nameText,ui->titleText);
    QWidget::setTabOrder(ui->titleText,ui->nationText);
    QWidget::setTabOrder(ui->nationText,ui->dateText);
    QWidget::setTabOrder(ui->dateText,ui->timeText);
    QWidget::setTabOrder(ui->timeText,ui->webText);
    QWidget::setTabOrder(ui->webText,ui->directorText);
    QWidget::setTabOrder(ui->directorText,ui->genreText);
    QWidget::setTabOrder(ui->genreText,ui->castText);
    QWidget::setTabOrder(ui->castText,ui->plotText);
    QWidget::setTabOrder(ui->plotText,ui->ratingText);
    QWidget::setTabOrder(ui->ratingText,ui->locationText);
    QWidget::setTabOrder(ui->locationText,ui->codeText);



    ui->label_9->setStyleSheet("color:red");
    ui->label_11->setStyleSheet("color:red");
    ui->editThumbBox->setChecked(false);
    ui->browseButton->setDisabled(true);
    ui->imageLabel->setDisabled(true);
    updateFields.insert("Cast",true);
    updateFields.insert("Code",true);
    updateFields.insert("Name",true);
    updateFields.insert("Title",true);
    updateFields.insert("AltTitle",true);
    updateFields.insert("Nation",true);
    updateFields.insert("ReleaseDate",true);
    updateFields.insert("Director",true);
    updateFields.insert("Genre",true);
    updateFields.insert("HomePage",true);
    updateFields.insert("Plot",true);
    updateFields.insert("Thumb",false);
    updateFields.insert("Rating",true);
    updateFields.insert("Runtime",true);
    updateFields.insert("Resolution",true);
    updateFields.insert("Format",true);
    updateFields.insert("Location", true);
    updateFields.insert("Category",true);

}

EditDialog::~EditDialog()
{
    delete ui;
}
void EditDialog::on_cancelButton_clicked()  {

    this->close();
}
void EditDialog::closeEvent ( QCloseEvent * e )  {

    this->QDialog::closeEvent(e);
    emit deleteMe(this);


}
void EditDialog::on_editThumbBox_clicked(){
    if(!ui->editThumbBox->isChecked()){
        ui->browseButton->setDisabled(true);
        ui->imageLabel->setDisabled(true);
        ui->imageLabel->setPixmap(this->origThumb);
        this->updateFields.insert("Thumb", false);

    }else{
        ui->imageLabel->setEnabled(true);
        this->updateFields.insert("Thumb", true);
        ui->browseButton->setDisabled(false);

    }
}

void EditDialog::on_browseButton_clicked(){
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"),tr("Image_file "));
    if(!fileName.isNull() && !fileName.isEmpty())loadThumbFromFile(fileName);
}

bool EditDialog::loadThumbFromFile(QString fileName){

    if(!fileName.isEmpty()){
        QImage image(fileName);

        QPixmap pixmap = QPixmap::fromImage(image);

        if (pixmap.width() > 195 || pixmap.height()>305 ){
            ui->imageLabel->setPixmap(pixmap.scaled(195,305,Qt::KeepAspectRatio,Qt::SmoothTransformation));
        }
        else ui->imageLabel->setPixmap(pixmap);

        return true;
    }
    return false;
}

bool EditDialog::populateField(QString pKey, Movie movie){
    QVariant p = pKey;
    this->pkey=p.toString();
    this->origThumb=movie.getThumb();
    ui->imageLabel->setPixmap(this->origThumb);
    ui->codeText->setText(movie.getCode());
    ui->nameText->setText(movie.getCustomName());
    ui->titleText->setText(movie.getOrigTitle());
    ui->nationText->setText(movie.getCountry());
    ui->dateText->setText(movie.getDate());
    ui->webText->setText(movie.getPage());
    ui->directorText->setText(movie.getDirector());
    ui->timeText->setText(movie.getTime());
    ui->genreText->setText(movie.getGenre());
    ui->castText->setText(movie.getCast());
    ui->ratingText->setText(movie.getRating());
    ui->plotText->setText(movie.getPlot());
    ui->locationText->setText(movie.getLocation());
    ui->altTitleTex->setText(movie.getAltTitle());
    if(movie.getFormat()=="DVD"){ui->dvdRadio->setChecked(true);ui->hd1Radio->setDisabled(true);ui->hd2Radio->setDisabled(true);}
    if(movie.getFormat()=="FILE")ui->fileRadio->setChecked(true);
    if(movie.getFormat()=="BD"){ui->bdRadio->setChecked(true);ui->sdRadio->setDisabled(true);ui->hd1Radio->setDisabled(true);}
    if(movie.getRes()=="SD")ui->sdRadio->setChecked(true);
    if(movie.getRes()=="720")ui->hd1Radio->setChecked(true);
    if(movie.getRes()=="1080")ui->hd2Radio->setChecked(true);
    if(movie.getCategory()=="MOVIE")ui->moviesRadio->setChecked(true);
    if(movie.getCategory()=="TV")ui->tvRadio->setChecked(true);
    if(movie.getCategory()=="TOON")ui->toonRadio->setChecked(true);
    return true;
}
void EditDialog::on_dvdRadio_clicked(){
    ui->hd1Radio->setDisabled(true);
    ui->hd2Radio->setDisabled(true);
    ui->sdRadio->setChecked(true);
    ui->sdRadio->setEnabled(true);

}

void EditDialog::on_fileRadio_clicked(){
    ui->hd1Radio->setEnabled(true);
    ui->hd2Radio->setEnabled(true);
    ui->sdRadio->setEnabled(true);
}

void EditDialog::on_bdRadio_clicked(){
    ui->hd1Radio->setDisabled(true);
    ui->sdRadio->setDisabled(true);
    ui->hd2Radio->setEnabled(true);
    ui->hd2Radio->setChecked(true);
}

void EditDialog::on_saveButton_clicked(){

    if(!ui->codeText->toPlainText().isEmpty() && !ui->nameText->toPlainText().isEmpty()){
        QString format;
        QString res;
        QString category;
        Movie movie;
        if(ui->sdRadio->isChecked())res="SD";
        if(ui->hd1Radio->isChecked())res="720";
        if(ui->hd2Radio->isChecked())res="1080";
        if(ui->fileRadio->isChecked())format="FILE";
        if(ui->dvdRadio->isChecked())format="DVD";
        if(ui->bdRadio->isChecked())format="BD";
        if(ui->moviesRadio->isChecked())category="MOVIE";
        if(ui->tvRadio->isChecked())category="TV";
        if(ui->toonRadio->isChecked())category="TOON";
        if(updateFields.value("Thumb")){
            QImage c = ui->imageLabel->pixmap()->toImage();
            movie.setThumb(QPixmap::fromImage(c));
        }
        movie.setCode(ui->codeText->toPlainText());
        movie.setCustomName(ui->nameText->toPlainText());
        movie.setOrigTitle(ui->titleText->toPlainText());
        movie.setCountry(ui->nationText->toPlainText());
        movie.setDate(ui->dateText->toPlainText());
        movie.setPage(ui->webText->toPlainText());
        movie.setDirector(ui->directorText->toPlainText());
        movie.setTime(ui->timeText->toPlainText());
        movie.setGenre(ui->genreText->toPlainText());
        movie.setCast(ui->castText->toPlainText());
        movie.setPlot(ui->plotText->toPlainText());
        movie.setRating(ui->ratingText->toPlainText());
        movie.setAltTitle(ui->altTitleTex->toPlainText());
        movie.setRes(res);
        movie.setFormat(format);
        movie.setLocation(ui->locationText->toPlainText());
        movie.setCategory(category);

        emit updateMovie(updateFields,pkey, movie);
        this->close();
    } else
    {
        QMessageBox msgBox;
        msgBox.setText("Code and Name fields are mandatory.");
        msgBox.exec();

    }


}

void EditDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
