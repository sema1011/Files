#ifndef MOVIE_H
#define MOVIE_H

#include <QObject>
#include <QPixmap>
class Movie
{
public:
    Movie();

    /// Setter Method
    void setCode(QString movieCode); //Digital Support code (Es.: codice dvd)
    void setOrigTitle(QString movieTitle);
    void setAltTitle(QString movieTitle);
    void setCustomName(QString movieTitle);
    void setThumb(QPixmap movieThumb);
    void setCountry(QString movieCountry);
    void setDate(QString movieDate);
    void setPage(QString moviePage);
    void setDirector(QString movieDirector);
    void setTime(QString movieTime);
    void setGenre(QString movieGenre);
    void setCast(QString movieCast);
    void setPlot(QString moviePlot);
    void setRating(QString movieRating);
    void setRes(QString movieRes);
    void setFormat(QString movieFormat);
    void setLocation(QString movieLocation);
    void setCategory(QString movieCategory);

    /// Getter Methods
    QString getCode();
    QString getOrigTitle();
    QString getAltTitle();
    QString getCustomName();
    QPixmap getThumb();
    QString getCountry();
    QString getDate();
    QString getPage();
    QString getDirector();
    QString getTime();
    QString getGenre();
    QString getCast();
    QString getPlot();
    QString getRating();
    QString getRes();
    QString getFormat();
    QString getLocation();
    QString getCategory();
    void clear();

private:

    QString code;
    QString customName;
    QString origTitle;
    QString altTitle;
    QPixmap thumb;
    QList< QPixmap > thumbsUrl;
    QString country;
    QString date;
    QString webpage;
    QString director;
    QString time;
    QString genre;
    QString cast;
    QString plot;
    QString rating;
    QString res;
    QString format;
    QString location;
    QString cat;

};

#endif // MOVIE_H
