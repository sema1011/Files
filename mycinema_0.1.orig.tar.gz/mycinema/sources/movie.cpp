#include "movie.h"

Movie::Movie()

{
}

void Movie::setCode(QString movieCode){
    this->code=movieCode;
}

void Movie::setOrigTitle(QString movieTitle){
    this->origTitle=movieTitle;
}

void Movie::setAltTitle(QString movieTitle){
    this->altTitle=movieTitle;
}

void Movie::setCustomName(QString movieTitle){
    this->customName=movieTitle;
}

void Movie::setThumb(QPixmap thumb){
    this->thumb = thumb;
}

void Movie::setCountry(QString movieCountry){
    this->country = movieCountry;
}

void Movie::setDate(QString movieDate){
    this->date = movieDate;
}

void Movie::setPage(QString moviePage){
    this->webpage = moviePage;
}

void Movie::setDirector(QString movieDirector){
    this->director = movieDirector;
}

void Movie::setTime(QString movieTime){
    this->time=movieTime;
}

void Movie::setGenre(QString movieGenre){
    this->genre=movieGenre;
}

void Movie::setCast(QString movieCast){
    this->cast=movieCast;
}

void Movie::setPlot(QString moviePlot){
    this->plot=moviePlot;
}

void Movie::setRating(QString movieRating){
    this->rating=movieRating;
}
void Movie::setRes(QString movieRes){
    this->res=movieRes;
}
void Movie::setFormat(QString movieFormat){
    this->format=movieFormat;
}
void Movie::setLocation(QString movieLocation){
    this->location=movieLocation;
}
void Movie::setCategory(QString movieCategory){
    this->cat=movieCategory;
}
/// Getter Methods


QString Movie::getCode(){
    return this->code;
}

QString Movie::getOrigTitle(){
    return this->origTitle;
}

QString Movie::getAltTitle(){
    return this->altTitle;
}

QString Movie::getCustomName(){
    return this->customName;
}

QPixmap Movie::getThumb(){
    return this->thumb;
}

QString Movie::getCountry(){
    return this->country;
}

QString Movie::getDate(){
    return this->date;
}

QString Movie::getPage(){
    return this->webpage;
}

QString Movie::getDirector(){
    return this->director;
}

QString Movie::getTime(){
    return this->time;
}

QString Movie::getGenre(){
    return this->genre;
}

QString Movie::getCast(){
    return this->cast;
}

QString Movie::getPlot(){
    return this->plot;
}

QString Movie::getRating(){
    return this->rating;
}
QString Movie::getRes(){
    return this->res;
}
QString Movie::getFormat(){
    return this->format;
}
QString Movie::getLocation(){
    return this->location;
}
QString Movie::getCategory(){
    return this->cat;
}
void Movie::clear(){

    customName="";
    rating="";
    res="";
    format="";
    location="";
    cat="";
    code="";
    origTitle="";
    thumb = NULL;
    country="";
    date="";
    webpage="";
    director="";
    time="";
    genre="";
    cast="";
    plot="";
    altTitle="";
}
