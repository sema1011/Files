#ifndef STOREDIALOG_H
#define STOREDIALOG_H

#include <QDialog>

namespace Ui {
    class storeDialog;
}

class storeDialog : public QDialog {
    Q_OBJECT
public:
    storeDialog(QWidget *parent = 0);
    ~storeDialog();
signals:
    void insert(QString code, QString name, QString resolution, QString format, QString location, QString category);

private slots:
    void on_cancelButton_clicked();
    void on_storeButton_clicked();
    void on_fileRadio_clicked();
    void on_dvdRadio_clicked();
    void on_bdRadio_clicked();
protected:
    void changeEvent(QEvent *e);

private:
    Ui::storeDialog *ui;
    QString res;
    QString format;
    QString category;
};

#endif // STOREDIALOG_H
