#ifndef SCRAPERINTERFACE_H
#define SCRAPERINTERFACE_H
#include <QWidget>
#include <QObject>
#include <QMap>
#include "movie.h"
#include "movieheader.h"
class MovieScraper : public QObject {  //useful for garbage collection
    Q_OBJECT
public:

    virtual QString getParserID() = 0;
    virtual QString getLastError()=0;
    virtual QList< MovieHeader > getSearchResult() = 0;
    virtual Movie getMovie() = 0;
    virtual QList<QPixmap> getThumbs()=0;
public slots:
    virtual bool search(QString movieName)=0;
    virtual bool downloadInfo(QString movieCode)=0;
    virtual bool downloadThumbs()=0;
signals:
    void thumbs(QList < QPixmap > thumbs);


};
#endif //SCRAPERINTERFACE_H
