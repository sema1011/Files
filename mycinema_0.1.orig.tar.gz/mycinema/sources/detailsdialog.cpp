#include "detailsdialog.h"
#include "ui_detailsdialog.h"
#include <QBuffer>
#include "storedialog.h"
#include "updatedialog.h"
#include "db.h"
#include "tmdbscraper.h"
#include "filmupscraper.h"
#include "scraperinterface.h"
#include <iostream>
#include "path.h"
#include "singletondownloader.h"
#include "QMessageBox"
#include "QDialogButtonBox"
DetailsDialog::DetailsDialog(QWidget *parent, Db* Db,QTableView * tView) :
        QDialog(parent),
        ui(new Ui::DetailsDialog)
{
    ui->setupUi(this);
    this->movieDb=Db;
    this->treeView=tView;
    stDialog=0;
    upDialog=0;
    frames.append((ui->titleText));
    frames.append((ui->nationText));
    frames.append((ui->dateText));
    frames.append((ui->webText));
    frames.append((ui->directorText));
    frames.append((ui->timeText));
    frames.append((ui->genreText));
    frames.append((ui->castText));
    frames.append((ui->plotText));
    frames.append((ui->ratingText));
    frames.append(ui->altTitleLabel);

}

DetailsDialog::~DetailsDialog()
{
    delete ui;
}
void DetailsDialog::on_thumbsButton_clicked(){

    emit downloadThumbs();

}

void DetailsDialog::closeEvent ( QCloseEvent * e )  {

    this->QDialog::closeEvent(e);

    emit deleteMe(this);


}

void DetailsDialog::popupThumbs(QList <QPixmap> thumbsList)
{
    QList < QRadioButton* > radioList;
    QDialog * provaDialog = new QDialog();
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;

    QDialogButtonBox *buttonBox;

        provaDialog->setObjectName(QString::fromUtf8("provaDialog"));
        provaDialog->setMinimumSize(400,400);
        //provaDialog->setSizePolicy(QSizePolicy::Expanding);
        provaDialog->setMaximumSize(800, 400);
        verticalLayout_2 = new QVBoxLayout(provaDialog);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        scrollArea = new QScrollArea(provaDialog);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 378, 243));
        verticalLayout_3 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));

        for(int i =0; i < thumbsList.length();i++){
            QRadioButton * radio = new QRadioButton(scrollAreaWidgetContents);
            radioList.append(radio);
            horizontalLayout_2->addWidget(radio);
            QLabel* p = new QLabel(scrollAreaWidgetContents);
            p->setMinimumSize(195,305);
            p->setPixmap(thumbsList.at(i));
            horizontalLayout_2->addWidget(p);
            horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

            horizontalLayout_2->addItem(horizontalSpacer_2);

        }
        horizontalLayout_2->setAlignment(Qt::AlignLeft);


        verticalLayout_3->addLayout(horizontalLayout_2);

        scrollArea->setWidget(scrollAreaWidgetContents);

        verticalLayout->addWidget(scrollArea);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        buttonBox = new QDialogButtonBox(provaDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        horizontalLayout->addWidget(buttonBox);
        verticalLayout->addLayout(horizontalLayout);
        verticalLayout_2->addLayout(verticalLayout);
        QObject::connect(buttonBox, SIGNAL(accepted()), provaDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), provaDialog, SLOT(reject()));

   if(provaDialog->exec()){//1-> ok  0 -> cancel

       for (int i =0; i< radioList.length(); i++){
           if(radioList.at(i)->isChecked()){
               movie.setThumb(thumbsList.at(i));
               ui->imageLabel->setPixmap(thumbsList.at(i));
           }
       }
   }

}

void DetailsDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void DetailsDialog::setInfoOnScreen(Movie  details){
    movie=details;
    frames.at(0)->setText(movie.getOrigTitle());
    frames.at(1)->setText(movie.getCountry());
    frames.at(2)->setText(movie.getDate());
    frames.at(3)->setText(movie.getPage());
    frames.at(4)->setText(movie.getDirector());
    frames.at(5)->setText(movie.getTime());
    frames.at(6)->setText(movie.getGenre());
    frames.at(7)->setText(movie.getCast());
    frames.at(8)->setText(movie.getPlot());
    frames.at(9)->setText(movie.getRating());
    frames.at(10)->setText(movie.getAltTitle());
    frames.at(0)->setAlignment(Qt::AlignCenter);
    ui->imageLabel->setPixmap(movie.getThumb());
    QString alias =movie.getPage();
    if (movie.getPage().length()>27){alias.remove(19,((alias.length())-30));alias.insert(19,"...");}
    frames.at(3)->setText("<a href='"+movie.getPage()+"'>"+alias+"</a>");
    this->show();
    this->activateWindow();
}

void DetailsDialog::on_storeAsNewButton_clicked(){
    stDialog = new storeDialog(this);
    QObject::connect( stDialog, SIGNAL(insert(QString, QString, QString, QString,QString, QString)),this, SLOT(insertMovie(QString, QString,QString,QString,QString, QString)));
    stDialog->setModal(true);
    stDialog->show();
    stDialog->activateWindow();

}

void DetailsDialog::on_updateButton_clicked(){
    upDialog = new updateDialog(this, this->treeView, this->movieDb);
    QObject::connect(upDialog, SIGNAL(updateMovie(QMap< QString, bool >,QString)),this, SLOT(updateMovie(QMap< QString, bool >,QString)));
    upDialog->setModal(true);
    upDialog->show();
    upDialog->activateWindow();


}


void DetailsDialog::insertMovie(QString code, QString name, QString res, QString format, QString location, QString category){
    this->setHidden(true);
    movie.setCode(code);
    movie.setCustomName(name);
    movie.setRes(res);
    movie.setFormat(format);
    movie.setLocation(location);
    movie.setCategory(category);
    emit insertMovie(movie);
    stDialog->close();
    delete stDialog;
this->close();}

void DetailsDialog::updateMovie(QMap< QString, bool > updateFields, QString pKey){
    this->setHidden(true);
    emit updateMovie(updateFields, pKey, movie);
    upDialog->close();
    delete upDialog;
    this->close();
}


