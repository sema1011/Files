#include "aboutdialog.h"
#include "ui_aboutdialog.h"
#include "version.h"
aboutDialog::aboutDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::aboutDialog)
{
    ui->setupUi(this);
    ui->versionLabel->setText(VERSION);
}

aboutDialog::~aboutDialog()
{
    delete ui;
}
void aboutDialog::on_cancelButton_clicked(){
    this->close();
}
void aboutDialog::closeEvent ( QCloseEvent * e )  {

    this->QDialog::closeEvent(e);
    delete this;

}
