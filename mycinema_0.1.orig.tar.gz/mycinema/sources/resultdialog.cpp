#include "resultdialog.h"
#include "ui_resultdialog.h"
#include <QPixmap>
#include <iostream>
#include <QLineEdit>
#include "scraperinterface.h"
#include "resultdialog.h"
#include <QMainWindow>
#include <QDialog>
#include <QRadioButton>
#include <QCloseEvent>

ResultDialog::ResultDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ResultDialog)
{
    ui->setupUi(this);
    i =0;
    choice = 0;
    targetID="";

}

ResultDialog::~ResultDialog()
{
    delete ui;

}

void ResultDialog::closeEvent ( QCloseEvent * e )  {

    this->QDialog::closeEvent(e);
    loop.exit();
}

void ResultDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }

}


void  ResultDialog::insertMovie(MovieHeader header){

    QLabel* movieLabel;
    QLabel* movieAltLabel;
    QLabel* movieId;
    QLabel* movieCode;
    QLabel* movieDate;
    QRadioButton* choice1;
    choice1=new QRadioButton(ui->scrollAreaWidgetContents);
    movieLabel= new QLabel(ui->scrollAreaWidgetContents);
    movieAltLabel= new QLabel(ui->scrollAreaWidgetContents);
    movieId = new QLabel(ui->scrollAreaWidgetContents);
    movieCode = new QLabel(ui->scrollAreaWidgetContents);
    movieDate = new QLabel(ui->scrollAreaWidgetContents);
    QHBoxLayout * horizontalLayout  = new QHBoxLayout();
    horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout_10"+i));
    horizontalLayout->addWidget(choice1);
    horizontalLayout->addWidget( movieCode);
    horizontalLayout->addWidget( movieLabel);
    horizontalLayout->addWidget( movieDate);
    horizontalLayout->addWidget( movieAltLabel);
    QSpacerItem * horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    horizontalLayout->addSpacerItem(horizontalSpacer);    
    QFrame * line_2 = new QFrame(ui->scrollAreaWidgetContents);
    line_2->setObjectName(QString::fromUtf8("line_2"));
    QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    line_2->setSizePolicy(sizePolicy);
    line_2->setFrameShape(QFrame::HLine);
    line_2->setFrameShadow(QFrame::Sunken);
    ui->verticalLayout->addLayout(horizontalLayout);
    ui->verticalLayout->addWidget(line_2);
    this->movies.append(movieLabel);
    this->altNames.append(movieAltLabel);
    this->radio.append(choice1);
    this->dates.append(movieDate);
    this->ids.append(movieId);
    this->codes.append(movieCode);
    this->movies.at(i)->setText("<b>"+header.getName()+"</b>");
    if(!header.getAltName().isEmpty())this->altNames.at(i)->setText("  (Other Title: "+header.getAltName()+")");
    this->ids.at(i)->setText(header.getID());
    this->ids.at(i)->setHidden(true);
    if(!header.getCode().isEmpty())this->codes.at(i)->setText(header.getCode()+"  - ");
    if(!header.getDate().isEmpty())this->dates.at(i)->setText("   ("+header.getDate().remove(4,header.getDate().length()-4)+")");
    this->HLay.append(horizontalLayout);
    this->spacer.append(horizontalSpacer);
    i++;

}



void ResultDialog::on_okButton_clicked(){

    this->setHidden(true);
    targetID = ids.at(this->getChoice())->text();
    loop.exit();
    emit selectedMovie(targetID);
    this->close();

}



int ResultDialog::getChoice(){
    for(int i =0;i<radio.length();i++){
        if(radio.at(i)->isChecked()) choice=i;
    }
    return  choice;
}

QString ResultDialog::popupAlternatives(QList < MovieHeader > list){

    for(int j=0;j<list.length();j++){
        this->insertMovie(list.at(j));
    }

    QSpacerItem * verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);
    ui->verticalLayout->addSpacerItem(verticalSpacer);
    this->spacer.append(verticalSpacer);
    if(this->i < 11)  {
        ui->scrollArea->setFixedSize(530,30+(30*this->i));
        this->setFixedSize(550,150+30*this->i);
    }

    this->show();
    this->activateWindow();
    loop.exec();
    return targetID;
}
