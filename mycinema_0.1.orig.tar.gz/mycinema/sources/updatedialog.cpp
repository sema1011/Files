#include "updatedialog.h"
#include "ui_updatedialog.h"
#include "resultdialog.h"
#include <iostream>
#include <QMessageBox>
updateDialog::updateDialog(QWidget *parent , QTableView* tview, Db* db) :
    QDialog(parent),
    ui(new Ui::updateDialog)
{
    ui->setupUi(this);
    ui->searchButton->setShortcut(QKeySequence(Qt::Key_Return));
    ui->castBox->setChecked(true);
    ui->countryBox->setChecked(true);
    ui->dateBox->setChecked(true);
    ui->directorBox->setChecked(true);
    ui->genreBox->setChecked(true);
    ui->homeBox->setChecked(true);
    ui->plotBox->setChecked(true);
    ui->posterBox->setChecked(true);
    ui->ratingBox->setChecked(true);
    ui->timeBox->setChecked(true);
    ui->titleBox->setChecked(true);
    ui->currentRadio->setChecked(true);
    ui->altTitleBox->setChecked(true);
    ui->searchButton->setEnabled(false);
    ui->searchText->setEnabled(false);
    this->treeview= tview;
    this->movieDb=db;
    this->selCode=treeview->model()->index(treeview->currentIndex().row(),0).data().toString();
    this->selName=treeview->model()->index(treeview->currentIndex().row(),1).data().toString();
    this->selPKey=treeview->model()->index(treeview->currentIndex().row(),13).data().toString();
    ui->codeText->setText(selCode);
    ui->nameText->setText(selName);
    targetPKey=selPKey;
    this->searchResultDialog=0;
}

updateDialog::~updateDialog()
{
    delete ui;
}

void updateDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
void updateDialog::on_cancelButton_clicked()  {

    this->close();
}

void updateDialog::on_newRadio_clicked(){
    ui->searchButton->setEnabled(true);
    ui->searchText->setEnabled(true);
    ui->codeText->setText(newCode);
    ui->nameText->setText(newName);
    targetPKey=newPKey;
}

void updateDialog::on_currentRadio_clicked(){
    ui->searchButton->setEnabled(false);
    ui->searchText->setEnabled(false);
    ui->codeText->setText(selCode);
    ui->nameText->setText(selName);
    targetPKey=selPKey;

}

void updateDialog::on_searchButton_clicked(){
    if( !ui->searchText->toPlainText().isEmpty()){
        QList< MovieHeader >results;
        if(movieDb->searchMovie("Name",ui->searchText->toPlainText(), &results)){
            if(results.length() >=2){
                searchResultDialog= new ResultDialog(this);
                searchResultDialog->popupAlternatives(results);
                QObject::connect(searchResultDialog, SIGNAL(selectedMovie(QString)),this, SLOT(setTarget(QString)));
            }else{
                if(results.length()==1){
                    MovieHeader h = results.at(0);
                    setTarget(h.getID());
                }
            }
        }else {
            QMessageBox msgBox;
            msgBox.setText(movieDb->getLastError());
            msgBox.exec();
        }
    }else {
        QMessageBox msgBox;
        msgBox.setText("No Keyword inserted.");
        msgBox.exec();
    }

}
void updateDialog::setTarget(QString pKey){
    Movie movie;
    this->movieDb->selectMovie(pKey,&movie);
    ui->nameText->setText(movie.getCustomName());
    ui->codeText->setText(movie.getCode());
    this->newCode=movie.getCode();
    this->newName=movie.getCustomName();
    newPKey=pKey;
    targetPKey = newPKey;
}

void updateDialog::on_storeButton_clicked(){
    if(targetPKey.isEmpty()){
        QMessageBox msgBox;
        msgBox.setText("No movie selected to update");
        msgBox.exec();
    }else{
        this->setHidden(true);
        QMap< QString, bool > updateFields;
        updateFields.insert("Resolution",false);
        updateFields.insert("Format",false);
        updateFields.insert("Location", false);
        updateFields.insert("Category",false);
        updateFields.insert("Code",false);
        updateFields.insert("Name",false);
        if(ui->castBox->isChecked())updateFields.insert("Cast",true);
        else updateFields.insert("Cast",false);
        if(ui->countryBox->isChecked())updateFields.insert("Nation",true);
        else updateFields.insert("Nation",false);
        if(ui->dateBox->isChecked())updateFields.insert("ReleaseDate",true);
        else updateFields.insert("ReleaseDate",false);
        if(ui->directorBox->isChecked())updateFields.insert("Director",true);
        else updateFields.insert("Director",false);
        if(ui->genreBox->isChecked())updateFields.insert("Genre",true);
        else updateFields.insert("Genre",false);
        if(ui->homeBox->isChecked())updateFields.insert("HomePage",true);
        else updateFields.insert("HomePage",false);
        if(ui->plotBox->isChecked())updateFields.insert("Plot",true);
        else updateFields.insert("Plot",false);
        if(ui->posterBox->isChecked())updateFields.insert("Thumb",true);
        else updateFields.insert("Thumb",false);
        if(ui->ratingBox->isChecked())updateFields.insert("Rating",true);
        else updateFields.insert("Rating",false);
        if(ui->timeBox->isChecked())updateFields.insert("Runtime",true);
        else updateFields.insert("Runtime",false);
        if(ui->titleBox->isChecked())updateFields.insert("Title",true);
        else updateFields.insert("Title",false);
        if(ui->altTitleBox->isChecked())updateFields.insert("AltTitle",true);
        else updateFields.insert("AltTitle",false);
        emit updateMovie(updateFields,targetPKey);
  //      this->close();


    }
}

