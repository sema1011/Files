#ifndef MOVIEHEADER_H
#define MOVIEHEADER_H

#include <QObject>

class MovieHeader
{

public:
    explicit MovieHeader();

    void setID(QString movID); //Web ID & Local PKey
    void setDate(QString movieDate);
    void setName(QString movieTitle);
    void setAltName(QString movieTitle);
    void setCode(QString movieCode); //Local Digital Support code

    QString getCode();
    QString getName();
    QString getAltName();
    QString getID();
    QString getDate();
    void clear();
private:

    QString movieID;
    QString code;
    QString name;
    QString altName;
    QString date;

};

#endif // MOVIEHEADER_H
