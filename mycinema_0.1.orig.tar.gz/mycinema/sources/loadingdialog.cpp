#include "loadingdialog.h"
#include "ui_loadingdialog.h"

LoadingDialog::LoadingDialog(QWidget *parent, QString message, int size ) :
        QDialog(parent),
        ui(new Ui::LoadingDialog)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::CustomizeWindowHint|Qt::Dialog|Qt::WindowTitleHint);
    liberSans.setPixelSize(size);
    this->setText(message);


}

LoadingDialog::~LoadingDialog()
{
    delete ui;
}

void LoadingDialog::closeEvent ( QCloseEvent * e )  {

    this->QDialog::closeEvent(e);
//    delete this;

}

void LoadingDialog::setValues(int min, int max, int start)
{
    ui->progressBar->setMinimum(min);
    ui->progressBar->setMaximum(max);
    ui->progressBar->setValue(start);

}
void LoadingDialog::setText(QString text)
{

           liberSans.setFamily(QString::fromUtf8("Liberation Sans"));
    liberSans.setBold(true);
    ui->label->setFont(liberSans);
    ui->label->setText(text);

}
void LoadingDialog::nextStep()
{
    ui->progressBar->setValue(ui->progressBar->value()+1);
}

void LoadingDialog::showIt()
{
    this->show();
    this->activateWindow();
}

QProgressBar* LoadingDialog::progressBar()
{
    return ui->progressBar;
}

void LoadingDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
