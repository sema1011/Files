#include "storedialog.h"
#include "ui_storedialog.h"
#include <QMessageBox>

storeDialog::storeDialog(QWidget *parent) :
        QDialog(parent),
        ui(new Ui::storeDialog)
{
    ui->setupUi(this);
    QWidget::setTabOrder(ui->codeText,ui->nameText);
    QWidget::setTabOrder(ui->nameText,ui->locationText);
    QWidget::setTabOrder(ui->locationText,ui->codeText);

}

storeDialog::~storeDialog()
{
    delete ui;
}

void storeDialog::on_cancelButton_clicked()  {

    this->close();

}

void storeDialog::on_dvdRadio_clicked(){
    ui->hd1Radio->setDisabled(true);
    ui->hd2Radio->setDisabled(true);
    ui->sdRadio->setChecked(true);
    ui->sdRadio->setEnabled(true);

}

void storeDialog::on_fileRadio_clicked(){
    ui->hd1Radio->setEnabled(true);
    ui->hd2Radio->setEnabled(true);
    ui->sdRadio->setEnabled(true);
}

void storeDialog::on_bdRadio_clicked(){
    ui->hd1Radio->setDisabled(true);
    ui->sdRadio->setDisabled(true);
    ui->hd2Radio->setEnabled(true);
    ui->hd2Radio->setChecked(true);
}


void storeDialog::on_storeButton_clicked(){
    this->setHidden(true);
    if(ui->sdRadio->isChecked())res="SD";
    if(ui->hd1Radio->isChecked())res="720";
    if(ui->hd2Radio->isChecked())res="1080";
    if(ui->fileRadio->isChecked())format="FILE";
    if(ui->dvdRadio->isChecked())format="DVD";
    if(ui->bdRadio->isChecked())format="BD";
    if(ui->moviesRadio->isChecked())category="MOVIE";
    if(ui->tvRadio->isChecked())category="TV";
    if(ui->toonRadio->isChecked())category="TOON";
    QString code = ui->codeText->toPlainText();
    QString name = ui->nameText->toPlainText();
    if(code.isEmpty() || name.isEmpty()){
        QMessageBox msgBox;
        msgBox.setText("Code and Name fields are mandatory.");
        msgBox.exec();
    }else{
        emit insert(code, name, res, format, ui->locationText->toPlainText(), category);
        //this->close();

    }
}

void storeDialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
