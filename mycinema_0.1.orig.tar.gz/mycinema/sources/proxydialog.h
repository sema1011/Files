#ifndef PROXYDIALOG_H
#define PROXYDIALOG_H

#include <QDialog>

namespace Ui {
    class ProxyDialog;
}

class ProxyDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ProxyDialog(QWidget *parent = 0);

    ~ProxyDialog();
protected:
    void showEvent ( QShowEvent * e );
    void closeEvent ( QCloseEvent * e );

public slots:
    void on_proxyCheck_clicked();
    void on_setProxyButton_clicked();
    void on_closeButton_clicked();
signals:
    void proxyData(bool, QString proxy, unsigned int port);
    void removeProxy(bool);
    void deleteMe(ProxyDialog * proxy);


private:
    Ui::ProxyDialog *ui;
    QString proxy;
    QString port;
};

#endif // PROXYDIALOG_H
