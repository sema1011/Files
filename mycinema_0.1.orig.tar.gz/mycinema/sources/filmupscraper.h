#ifndef FILMUPSCRAPER_H
#define FILMUPSCRAPER_H
#include <QXmlStreamReader>
#include <QMap>
#include "scraperinterface.h"
#include <QFile>
#include <QWidget>
#include "movie.h"
#include "movieheader.h"
#include "singletondownloader.h"
class FilmupScraper : public MovieScraper
{

Q_OBJECT
public:
    explicit FilmupScraper();
    /// Getter methods.
    QString getParserID();
    QString getLastError();
    QList< MovieHeader > getSearchResult();
    Movie getMovie();
    /// public slots to search for a movie and to get movie specific details
    bool search(QString movieName);
    bool downloadInfo(QString movieCode);
    QList<QPixmap> getThumbs();
    bool downloadThumbs();
private:
    QList< MovieHeader > results;
    Movie movie;
    QList <QString> thumbsUrl;
    QList <QPixmap> thumbsList;
    bool parseMovieInfo(QString filmupID);
    bool parseSearchResult();
        SingletonDownloader* downloader;
    QString getContentBetween(QString source, QString startStr, QString endStr);
    QString removeTags(QString source);
    QString replace(QString source);
    QString getOpinionId(QByteArray searchFile);
    QString getPosterPage(QByteArray searchFile);
    QString findRating(QString searchFile);
    QString findTitle(QString searchFile);
    QString findPlot(QString searchFile);
    QString findPoster(QString searchFile);
    QString findThumb(QString searchFile);
    QString findCountry(QString searchFile);
    QString findDate(QString searchFile);
    QString findCast(QString searchFile);
    QString findDirector(QString searchFile);
    QString findGenre(QString searchFile);
    QString findTime(QString searchFile);
    QString dateParser(QString date);
    QString nameReplace(QString name);
    QByteArray searchResp;
    QByteArray infoResp;
    QByteArray opinionResp;
    QByteArray posterResp;
    QString hostName;
    QString searchPath1;
    QString searchPath2;
    QString infoPath;
    QString opinionPath;
    QString posterPath;
    QString ID;
    QString lastError;

};
#endif // FILMUPSCRAPER_H
