#ifndef DB_H
#define DB_H
#include <QtSql>
#include <QTableView>
#include <QTreeView>
#include <QSortFilterProxyModel>
#include "movie.h"
#include "movieheader.h"
class Db : public QObject {
    Q_OBJECT
public:

    Db(QString newDbDriver, QString name,QString path );
    QSqlDatabase* getDb( bool close );
    QString getPath();

public slots:
    bool insertMovie(Movie movie);
    bool deleteMovie(QString pKey);
    bool updateMovie(QMap< QString, bool> updateFields, QString pkey, Movie movie);
    bool multiple_insert(QList< Movie >movieList);
    bool multiple_delete(QList<QString> pkeyList);
    bool multiple_update( QList < QMap< QString, bool> >updateFieldsList, QList< QString > pKeyList, QList< Movie > movieList);
    bool selectMovie(QString pkey, Movie* movie);
    bool searchMovie(QString searchField, QString keyW, QList < MovieHeader > *results);
    QString getLastError();

signals:
    void doneUp(bool done, QString error, QString pKey);
    void doneIns(bool done, QString error, QString pKey);
    void doneDel(bool done, QString error, QString pKey);

private:
    QSqlDatabase db;
    bool db_initialize();
    bool ins(Movie movie);
    bool upd(QMap< QString, bool> updateFields, QString pkey, Movie movie);
    QString genUpdateQuery(QMap< QString, bool> updateFields, Movie movie);
    QString selectLastPkey();
    bool loadThumb(QString pKey, QPixmap* out);
    bool storeThumb(QPixmap thumb, QString pKey);
    bool removeThumb(QString pKey);
    QString esc(QString string);
    QString dbPath;
    QString dbName;
    QString dbDriver;
    QString lastError;

};
#endif // MOVIEDB_H
