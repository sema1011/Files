#ifndef TMDBSCRAPER_H
#define TMDBSCRAPER_H
#include <QXmlStreamReader>
#include <QMap>
#include "scraperinterface.h"
#include <QString>
#include "movie.h"
#include "movieheader.h"
#include "singletondownloader.h"
class TmdbScraper : public MovieScraper
{
Q_OBJECT
public:
    explicit TmdbScraper();
    /// Getter methods.
    QString getParserID();
    QString getLastError();
    QList< MovieHeader > getSearchResult();
    Movie getMovie();
    /// public slots to search for a movie and to get movie specific details
    bool search(QString movieName);
    bool downloadInfo(QString movieCode);
    QList<QPixmap> getThumbs();
    bool downloadThumbs();

private:

    bool parseMovieInfo();
    bool parseSearchResult();
    QString nameReplace(QString name);
    SingletonDownloader* downloader;
    QList< MovieHeader > results;
    Movie movie;
    QXmlStreamReader reader;
    QByteArray searchResp;
    QByteArray infoResp;
    QString apiKey;
    QString hostName;
    QString posterHostName;
    QString searchPath;
    QString infoPath;
    QString ID;
    QString lastError;
    QList <QString> thumbsUrl;
    QList <QPixmap> thumbsList;

};
#endif // TMDBSCRAPER_H
