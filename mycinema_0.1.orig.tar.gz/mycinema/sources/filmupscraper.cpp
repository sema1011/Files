
#include "filmupscraper.h"
#include <iostream>
#include <QFile>
#include <QList>
#include <QVariant>
#include <QTextStream>
#include <QRegExp>
#include <QtGlobal>
#include <QTextCodec>
#include "path.h"
#include "singletondownloader.h"
#include "loadingdialog.h"
#include <QBuffer>
//pagine in windows 1252

FilmupScraper::FilmupScraper(){
    downloader = SingletonDownloader::getInstance();

    searchResp="";
    infoResp="";
    opinionResp="";
    posterResp="";
    hostName= "http://filmup.leonardo.it";
    searchPath1= "/cgi-bin/search.cgi?ps=500&fmt=long&q=";
    searchPath2="&ul=%25/sc_%25&x=53&y=4&m=all&wf=2221&wm=wrd&sy=0";
    infoPath="/sc_";
//    opinionPath="/opinioni/op.php?uid=";
//    posterPath="/posters/locp/";
    ID="FILMUP";
    lastError = "";

}

QString FilmupScraper::getLastError(){
    return lastError;
}
Movie FilmupScraper::getMovie(){
    return this->movie;

}
QList< MovieHeader > FilmupScraper::getSearchResult(){

    return this->results;

}


bool FilmupScraper::search(QString name){
    searchResp.clear();
    if (!downloader->syncGet(hostName+searchPath1+nameReplace(name)+searchPath2,&searchResp)) {
        lastError="cannot retrieve api search response";
        return false;
    }else{
        return parseSearchResult();
    }

}

QList<QPixmap> FilmupScraper::getThumbs(){
    return this->thumbsList;
}

bool FilmupScraper::downloadThumbs(){
    thumbsList.clear();
    LoadingDialog * dialog = new LoadingDialog();
    dialog->setValues(0,thumbsUrl.length(),0);
    dialog->showIt();
    for(int i = 0; i< this->thumbsUrl.length(); i++){
        QByteArray bytes;
        downloader->syncGet(thumbsUrl.at(i),&bytes);
        QImage image;
        image.loadFromData(bytes);
        if (image.width() > 195 || image.height()>305 )image = image.scaled(195,305,Qt::KeepAspectRatio,Qt::SmoothTransformation);
        this->thumbsList.append(QPixmap::fromImage(image));
        dialog->nextStep();
    }
    dialog->close();
    delete dialog;
    emit thumbs(thumbsList);
    return true;
}

bool  FilmupScraper::downloadInfo(QString code){
    infoResp.clear();
    opinionResp.clear();
    posterResp.clear();
    if (!downloader->syncGet(hostName+infoPath+code,&infoResp)) {
        lastError="cannot retrieve api info response";
        return false;
    }else{
        QString opId = getOpinionId(infoResp);
        if(!opId.isEmpty()){
            downloader->syncGet(hostName+opId,&opinionResp);

        }
        QString posterPage = getPosterPage(infoResp);

        if(!posterPage.isEmpty()){
            downloader->syncGet(hostName+posterPage,&posterResp);
        }


        return parseMovieInfo(code);
    }

}



bool FilmupScraper::parseSearchResult(){

    results.clear();
    QBuffer buff(&searchResp);

    if (! buff.open(QIODevice::ReadOnly)) {
        lastError="Error: Cannot read search response.";
        return false;

    }
    QTextCodec *tc = QTextCodec::codecForMib(2252);
    QString* file = new QString (tc->toUnicode(buff.readAll()));

    if(file->isEmpty()){

        lastError="Can't read server response.\nThis seems to be a Connection issue.";
        delete file;
        return false;
    }


    QString next = *file;
    int i = 0;
    while (i!=  -1 ){
        QString info = getContentBetween(next,"<DT>","</DL>");
        if(!info.isEmpty()){
            QString movie ="<START>"+info+"</START>";
            //OLD VERSION OK: if( movie.indexOf("FilmUP - Scheda: " ) != -1 ){

            if( movie.indexOf("/sc_",0 ) != -1 ){
                MovieHeader header;
                QString itaName= replace(removeTags(getContentBetween(movie,"FilmUP - Scheda: ","</a>")));
                QString year = getContentBetween(movie,"Anno: "," ");
                QString origName = replace(removeTags(getContentBetween(movie,"Titolo originale: "," Nazion")));
                QString url =replace(getContentBetween(movie,"/sc_","\""));

                header.setName(origName);
                header.setAltName(itaName);
                header.setID(url);
                header.setDate(year);

                results.append(header);

            }
            next.remove(0,next.indexOf(info)+info.length());
            i++;
        }else i = -1;
    }
    if(results.isEmpty()){        lastError="No Results. Sorry.\nTry with different keywords.";
        delete file;return false;}
    else{

        delete file;

        return true;}
}





bool FilmupScraper::parseMovieInfo(QString filmupID){
    std::cerr << qPrintable(filmupID);
    movie.clear();
    QBuffer buff(&infoResp);

    if (! buff.open(QIODevice::ReadOnly)) {
        lastError="Error: Cannot read the search buffer.";
        return false;

    }

    QTextCodec *tc = QTextCodec::codecForMib(2252);
    QString* file = new QString (tc->toUnicode(buff.readAll()));
    if(file->isEmpty()){
        lastError="Connection Problem";
        delete file;
        return false;
    }else{

        movie.setOrigTitle(findTitle(*file));
        movie.setPlot(findPlot(*file));
        thumbsList.clear();
        thumbsUrl.clear();
        /// se trova il poster ad alta res usa quello come thumb, altrimenti l'immagine piccola
        if(!posterResp.isNull() && !posterResp.isEmpty()){
            QBuffer poBuff(&posterResp);
            if (! poBuff.open(QIODevice::ReadOnly)) {
                lastError="Error: Cannot read the poster page.";
            }
            QTextCodec *tc1 = QTextCodec::codecForMib(2252);
            QString* poString =new QString (tc1->toUnicode(poBuff.readAll()));
            QByteArray thumbBA;
            QString posterUrl = findPoster(*poString);
            std::cerr << qPrintable(posterUrl);
            downloader->syncGet(posterUrl,&thumbBA);
            if(!thumbBA.isEmpty()){
                thumbsUrl.append(posterUrl);
                QImage image;
                image.loadFromData(thumbBA);
                image = image.scaled(195,305,Qt::KeepAspectRatio,Qt::SmoothTransformation);
                movie.setThumb(QPixmap::fromImage(image));
            }
            poBuff.close();
            delete poString;
        }

            QString thumbUrl = findThumb(*file);
            if(!thumbUrl.isEmpty()) thumbsUrl.append(thumbUrl);
            if(movie.getThumb().isNull()){
            std::cerr << qPrintable(thumbUrl);
            QByteArray thumbBA;
            downloader->syncGet(thumbUrl,&thumbBA);
            if(!thumbBA.isEmpty()){
                QImage image;
                image.loadFromData(thumbBA);
                movie.setThumb(QPixmap::fromImage(image));

            }
        }
        movie.setCountry(findCountry(*file));
        movie.setGenre(findGenre(*file));
        movie.setDate(findDate(*file));
        movie.setTime(findTime(*file));
        movie.setDirector(findDirector(*file));
        movie.setCast(findCast(*file));
        movie.setPage("http://filmup.leonardo.it/sc_"+filmupID+"");
        if(!opinionResp.isEmpty() && !opinionResp.isNull()){
            QBuffer opBuff(&opinionResp);
            if (! opBuff.open(QIODevice::ReadOnly)) {
                lastError= "Error: Cannot read the opinion page";

            }
            QTextCodec *tc2 = QTextCodec::codecForMib(2252);
            QString* opString =new QString (tc2->toUnicode(opBuff.readAll()));;

            movie.setRating(findRating(*opString));
            opBuff.close();
            delete opString;
        }
        if(opinionResp.isEmpty())std::cerr << "opinion page empty";
        //movie.setCode(this->getParserID()+"_"+movieCode);

        buff.close();
        delete file;
        return true;
    }
}


QString FilmupScraper::getContentBetween(QString source, QString startStr, QString endStr){

    int start = source.indexOf(startStr);
    if(start != -1){
        source.remove(0,start+startStr.length());
        int end = source.indexOf(endStr);
        if (end != -1){
            source.remove(end,source.length()-end);
            return source;
        }else return "";

    }else return "";
}
QString FilmupScraper::removeTags(QString source){
    int go = 0;
    while (go != -1){
        int start = source.indexOf("<");
        if (start != -1){
            int end = source.indexOf(">");
            if(end != -1)source.remove(start,end-start+1);
            else go = -1;
        }else go = -1;
    }
    return source;

}

QString FilmupScraper::findTitle(QString searchFile){
    // replace (removeTags(getContentBetween(searchFile,"Titolo originale:&nbsp;</font></td>","</font></td>")));
    return replace (removeTags(getContentBetween(searchFile,"Titolo originale:&nbsp;</font></td>","</font></td>")));

}

QString FilmupScraper::findPlot(QString searchFile){

    return replace (removeTags(getContentBetween(searchFile,"Trama:<br>","</font><br>")));
}

QString FilmupScraper::findPoster(QString searchFile){

    return "http://filmup.leonardo.it/posters/loc"+replace (removeTags(getContentBetween(searchFile,"/loc","\"")));

}
QString FilmupScraper::findThumb(QString searchFile){

    return "http://filmup.leonardo.it/locand/"+replace(removeTags(getContentBetween(searchFile,"<img src=\"locand/","\"")));

}
QString FilmupScraper::findCountry(QString searchFile){

    return replace (removeTags(getContentBetween(searchFile,"Nazione:&nbsp;</font></td>","</font></td>")));
}

QString FilmupScraper::findDate(QString searchFile){

    QString date = removeTags(getContentBetween(searchFile,"Data di uscita:&nbsp;</font></td>","</font></td>"));
    if (date.isEmpty()){
        date = removeTags(getContentBetween(searchFile,"Uscita prevista:&nbsp;</font></td>","</font></td>"));
    }
    //movieData.insert(2,replace(removeTags(getContentBetween(*file,"Anno:&nbsp;</font></td>","</font></td>"))));

    return dateParser(replace (date));
}

QString FilmupScraper::findGenre(QString searchFile){

    return replace (removeTags(getContentBetween(searchFile,"Genere:&nbsp;</font></td>","</font></td>")));

}
QString FilmupScraper::findDirector(QString searchFile){

    return replace (removeTags(getContentBetween(searchFile,"Regia:&nbsp;</font></td>","</font></td>")));
}

QString FilmupScraper::findCast(QString searchFile){
    QString cast = replace (removeTags(getContentBetween(searchFile,"Cast:&nbsp;</font></td>","</font></td>")));
    if (cast.isEmpty()) cast =replace (removeTags(getContentBetween(searchFile,"Cast:&nbsp; (voci)</font></td>","</font></td>")));
    if (cast.isEmpty()) cast =replace (removeTags(getContentBetween(searchFile,"Cast (voci):&nbsp;</font></td>","</font></td>")));
    if (cast.isEmpty()) cast =replace (removeTags(getContentBetween(searchFile,"Voci originali:&nbsp;</font></td>","</font></td>")));
    return cast;
}

QString FilmupScraper::findTime(QString searchFile){

    return replace (removeTags(getContentBetween(searchFile,"Durata:&nbsp;</font></td>","</font></td>")));
}
QString FilmupScraper::findRating(QString searchFile){
    std::cerr << qPrintable(searchFile);
    return replace (removeTags(getContentBetween(searchFile,"Media Voto:&nbsp;&nbsp;&nbsp;</td>","</b>")));
}
QString FilmupScraper::getOpinionId(QByteArray infoPage){

    QBuffer buff(&infoPage);

    if (! buff.open(QIODevice::ReadOnly)) {
        lastError="Error: Cannot read the opinion buffer.";
        return "";

    }
    //   QByteArray bytes;
    //    bytes = buff.buffer();

    QTextCodec *tc = QTextCodec::codecForMib(2252);
    QString* file = new QString (tc->toUnicode(buff.readAll()));
    QString id = getContentBetween(*file,"op.php?uid=","\"");
    buff.close();
    if(!id.isEmpty()){
        delete file;
        return "/opinioni/op.php?uid="+id;

    }else{
        QString id = getContentBetween(*file,"op_",".htm");
        delete file;
        if(!id.isEmpty())return "/op_"+id+".htm";
        return "";
    }

}
QString FilmupScraper::getPosterPage(QByteArray infoPage){
    QBuffer buff(&infoPage);

    if (! buff.open(QIODevice::ReadOnly)) {
        lastError="Error: Cannot read the opinion buffer.";
        return "";

    }


    QTextCodec *tc = QTextCodec::codecForMib(2252);
    QString* file = new QString (tc->toUnicode(buff.readAll()));
    QString pageName = getContentBetween(*file,"posters/locp/","\"");
    buff.close();
    delete file;
    if(!pageName.isEmpty())return "/posters/locp/"+pageName;
    else return "";

}

QString FilmupScraper::replace(QString source){
    int loop = 0;
    while(loop != -1){
        if(source.indexOf("\n")==0)source.remove(0,1);
        else loop = -1;
    }
    loop =0;
    //QVariant v = source.length();
    //std::cerr << "|NAME:"<<qPrintable(source)<< "INOF:" << qPrintable(v.toString())<<"|";
    while(loop != -1){
        if(source.endsWith("\n")|| source.endsWith(" ")){

            source.remove(source.length()-1,1);
        }
        else loop = -1;
    }

    source.replace("&nbsp;","");
    source.replace("&#38;","&");

    return source;
}

QString FilmupScraper::dateParser(QString date){


    QList<QString> monthList;
    monthList.append("Gennaio");
    monthList.append("gennaio");
    monthList.append("Febbraio");
    monthList.append("febbraio");
    monthList.append("Marzo");
    monthList.append("marzo");
    monthList.append("Aprile");
    monthList.append("aprile");
    monthList.append("Maggio");
    monthList.append("maggio");
    monthList.append("Giugno");
    monthList.append("giugno");
    monthList.append("Luglio");
    monthList.append("luglio");
    monthList.append("Agosto");
    monthList.append("agosto");
    monthList.append("Settembre");
    monthList.append("settembre");
    monthList.append("Ottobre");
    monthList.append("ottobre");
    monthList.append("Novembre");
    monthList.append("novembre");
    monthList.append("Dicembre");
    monthList.append("dicembre");
    int monthIndex=-1;

    for(int i =0;i < monthList.length();i++){
        if(date.indexOf(monthList.at(i)) != -1) {
            monthIndex= date.indexOf(monthList.at(i));
            i = 100;
        }
    }
    if(monthIndex == -1)return "";
    QString day;
    QString d = "23";
    if(monthIndex >2){
        if( date.at(monthIndex-3) == d.at(0) || date.at(monthIndex-3) == d.at(1) ) day.append(date.at(monthIndex-3));
        else day.append("0");
        day.append(date.at(monthIndex-2));

    }else {
        day=date;
        day.remove(monthIndex-1,day.length()-(monthIndex-1));

    }
    date.remove(0,monthIndex);
    int yearStart= date.indexOf(" ");
    QString year;
    year.append(date.at(yearStart+1));
    year.append(date.at(yearStart+2));
    year.append(date.at(yearStart+3));
    year.append(date.at(yearStart+4));
    std::cerr << qPrintable(date);

    QString month= date.remove(yearStart,date.length()-yearStart);
    QString monthNumber="";

    if(month == "Gennaio" || month == "gennaio") monthNumber = "01";
    if(month == "Febbraio" || month == "febbraio") monthNumber = "02";
    if(month == "Marzo" || month == "marzo") monthNumber = "03";
    if(month == "Aprile" || month == "aprile") monthNumber = "04";
    if(month == "Maggio" || month == "maggio") monthNumber = "05";
    if(month == "Giugno" || month == "giugno") monthNumber = "06";
    if(month == "Luglio" || month == "luglio") monthNumber = "07";
    if(month == "Agosto" || month == "agosto") monthNumber = "08";
    if(month == "Settembre" || month == "settembre") monthNumber = "09";
    if(month == "Ottobre" || month == "ottobre") monthNumber = "10";
    if(month == "Novembre" || month == "novembre") monthNumber = "11";
    if(month == "Dicembre" || month == "dicembre") monthNumber = "12";


    return year+"-"+monthNumber+"-"+day+"  (Italia)";


}



QString FilmupScraper::getParserID(){
    return ID;
}

QString FilmupScraper::nameReplace(QString name){

    for(int i=0; i<name.length();i++){

        if((name.at(i)).isSpace()){

            name.replace(i,1,"%20");}

        if(((QString)name.at(i)).toUtf8()=="ò" || ((QString)name.at(i)).toUtf8()=="ó" ){

            name.replace(i,1,"o");}

        if(((QString)name.at(i)).toUtf8()=="à"){
            name.replace(i,1,"a");}

        if(((QString)name.at(i)).toUtf8()=="è" || ((QString)name.at(i)).toUtf8()=="é" ){
            name.replace(i,1,"e");}

        if(((QString)name.at(i)).toUtf8()=="ì" ){
            name.replace(i,1,"i");}

        if(((QString)name.at(i)).toUtf8()=="ù" ){
            name.replace(i,1,"u");}

    }

    return name;
}



