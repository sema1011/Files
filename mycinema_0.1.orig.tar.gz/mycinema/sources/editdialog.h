#ifndef EDITDIALOG_H
#define EDITDIALOG_H

#include <QDialog>
#include <QMap>
#include "movie.h"
namespace Ui {
    class EditDialog;
}

class EditDialog : public QDialog {
    Q_OBJECT
public:
    EditDialog(QWidget *parent = 0);
    ~EditDialog();
    bool populateField(QString key, Movie movie);
    bool loadThumbFromFile(QString fileName);

private slots:
    void on_cancelButton_clicked();
    void on_saveButton_clicked();
    void on_fileRadio_clicked();
    void on_dvdRadio_clicked();
    void on_editThumbBox_clicked();
    void on_browseButton_clicked();
    void on_bdRadio_clicked();
signals:
    void updateMovie( QMap< QString, bool > updateFields, QString pkey, Movie movie);
    void deleteMe(EditDialog * dialog);
protected:
    void closeEvent ( QCloseEvent * e );
    void changeEvent(QEvent *e);

private:
    QPixmap origThumb;
    QString pkey;
    QMap< QString, bool > updateFields;

    Ui::EditDialog *ui;
};

#endif // EditDialog_H
