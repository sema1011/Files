#ifndef MyCinema_H
#define MyCinema_H

#include <QMainWindow>
#include "resultdialog.h"
#include <QWidget>
#include <QTextEdit>
#include "db.h"
#include "tmdbscraper.h"
#include "filmupscraper.h"
#include "scraperinterface.h"
#include "scraperfactory.h"
#include "loadingdialog.h"
#include "editdialog.h"
#include "detailsdialog.h"
#include "adddialog.h"
#include "proxydialog.h"
#include "aboutdialog.h"
#include "singletondownloader.h"
namespace Ui {
    class MyCinema;
}

class MyCinema : public QMainWindow
{
    Q_OBJECT

public:
    explicit MyCinema(QWidget *parent = 0);
    ~MyCinema();
protected:
    void changeEvent(QEvent *e);
    void closeEvent ( QCloseEvent * e );

public slots:
    void setScraper (QString parserName);
    void on_comboBox_currentIndexChanged(QString index);
    void selChanged(QModelIndex a, QModelIndex b);
    void localSearch(QString keyWord);
    void onlineSearch(QString keyWord);
    void deleteThis(DetailsDialog * dialog);
    void deleteThis(EditDialog * dialog);
    void deleteThis(AddDialog * dialog);
    void refreshPkey(bool done,QString error,QString pKey);

signals:
    void popupDetails(QMap<int, QString> movieData);

private slots:
    void showInfo(QString pKey);
    int pKey2Row(QString pKey);
    void fillQuotesPool();
    QString getRandomQuote();
    void add();
    void about();
    void remove();
    void help();
    void setProxy();
    void import();
   // void on_setProxyButton_clicked();
    bool list();
    void on_categoryCombo_currentIndexChanged(QString index);
    void on_formatCombo_currentIndexChanged(QString index);
    void on_hdBox_clicked();
    void on_getstoreButton_clicked();
    //void on_proxyCheck_clicked();
    bool on_searchButton_clicked();
    void edit();

private:
    QString formatView;
    QString categoryView;
    QString hdView;
    QList <QString> quotesPool;
    bool backgroundParsing;
    int backgroundCurrInd;
    QModelIndexList backgroundIndexList;
    ProxyDialog * proxyDialog;
    QString getCurrentView();
    void refresh(QString queryStr);
    void centerWidget( QWidget * w);
    void selectMovie(int row);
    void updateSearchText(int currRow);
    QList<QLabel*> frames;
    Ui::MyCinema *ui;
    Db* movieDb;
    QString proxy;
    unsigned int port;
    QString currView;
    QSqlQueryModel model;
    QSortFilterProxyModel proxyModel;
    MovieScraper * scraper;

};

#endif // MyCinema_H
