#!/usr/bin/env python2

from distutils.core import setup

setup(name='ObFileBrowser',
      version='2011.06.16.1',
      description='Generate file browser pipe menus for Openbox.',
      author='Xyne',
      author_email='ac xunilhcra enyx, backwards',
      url='http://xyne.archlinux.ca/projects/obfilebrowser',
      py_modules=['ObFileBrowser'],
     )
