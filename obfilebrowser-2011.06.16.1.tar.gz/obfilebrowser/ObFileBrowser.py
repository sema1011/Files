#!/usr/bin/env python2

# Copyright (C) 2009,2010,2011  Xyne
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# (version 2) as published by the Free Software Foundation.
#
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# METADATA
# Version: 2.0

import os, sqlite3, errno
from argparse import ArgumentParser, Action
from Mimeo import Mimeo, Desktop, DEG, quote_command, split_list, get_paths
from sys import argv, exit, stderr
from time import time
from xml.dom.minidom import getDOMImplementation, Document

# from pwd import getpwuid
# from grp import getgrgid
# from time import localtime, strftime

UNKNOWN_MIMETYPE = 'unknown/mimetype'

# TIMEFMT = '%Y-%m-%d %H:%M:%S'
#
# def format_time(t):
#   return strftime(TIMEFMT, localtime(t))
#
# def format_bytes(bytes):
#   if bytes < 0x400:
#     return "%d B" % bytes
#
#   bytes = float(bytes) / 0x400
#
#   suffixes = ('KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB')
#   for suffix in suffixes:
#     if bytes < 0x400:
#       return "%0.2f %s" % (bytes, suffix)
#     else:
#       bytes /= 0x400
#
#   return "%0.2f 'YiB'" % bytes


class PipeMenu():

  # implementation, from getDOMImplementation()
  def __init__(self, implementation, element="openbox_pipe_menu"):
    self.doc = implementation.createDocument(None, element, None)



  def __str__(self):
    return self.doc.documentElement.toprettyxml(indent='  ')



  # Escape underscores.
  def escape_label(self, label):
    return label.replace('_', '__')



  def clear(self):
    for child in self.doc.documentElement.childNodes:
      self.doc.documentElement.removeChild(child)



  def add_separator(self, label=None):
    sep = self.doc.createElement('separator')
    if label:
      sep.setAttribute('label', self.escape_label(label))
    self.doc.documentElement.appendChild(sep)



  # An empty menu will be replaced by one with the matching ID in Openbox.
  def add_menu(self, id, label, menu=None):
    if menu:
      if isinstance(menu, Document):
        menu = menu.documentElement

      elif isinstance(menu, PipeMenu):
        menu = menu.doc.documentElement

      menu.tagName = 'menu'
      if menu.hasAttributes():
        for attr in menu.attributes:
          menu.removeAttribute(attr)
    else:
      menu = self.doc.createElement('menu')
    menu.setAttribute('id', "menu: %s" % id)
    menu.setAttribute('label', self.escape_label(label))
    self.doc.documentElement.appendChild(menu)



  def add_pipe_menu(self, id, label, execute):
    menu = self.doc.createElement('menu')
    menu.setAttribute('id', "pipemenu: %s" % id)
    menu.setAttribute('label', self.escape_label(label))
    menu.setAttribute('execute', execute)
    self.doc.documentElement.appendChild(menu)



  def add_command(self, label, command_str, startup_notify=False):
    item = self.doc.createElement('item')
    item.setAttribute('label', self.escape_label(label))
    action = self.doc.createElement('action')
    action.setAttribute('name', 'Execute')
    command = self.doc.createElement('command')
    cmd = self.doc.createTextNode(command_str)

    command.appendChild(cmd)
    action.appendChild(command)

    # startup notification
    if startup_notify:
      startupnotify = self.doc.createElement('startupnotify')
      enabled = self.doc.createElement('enabled')
      yes = self.doc.createTextNode('yes')
      enabled.appendChild(yes)
      startupnotify.appendChild(enabled)
      action.appendChild(startupnotify)

    item.appendChild(action)
    self.doc.documentElement.appendChild(item)



  def add_text(self, text):
    item = self.doc.createElement('item')
    item.setAttribute('label', self.escape_label(text))
    self.doc.documentElement.appendChild(item)





class ObFileBrowser():

  # implementation, from getDOMImplementation()
  # mimeo is an instance of Mimeo
  # show_hidden: do not display hidden items
  # show_parent: suppress link to parent
  # show_self: suppress menu for target directory
  def __init__(self, implementation, mimeo, cmd, show_hidden=True, show_parent=True, show_self=True, commands=[]):
    self.impl = implementation
    self.mimeo = mimeo
    self.cmd = cmd
    self.show_hidden = show_hidden
    self.show_parent = show_parent
    self.show_self = show_self
    self.commands = commands


  def parse_command(self, command, fpath):

    while '%FILEPATH%' in command:
      command = command.replace('%FILEPATH%', fpath)

    if '%MIMETYPE%' in command:
      mimetype = self.mimeo.get_mimetype(fpath)
      if not mimetype:
        mimetype = UNKNOWN_MIMETYPE
      command = command.replace('%MIMETYPE%', mimetype)
      while '%MIMETYPE%' in command:
        command = command.replace('%MIMETYPE%', mimetype)

    return command



  def launcher_menu(self, fpath):
    mimeo = self.mimeo
    is_empty = True
    add_sep = True

    menu = PipeMenu(self.impl)

    custom_launcher = mimeo.get_custom_launcher(fpath)
    if custom_launcher:
      desktop = Desktop()
      desktop[DEG]['Exec'] = custom_launcher
      cmds = desktop.parse_exec_key([fpath])
      if cmds:
        if add_sep:
          menu.add_separator('Open with')
          add_sep = False
        menu.add_command('Custom Launcher', cmds[0])
        is_empty = False

    mimetype = mimeo.get_mimetype(fpath)
    if mimetype:
      for desktop_name in mimeo.get_associated_desktop_names(mimetype):
        desktop = mimeo.get_desktop(desktop_name)
        if desktop:
          if add_sep:
            menu.add_separator('Open with')
            add_sep = False
          cmds = desktop.parse_exec_key([fpath])
          if cmds:
            menu.add_command(desktop[DEG]['Name'], cmds[0], desktop[DEG]['StartupNotify'])
            is_empty = False

    if os.path.isfile(fpath) and os.access(fpath, os.X_OK):
      menu.add_separator('Run')
      menu.add_command('directly', fpath)
      cmd = mimeo.use_term(fpath)
      if cmd:
        menu.add_command('in terminal', cmd)
      is_empty = False

    if self.commands:
      menu.add_separator('Custom')
      for name, command in self.commands:
        command = self.parse_command(command, fpath)
        menu.add_command(name, command)
        is_empty = False

#     menu.add_separator('Info')
#     stat = os.stat(fpath)
#     menu.add_text("%o %d %s:%s %s" % (\
#       stat.st_mode, \
#       stat.st_nlink, \
#       getpwuid(stat.st_uid)[0], \
#       getgrgid(stat.st_gid)[0], \
#       format_bytes(stat.st_size)))
# #    menu.add_text("atime: %s" % format_time(stat.st_atime))
# #    menu.add_text("mtime: %s" % format_time(stat.st_mtime))

    return menu



  def pipe_menu(self, path):
    path = os.path.abspath(path)
    menu = PipeMenu(self.impl)
    menu.add_separator(path)

    # Track additions that require a separator if the following item is present.
    add_sep = False

    if os.path.isdir(path):

      # directories, hidden directories, files, hidden files
      dirs = []
      hdirs = []
      files = []
      hfiles = []

      try:
        for item in sorted(os.listdir(path)):
          fpath = os.path.join(path, item)

          if item[0] == '.':
            if not self.show_hidden:
              continue
            else:
              if os.path.isdir(fpath):
                hdirs.append((fpath, item))
              else:
                hfiles.append((fpath, item))
          else:
            if os.path.isdir(fpath):
              dirs.append((fpath, item))
            else:
              files.append((fpath, item))
      # Ignore paths that we cannot read.
      except OSError as e:
        if e.errno == errno.EACCES:
          pass
        else:
          raise e


      if self.show_parent:
        parent = os.path.abspath( os.path.join(path, '..') )
        if parent != path:
          cmd = quote_command(self.cmd + [parent])
#          menu.add_pipe_menu(parent, '..', cmd)

          pname = os.path.basename(parent)
          if not pname:
            pname = '/'
          menu.add_pipe_menu(parent, pname, cmd)
          add_sep = True


      if self.show_self:
        menu.add_menu(path, '.', self.launcher_menu(path))
        add_sep = True


      if self.show_hidden and (hdirs or hfiles):
        hidden = PipeMenu(self.impl)
        hidden.add_separator("Hidden")

        if hdirs:
          for fpath, item in hdirs:
            cmd = quote_command(self.cmd + [fpath])
            hidden.add_pipe_menu(fpath, item, cmd)

        if files:
          if hdirs:
            menu.add_separator()
          for fpath, item in hfiles:
            hidden.add_menu(fpath, item, self.launcher_menu(fpath))

        menu.add_menu("hidden: %s" % path, 'hidden', hidden)



      if dirs:
        #if add_sep:
        menu.add_separator('Dirs')
        add_sep = True
        for fpath, item in dirs:
          cmd = quote_command(self.cmd + [fpath])
          menu.add_pipe_menu(fpath, item, cmd)


      if files:
        #if add_sep:
        menu.add_separator('Files')
        add_sep = True
        for fpath, item in files:
          menu.add_menu(fpath, item, self.launcher_menu(fpath))


    else:
      menu.add_menu(path, os.path.basename(path), self.launcher_menu(path))


    return menu





# Display a menu of all Desktop entries, sorted by name and by category.
class ObDesktopBrowser():
  def __init__(self, impl, mimeo, obfb_cmd, load=False):
    self.impl = impl
    self.mimeo = mimeo
    self.id = 'ObDesktopBrowser'
    self.seen = set()
    self.menu = PipeMenu(self.impl)
    self.obfb_cmd = obfb_cmd

    if load:
      self.load()



  def __str__(self):
    return str(self.menu)


  def get_key(self, tup):
    return tup[0].lower()



  def load(self):
    self.menu.clear()

    names = []
    cats = {}

    for desktop_name in self.mimeo.list_desktops():
      desktop = self.mimeo.get_desktop(desktop_name)
      if not desktop or desktop[DEG]['NoDisplay']:
        continue

      name = desktop[DEG].get_localized('Name')
      pair = (name, desktop)
      names.append(pair)

      for cat in desktop[DEG]['Categories']:
        try:
          cats[cat].append(pair)
        except KeyError:
          cats[cat] = [pair]

    self.names = sorted(names, key=self.get_key)
    for cat in cats:
      cats[cat] = sorted(cats[cat], key=self.get_key)
    self.cats = cats





    # Sorted by name.
    name_menu = PipeMenu(self.impl)
    name_menu.add_separator('Names')

    subname_menu = None
    c = None
    for name, desktop in self.names:
      d = name[0].lower()
      if d != c:
        # Add the previous submenu.
        if subname_menu:
          name_menu.add_menu('%s: letter %s' % (self.id, c), c, subname_menu)

        # Create a new submenu for this letter.
        subname_menu = PipeMenu(self.impl)
        subname_menu.add_separator(d)
        c = d

      dmenu = self.desktop_launcher(desktop)
      subname_menu.add_menu('%s: %s' % (self.id, desktop.get_file_path()), name, dmenu)

    if subname_menu:
      name_menu.add_menu('%s: letter %s' % (self.id, c), c, subname_menu)



    # Sorted by category
    cat_menu = PipeMenu(self.impl)
    cat_menu.add_separator('Categories')
    for cat, desktops in sorted(self.cats.iteritems(), key=self.get_key):
      menu = PipeMenu(self.impl)
      menu.add_separator(cat)
      for name, desktop in desktops:
        dmenu = self.desktop_launcher(desktop)
        menu.add_menu('%s: %s' % (self.id, desktop.get_file_path()), name, dmenu)
      cat_menu.add_menu('%s: category %s' % (self.id, cat), cat, menu)



    self.menu.add_separator('Desktop Entries')
    self.menu.add_menu('%s: Names' % (self.id), 'Names', name_menu)
    self.menu.add_menu('%s: Categories' % (self.id), 'Categories', cat_menu)





  def desktop_launcher(self, desktop):
    fpath = desktop.get_file_path()
    menu = PipeMenu(self.impl)

    if not fpath in self.seen:
      name = desktop[DEG].get_localized('Name')
      gen_name = desktop[DEG].get_localized('GenericName')
      comment = desktop[DEG].get_localized('Comment')
      notify = desktop[DEG]['StartupNotify']
      term = desktop[DEG]['Terminal']

      menu.add_separator(name)

      cmd = desktop.parse_exec_key()[0]
      if term:
        cmd = self.mimeo.use_term(cmd)
        if cmd:
          menu.add_command(cmd, cmd, notify)
        else:
          menu.add_text('error: terminal required')
      else:
        menu.add_command(cmd, cmd, notify)

      menu.add_separator('Description')
      if gen_name:
        menu.add_text(gen_name)
      if comment:
        menu.add_text(comment)

      menu.add_separator('Location')
      obfb_cmd = quote_command(self.obfb_cmd + [fpath])
      menu.add_pipe_menu('%s: launcher %s' % (self.id, fpath), fpath, obfb_cmd)



      self.seen.add(fpath)

    return menu


class DisplayCommandHelp(Action):
  def __call__(self, parser, namespace, values, option_string=None):
    print '''OPENBOX MENU EXAMPLE
  The following line can be added to an Openbox menu in menu.xml to include an
  ObFileBrowser menu that opens the user's home directory and uses urxvtc to
  open any terminal applications.

  <menu id="obfb-home" label="home" execute="obfilebrowser ~ --term 'urxvtc -e %s'" />



COMMANDS
  Custom commands can be added to the Exec menu for files and directories using
  "--command <name> <command>". This may be expanded in the future, depending
  on feedback.

  <name>
    The name to display in the menu.

  <command>
    The command to execute. Substrings will be replaced as follows:

      %FILEPATH%
        The full filepath.

      %MIMETYPE%
        The detected mimetype.

  Examples
    Move files to a trash directory:
      --command trash 'mv "%FILEPATH%" -t /path/to/trash'

    Copy the file path to the clipboard:
      --command 'copy path' 'sh -c "echo \"%FILEPATH%\" | xsel -ib"'

    Note the use of "sh -c" due to the pipe. Openbox does not recognize pipes
    and other redirections so they must be wrapped.
'''
    exit(0)


def main():
  # For recursive invocations.
  cmd = None
  argv[0] = os.path.abspath(argv[0])
  if os.access(argv[0], os.X_OK):
    cmd = [argv[0]]
  else:
    cmd = ['python2', sys.argv[0]]


  parser = ArgumentParser(description='Browse and open files using Openbox pipe menus.')

  parser.add_argument('fpath', metavar='<filepath>', default='.', nargs='?',
    help='The path to a file or directory.')

  parser.add_argument('--no-parent', dest='parent', action='store_false',
    help='Remove the ".." entry from the initial directory.')

  parser.add_argument('--no-self', dest='self', action='store_false',
    help='Remove the "." launcher menu from the initial directory.')

  parser.add_argument('--no-hidden', dest='hidden', action='store_false',
    help='Remove the "hidden" menu containing hidden files and directories.')

  parser.add_argument('--assoc', dest='assoc', default=[], metavar='<filepath>', action='append',
    help='Paths to Mimeo association files. See Mimeo\'s documentation for details.')

  parser.add_argument('--term', dest='term', metavar='<cmd>', action='store',
    help='Specify a terminal command. See Mimeo\'s documentation for details.')

  parser.add_argument('--command', dest='commands', default=[], nargs=2, metavar=('<name>', '<command>'), action='append',
    help='Custom commands to add to every Exec menu. See "--more-help" for details.')

  parser.add_argument('--more-help', nargs=0, action=DisplayCommandHelp,
    help='Display more information.')

  parser.add_argument('--desktop-menu', dest='desktop_menu', action='store_true',
    help='Display desktop entries sorted by name and category.')

  parser.add_argument('--cache', dest='cache', action='store_true',
    help='Cache menus in a database to speed up subsequent browsing. This should detect changes in target directories and MIME-type associations.')

  parser.add_argument('--delete-cache', dest='delete_cache', action='store_true',
    help='Delete the cache database.')

  options = parser.parse_args()

  # Add arguments to recursive invocation command. Skip "--no-self" and
  # "--no-parent" as they only apply to the initial directory.
  if not options.hidden:
    cmd.append('--no-hidden')

  for assoc in options.assoc:
    cmd.append('--assoc')
    cmd.append(assoc)

  if options.term:
    cmd.append('--term')
    cmd.append(options.term)

  for name, command in options.commands:
    cmd.append('--command')
    cmd.append(name)
    cmd.append(command)

  if options.cache:
    cmd.append('--cache')


  dbpath = None
  if options.cache or options.delete_cache:
    caches = get_paths('XDG_CACHE_HOME')
    if not caches:
      stderr.write("error: $XDG_CACHE_HOME must be set to use caching\n")
      exit(1)
    dbpath = os.path.join(caches[0], 'obfilebrowser.sqlite')
    try:
      os.makedirs( os.path.dirname(dbpath) )
    except OSError:
      pass

    if options.delete_cache:
      if os.path.isfile(dbpath):
        try:
          os.remove(dbpath)
        except OSError as e:
          stderr('error: failed to delete cache (%s): %s' % (dbpath, e))
          exit(1)
      exit()




  ##############################################################################
  # Simple caching
  ##############################################################################

  # Store menus in a database using the command arguments as a unique id.
  #
  # This needs to track not only the directores containing the target files,
  # but also the XDG data directories, including the desktop files and MIME
  # data files themselves.
  #
  # The benefits of caching are debatable. It's a little bit faster, but I was
  # mostly just curious to see how it would work.

  conn = None
  c = None

  if options.cache and dbpath:
    try:
      if cmd[0] == 'python2':
        menu_id = cmd[1:]
      else:
        menu_id = cmd
      menu_id = unicode(quote_command(menu_id + [options.fpath]), 'utf-8')
      conn = sqlite3.connect(dbpath)
      conn.text_factory=str
      c = conn.cursor()

      # Create the tables if necessary
      if not c.execute("select 1 from sqlite_master where type='table' and name='menus'").fetchone():
        c.execute('create table menus (id text primary key, xml text, paths text, mtime integer)')
        conn.commit()
      if not c.execute("select 1 from sqlite_master where type='table' and name='mimefiles'").fetchone():
        c.execute('create table mimefiles (path text primary key)')
        conn.commit()

      c.execute('select xml, paths, mtime from menus where id=?', (menu_id,))
      row = c.fetchone()
      if row:
        is_old = False
        minimum_mtime = 0
        xml, paths, mtime = row

        # Check MIME data
        # If this fails, it will be updated below
        rows = c.execute('select path from mimefiles')
        for path in rows:
          try:
            stat = os.stat(path[0])
            if stat.st_mtime > mtime:
              minimum_mtime = stat.st_mtime
              is_old = True
              break
          except OSError:
            minimum_mtime = time()
            is_old = True
            break

        # Check the paths
        if not is_old:
          if not paths:
            paths = []
          else:
            paths = split_list(paths, sep=os.pathsep)
          # Check for changes.
          for path in paths:
            try:
              stat = os.stat(path)
              # It's newer.
              if stat.st_mtime > mtime:
                break
            except OSError:
              # It no longer exists.
              break
          else:
            print xml
            exit()

        # This section is only executed if the entry is old.
        # This should also clean up leftover entries in the database.
        c.execute('delete from menus where id=? or mtime<?', (menu_id,minimum_mtime))
        conn.commit()

    except sqlite3.OperationalError as e:
      stderr.write('sqlite3.OperationalError: %s (%s)' % (e, dbpath))
      exit(1)





  ##############################################################################
  # Create new menus
  ##############################################################################
  impl = getDOMImplementation()

  mimeo = Mimeo(options.term)
  for assoc in options.assoc:
    mimeo.load_launchers(assoc)

  menu_xml = '';
  fpaths = []

  # Custom menus
  if options.desktop_menu:
    # Speed up display by caching the menu.
    fpaths = map(lambda x: os.path.join(x, 'obdesktopbrowser_menu.xml'), get_paths('XDG_CACHE_HOME'))
    cache_path = None
    cache_mtime = None
    for fpath in fpaths:
      if os.path.isfile(fpath):
        cache_path = fpath
        cache_mtime = os.path.getmtime(cache_path)

    last_update = 0
    if cache_mtime:
      for app_dir in mimeo.app_dirs:
        fpath = os.path.join(app_dir, 'mimeinfo.cache')
        if os.path.isfile(fpath):
          mtime = os.path.getmtime(fpath)
          if last_update < mtime:
            last_update = mtime


    if cache_mtime and cache_mtime > last_update:
      f = open(cache_path, 'r')
      menu_xml = f.read()
      f.close()
    else:
      menu_xml = ObDesktopBrowser(impl, mimeo, cmd, True)
      if not cache_path and fpaths:
        cache_path = fpaths[0]
      if cache_path:
        f = open(cache_path, 'w')
        f.write(str(menu_xml))
        f.close()

  else:
    obfb = ObFileBrowser(impl, mimeo, cmd, options.hidden, options.parent, options.self, options.commands)
    menu_xml = obfb.pipe_menu(options.fpath)
    # The target path must also be checked.
    fpaths.append(options.fpath)

  print menu_xml



  ##############################################################################
  # Update the database if we're still here.
  ##############################################################################

  if options.cache:
    try:
      # Addition or removal of MIME data and desktop files must be tracked, and
      # also modification of the files themselves.
      c.execute('delete from mimefiles')
      for app_dir in mimeo.app_dirs:
        for dirpath, dirnames, filenames in os.walk(app_dir, followlinks=True):
          paths = [(dirpath,)]
          paths.extend( map(lambda x: (os.path.join(dirpath, x),), filenames) )
          c.executemany('insert into mimefiles (path) values (?)', paths)

      menu_xml = unicode(str(menu_xml), 'utf-8')
      mtime = time()
      fpaths = os.pathsep.join(fpaths)
      c.execute('insert into menus (id, xml, paths, mtime) values (?,?,?,?)', (menu_id, menu_xml, fpaths, mtime))
      c.close()
      conn.commit()

    except sqlite3.OperationalError as e:
      stderr.write('sqlite3.OperationalError: %s (%s)' % (e, dbpath))
      exit(1)


if __name__ == "__main__":
  main()