#-*- coding:utf-8 -*-


#===============================================================================
# Application : Curlew multimedia converter
# Author: Chamekh Fayssal <chamfay@gmail.com>
# License: Waqf license, see: http://www.ojuba.org/wiki/doku.php/waqf/license
#===============================================================================


try:
    import sys
    import os
    import re
    import time
    from subprocess import Popen, PIPE, call
    from os.path import basename, isdir, splitext, join, dirname, realpath, \
    isfile
    from ConfigParser import ConfigParser, NoOptionError, NoSectionError
    from urllib import unquote
    from gi.repository import Gtk, GLib, Gdk
    
    from customwidgets import LabeledHBox, TimeLayout, LabeledComboEntry, \
    CustomHScale
    from about import APP_NAME, APP_VERSION, About
    from functions import show_message, extract_font_name, get_format_size, \
    duration_to_time, time_to_duration
    
except Exception as detail:
    print(detail)
    sys.exit(1)

APP_DIR      = dirname(realpath(__file__))
HOME         = os.getenv("HOME")
TEN_SECONDS  = '10'
OPTS_FILE    = join(HOME, '.curlew.cfg')
PASS_LOG     = '/tmp/pass1log'
PASS_1_FILE  = '/tmp/pass1file'
PREVIEW_FILE = '/tmp/preview'


# Treeview cols nbrs
C_SKIP = 0             # Skip (checkbox)
C_NAME = 1             # File name
C_DURA = 2             # Duration
C_SIZE = 3             # Estimated output size
C_REMN = 4             # Remaining time
C_PRGR = 5             # Progress value
C_STAT = 6             # Stat string
C_PULS = 7             # Pulse
C_FILE = 8             # complete file name /path/file.ext


def create_tool_btn(icon_name, tooltip, callback):
    ''' Build custom toolbutton '''
    toolbtn = Gtk.ToolButton()
    widget = Gtk.Image.new_from_file(join(APP_DIR, 'data', icon_name))
    toolbtn.set_icon_widget(widget)
    toolbtn.set_tooltip_markup(tooltip)
    toolbtn.connect('clicked', callback)
    return toolbtn

#--- Main class        
class Curlew(Gtk.Window):
    
    def __init__(self):
        #--- Variables
        self.curr_open_folder = None
        self.curr_save_folder = None
        self.is_converting = False
        self.fp = None
        self.Iter = None
        self.output_details = ''
        self.total_duration = 0.0
        self.out_file = None
        self.pass_nbr = 0
        '''
        0: Single pass encoding option
        1: Two-pass encoding option (1st pass)
        2: Two-pass encoding option (2nd pass)
        '''
        self.encoder = ''
        self.player = 'ffplay'
        
        #--- Regex
        self.reg_avconv_u = \
        re.compile('''size=\s+(\d+\.*\d*).*time=(\d+\.\d*)''') # ubuntu
        self.reg_avconv_f = \
        re.compile('''size=\s+(\d+\.*\d*).*time=(\d+:\d+:\d+.\d+)''') # fedora
        self.reg_menc = \
        re.compile('''.(\d+\.*\d*)s.*(.\d+)%.*\s+(\d+)mb''')
        self.reg_duration = \
        re.compile('''Duration:.*(\d+:\d+:\d+\.\d+)''')
               
        Gtk.Window.__init__(self)        
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_title('{} {}'.format(APP_NAME, APP_VERSION))
        self.set_border_width(6)
        self.set_size_request(680, -1)
        self.set_icon_name('curlew')
        
        vbox = Gtk.VBox(spacing=6)
        self.add(vbox)

        #--- Toolbar
        toolbar = Gtk.Toolbar()
        toolbar.set_style(Gtk.ToolbarStyle.ICONS)
        toolbar.set_icon_size(Gtk.IconSize.DIALOG)
        vbox.pack_start(toolbar, False, True, 0)
        
        
        self.tb_add = create_tool_btn('add.png',
                                      _('Add files'),
                                      self.tb_add_clicked)
        toolbar.insert(self.tb_add, -1)
        
        self.tb_remove = create_tool_btn('remove.png',
                                         _('Remove selected file'),
                                         self.tb_remove_clicked)
        toolbar.insert(self.tb_remove, -1)
        
        self.tb_clear = create_tool_btn('clear.png',
                                        _('Clear files list'),
                                        self.tb_clear_clicked)
        toolbar.insert(self.tb_clear, -1)
        
        toolbar.insert(Gtk.SeparatorToolItem(), -1)
        
        self.tb_convert = create_tool_btn('convert.png',
                                          _('Start Conversion'),
                                          self.convert_cb)
        toolbar.insert(self.tb_convert, -1)
        
        self.tb_stop = create_tool_btn('stop.png',
                                       _('Stop Conversion'),
                                       self.tb_stop_clicked)
        toolbar.insert(self.tb_stop, -1)
        
        toolbar.insert(Gtk.SeparatorToolItem(), -1)
        
        self.tb_about = create_tool_btn('about.png',
                                        _('About ') + APP_NAME,
                                        self.tb_about_clicked)
        toolbar.insert(self.tb_about, -1)
        
        toolbar.insert(Gtk.SeparatorToolItem(), -1)
        
        self.tb_quit = create_tool_btn('close.png',
                                       _('Quit application'),
                                       self.quit_cb)
        toolbar.insert(self.tb_quit, -1)
        
        #--- List of files
        self.store = Gtk.ListStore(bool,  # active 
                                   str,   # file_name
                                   str,   # duration
                                   str,   # estimated file_size
                                   str,   # time remaining
                                   float, # progress
                                   str,   # status (progress txt)
                                   int,   # pulse
                                   str    # complete file_name
                                   )         
        self.tree = Gtk.TreeView(self.store)
        self.tree.set_grid_lines(True)
        self.tree.set_has_tooltip(True)
        self.tree.set_rubber_banding(True)

        tree_select = self.tree.get_selection()
        tree_select.set_mode(Gtk.SelectionMode.MULTIPLE)
        
        self.tree.connect("button-press-event", self.show_popup)
        self.tree.connect("key-press-event", self.on_key_press)
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_size_request(-1, 180)
        scroll.set_shadow_type(Gtk.ShadowType.IN)
        scroll.add(self.tree)
        vbox.pack_start(scroll, True, True, 0)
        
        #--- CheckButton cell
        cell = Gtk.CellRendererToggle()
        cell.connect('toggled', self.on_toggled_cb)
        col = Gtk.TreeViewColumn(None, cell, active=C_SKIP)
        self.tree.append_column(col)
        
        #--- File name cell
        cell = Gtk.CellRendererText()
        col = Gtk.TreeViewColumn(_("File"), cell, text=C_NAME)
        col.set_resizable(True)
        col.set_min_width(100)
        self.tree.append_column(col)
        
        #--- Duration cell
        cell = Gtk.CellRendererText()
        col = Gtk.TreeViewColumn(_("Duration"), cell, text=C_DURA)
        self.tree.append_column(col)
        
        
        #--- Size cell
        cell = Gtk.CellRendererText()
        col = Gtk.TreeViewColumn(_("Estimated size"), cell, text=C_SIZE)
        col.set_fixed_width(60)
        self.tree.append_column(col)
        
        #--- Remaining time cell
        cell = Gtk.CellRendererText()
        col = Gtk.TreeViewColumn(_("Remaining time"), cell, text=C_REMN)
        self.tree.append_column(col)
        
        #--- Progress cell
        cell = Gtk.CellRendererProgress()
        col = Gtk.TreeViewColumn(_("Progress"), cell, 
                                 value=C_PRGR, text=C_STAT, pulse=C_PULS)
        col.set_min_width(130)
        self.tree.append_column(col)

        #--- Popup menu
        self.popup = Gtk.Menu()
        remove_item = Gtk.ImageMenuItem().new_from_stock(Gtk.STOCK_REMOVE, None)
        remove_item.set_always_show_image(True)
        remove_item.connect('activate', self.tb_remove_clicked)
        
        play_item = Gtk.ImageMenuItem.new_from_stock(Gtk.STOCK_MEDIA_PLAY, None)
        play_item.set_always_show_image(True)
        play_item.connect('activate', self.on_play_cb)
        
        browse_item = Gtk.ImageMenuItem.new_from_stock(Gtk.STOCK_DIRECTORY, None)
        browse_item.set_always_show_image(True)
        browse_item.set_label(_('Browse destination'))
        browse_item.connect('activate', self.on_browse_cb)
        
        preview_item = Gtk.MenuItem(_('Preview before converting'))
        preview_item.connect('activate', self.on_preview_cb)
        
        self.popup.append(play_item)
        self.popup.append(preview_item)
        self.popup.append(remove_item)
        self.popup.append(browse_item)
        self.popup.show_all()
        
        #--- Output formats
        self.cmb_formats = Gtk.ComboBoxText()
        self.cmb_formats.set_entry_text_column(0)
        self.cmb_formats.connect('changed', self.on_cmb_formats_changed)
        hl = LabeledHBox(_("<b>Format:</b>"), vbox)
        hl.pack_start(self.cmb_formats, True, True, 0)
        
        #--- Destination
        self.e_dest = Gtk.Entry()
        self.e_dest.set_text(HOME)
        self.b_dest = Gtk.Button(' ... ')
        self.b_dest.set_size_request(30, -1)
        self.cb_dest = Gtk.CheckButton(_('Source Path'))
        self.cb_dest.connect('toggled', self.on_cb_dest_toggled)
        self.b_dest.connect('clicked', self.on_dest_clicked)     
        hl = LabeledHBox(_('<b>Destination:</b>'), vbox)
        hl.pack_start(self.e_dest, True, True, 0)
        hl.pack_start(self.b_dest, False, True, 0)
        hl.pack_start(self.cb_dest, False, True, 0)
        
        #--- Quality (low, medium, high)
        self.cmb_quality = Gtk.ComboBoxText()
        map(self.cmb_quality.append_text,
            [_("Low Quality"), _("Normal Quality"), _("High Quality")])
        self.cmb_quality.set_active(1)
        self.cmb_quality.connect('changed', self.on_cmb_quality_changed)
        hl = LabeledHBox(_('<b>Quality:</b>'), vbox)
        hl.pack_start(self.cmb_quality, True, True, 0)
        
        #-- Use same quality as source file
        self.cb_same_qual = Gtk.CheckButton(_('Source Quality'))
        self.cb_same_qual.set_tooltip_text(_('Use the same quality as source file'))
        self.cb_same_qual.connect('toggled', self.on_cb_same_qual_toggled)
        hl.pack_start(self.cb_same_qual, False, False, 0)
        
        #--- advanced options
        self.exp_advanced = Gtk.Expander(label=_("<b>Advanced</b>"))
        self.exp_advanced.set_use_markup(True)
        self.exp_advanced.set_resize_toplevel(True)
        vbox.pack_start(self.exp_advanced, False, True, 0)
        
        note = Gtk.Notebook()
        self.exp_advanced.add(note)
        
        #--- audio page
        self.vb_audio = Gtk.VBox()
        self.vb_audio.set_border_width(6)
        self.vb_audio.set_spacing(6)
        note.append_page(self.vb_audio, Gtk.Label(_("Audio")))
       
        self.c_abitrate = LabeledComboEntry(self.vb_audio, _("Audio Bitrate"))
        self.c_afreq = LabeledComboEntry(self.vb_audio, _("Audio Frequency"))
        self.c_ach = LabeledComboEntry(self.vb_audio, _("Audio Channels"))
        self.c_acodec = LabeledComboEntry(self.vb_audio, _("Audio Codec"))
        
        # volume
        self.hb_volume = LabeledHBox(_('Volume (%)'), self.vb_audio, 14)
        self.vol_scale = CustomHScale(self.hb_volume, 100, 25, 400, 25)
        
        self.vb_audio.pack_start(Gtk.Separator(), False, False, 0)
        
        # Audio quality for ogg
        self.hb_aqual = LabeledHBox(_('Audio Quality'), self.vb_audio, 14)
        self.a_scale = CustomHScale(self.hb_aqual, 3, 0, 10)
        
        
        #--- video page
        self.vb_video = Gtk.VBox()
        self.vb_video.set_border_width(6)
        self.vb_video.set_spacing(6)
        note.append_page(self.vb_video, Gtk.Label(_("Video")))
        
        self.c_vbitrate = LabeledComboEntry(self.vb_video, _("Video Bitrate"))
        self.c_vfps = LabeledComboEntry(self.vb_video, _("Video FPS"))
        self.c_vsize = LabeledComboEntry(self.vb_video, _("Video Size"))
        self.c_vcodec = LabeledComboEntry(self.vb_video, _("Video Codec"))
        self.c_vratio = LabeledComboEntry(self.vb_video, _("Aspect Ratio"))
        
        hbox = Gtk.HBox(spacing=10)
        self.vb_video.pack_start(hbox, False, False, 0)
        
        # 2-pass
        self.cb_2pass = Gtk.CheckButton(_('2-Pass'))
        hbox.pack_start(self.cb_2pass, False, False, 0)
        
        # Video only (no sound)
        self.cb_video_only = Gtk.CheckButton(_('Video only'))
        self.cb_video_only.connect('toggled', self.on_cb_video_only_toggled)
        hbox.pack_start(self.cb_video_only, False, False, 0)
        
        self.vb_video.pack_start(Gtk.Separator(), False, False, 0)
        
        # Video quality for ogv
        self.hb_vqual = LabeledHBox(_('Video Quality'), self.vb_video, 14)
        self.v_scale = CustomHScale(self.hb_vqual, 5, 0, 20)
        
        #--- Subtitle page
        self.vb_sub = Gtk.VBox()
        self.vb_sub.set_border_width(6)
        self.vb_sub.set_spacing(6)
        note.append_page(self.vb_sub, Gtk.Label(_("Subtitle")))
        
        #--- Sub Active/Desactive
        self.cb_sub = Gtk.CheckButton(_('Use subtitle'))
        self.cb_sub.connect('toggled', self.cb_sub_toggled)
        self.vb_sub.pack_start(self.cb_sub, False, False, 0)
        
        #--- Subtitle filename
        self.hb_sub = LabeledHBox(_('Subtitle: '), self.vb_sub, 9)
        self.entry_sub = Gtk.Entry()
        self.hb_sub.pack_start(self.entry_sub, True, True, 0)
        self.hb_sub.set_sensitive(False)
        
        #---- Select subtitle
        b_enc = Gtk.Button(' ... ')
        b_enc.set_size_request(30, -1)
        self.hb_sub.pack_start(b_enc, False, False, 0)
        b_enc.connect('clicked', self.b_enc_cb)
        
        #--- Subtitle font
        self.hb_font = LabeledHBox(_('Font: '), self.vb_sub, 9)
        self.b_font = Gtk.FontButton()
        self.hb_font.pack_start(self.b_font, True, True, 0)
        self.b_font.set_font_name('Arial 12')
        self.b_font.set_show_size(False)
        self.b_font.set_show_style(False)
        
        self.hb_font.set_sensitive(False)
        
        hbox = Gtk.HBox()
        hbox.set_spacing(30)
        
        #--- Subtitle position
        self.hb_pos = LabeledHBox(_('Position: '), hbox, 9)
        adj = Gtk.Adjustment(100, 0, 100, 2)
        self.spin_pos = Gtk.SpinButton()
        self.spin_pos.set_adjustment(adj)
        self.hb_pos.pack_start(self.spin_pos, True, True, 0)
        self.hb_pos.set_sensitive(False)
        
        #--- Subtitle size
        self.hb_size = LabeledHBox(_('Size: '), hbox, 0)
        adj = Gtk.Adjustment(4, 0, 100, 1)
        self.spin_size = Gtk.SpinButton()
        self.spin_size.set_adjustment(adj)
        self.hb_size.pack_start(self.spin_size, True, True, 0)
        self.hb_size.set_sensitive(False)
        
        self.vb_sub.pack_start(hbox, False, False, 0)
        
        #--- Subtitle Encoding
        enc = ['cp1250', 'cp1252', 'cp1253', 'cp1254',
               'cp1255', 'cp1256', 'cp1257', 'cp1258',
               'iso-8859-1', 'iso-8859-2', 'iso-8859-3', 'iso-8859-4',
               'iso-8859-5', 'iso-8859-6', 'iso-8859-7', 'iso-8859-8',
               'iso-8859-9', 'iso-8859-10', 'iso-8859-11', 'iso-8859-12',
               'iso-8859-13', 'iso-8859-14', 'iso-8859-15',
               'utf-7', 'utf-8', 'utf-16', 'utf-32', 'ASCII']
        self.hb_enc = LabeledHBox(_('Encoding: '), self.vb_sub, 9)
        self.combo_enc = Gtk.ComboBoxText()
        self.combo_enc.set_entry_text_column(0)
        map(self.combo_enc.append_text, enc)
        self.combo_enc.set_active(5)
        self.combo_enc.set_wrap_width(4)
        self.hb_enc.pack_start(self.combo_enc, True, True, 0)
        self.hb_enc.set_sensitive(False)
        
        #--- Other page (split,...)
        self.vb_other = Gtk.VBox()
        self.vb_other.set_border_width(6)
        self.vb_other.set_spacing(8)
        note.append_page(self.vb_other, Gtk.Label(_("Other")))
        
        #--- Split file section
        self.cb_split = Gtk.CheckButton(label=_('Split File'), active=False)
        self.cb_split.connect('toggled', self.cb_split_cb)
        self.vb_other.pack_start(self.cb_split, False, False, 0)
        self.tl_begin = TimeLayout(self.vb_other, _('Begin time: '))
        self.tl_duration = TimeLayout(self.vb_other, _('Duration: '))
        self.tl_duration.set_duration(5)
        self.tl_begin.set_sensitive(False)
        self.tl_duration.set_sensitive(False)
         
        # Encoder type (ffmpeg / avconv)
        self.combo_encoder = LabeledComboEntry(self.vb_other, 
                                               _('Converter:'), 0)
        self.combo_encoder.set_label_width(10)
        self.combo_encoder.connect('changed', self.combo_encoder_cb)
        self.combo_encoder.set_list(['avconv', 'ffmpeg'])
        
        # Other Parameters.
        hb_other = LabeledHBox(_('Others opts:'), self.vb_other, 10)
        self.e_extra = Gtk.Entry()
        hb_other.pack_start(self.e_extra, True, True, 0)
        
        # Replace/Skip/Rename
        self.cmb_exist = LabeledComboEntry(self.vb_other, _('File exist:'), 0)
        self.cmb_exist.set_label_width(10)
        self.cmb_exist.set_list([_('Overwrite it'),
                                 _('Choose another name'),
                                 _('Skip conversion')])
        
        
        vbox.pack_start(Gtk.Separator(), False, False, 0)
        
        #--- Status
        self.label_details = Gtk.Label()
        self.label_details.set_text('')
        vbox.pack_start(self.label_details, False, False, 0)
        
        #--- Show interface
        '''Must show interface before loading cmb_formats combobox.'''
        self.show_all()
        
        #--- Load formats from format.cfg file
        self.f_file = ConfigParser()
        self.f_file.read(join(APP_DIR, 'formats.cfg'))
        map(self.cmb_formats.append_text, self.f_file.sections())
        self.cmb_formats.set_active(0)
        
        #--- Load saved options.
        self.load_options()
        
        #--- Drag and Drop
        targets = Gtk.TargetList.new([])
        targets.add_uri_targets((1 << 5) - 1)
        self.drag_dest_set(Gtk.DestDefaults.ALL, [], Gdk.DragAction.COPY)
        self.drag_dest_set_target_list(targets)
        self.connect('drag-data-received', self.drop_data_cb)
        
        #--- Window connections
        self.connect('destroy', Gtk.main_quit)
        self.connect('delete-event', self.on_delete)
    
    
    def on_toggled_cb(self, widget, Path):
        self.store[Path][C_SKIP] = not self.store[Path][C_SKIP]
        
    def on_cb_same_qual_toggled(self, widget):
        active = widget.get_active()
        self.cmb_quality.set_sensitive(not active)
        if active:
            self.vb_audio.set_sensitive(False)
            self.vb_video.set_sensitive(False)
        else:
            self.set_sensitives()
        
    
    def on_delete(self, widget, data):
        self.quit_cb(widget)
        return True
    
    def quit_cb(self, widget):
        self.save_options()
        if self.is_converting:
            ''' Press quit btn during conversion process '''
            resp = show_message(self, _('Do you want to quit Curlew and abort conversion process?'),
                                Gtk.MessageType.QUESTION,
                                Gtk.ButtonsType.YES_NO)
            if resp == Gtk.ResponseType.YES:
                try:
                    self.fp.kill()
                    self.fp.terminate()
                    self.force_delete_file(self.out_file)
                except: 
                    pass
                Gtk.main_quit()
            return
        Gtk.main_quit()
    
    #--- Add files
    def tb_add_clicked(self, widget):
        open_dlg = Gtk.FileChooserDialog(_("Add file"),
                                         self, Gtk.FileChooserAction.OPEN,
                                        (Gtk.STOCK_OK, 
                                         Gtk.ResponseType.OK,
                                         Gtk.STOCK_CANCEL,
                                         Gtk.ResponseType.CANCEL))
        open_dlg.set_current_folder(self.curr_open_folder)
        open_dlg.set_select_multiple(True)
        
        #--- File filters
        Filter = Gtk.FileFilter()
        Filter.set_name(_("All supported files"))
        Filter.add_mime_type("video/*")
        Filter.add_mime_type("audio/*")
        Filter.add_pattern("*.[Rr][AaMm]*")
        open_dlg.add_filter(Filter)
        
        Filter = Gtk.FileFilter()
        Filter.set_name(_("Video files"))
        Filter.add_mime_type("video/*")
        Filter.add_pattern("*.[Rr][AaMm]*")
        open_dlg.add_filter(Filter)
        
        Filter = Gtk.FileFilter()
        Filter.set_name(_("Audio files"))
        Filter.add_mime_type("audio/*")
        Filter.add_pattern("*.[Rr][AaMm]*")
        open_dlg.add_filter(Filter)
        
        Filter = Gtk.FileFilter()
        Filter.set_name(_("All files"))
        Filter.add_pattern("*")
        open_dlg.add_filter(Filter)
        
        res = open_dlg.run()
        if res == Gtk.ResponseType.OK:
            for file_name in open_dlg.get_filenames():
                self.store.append([
                                   True,
                                   basename(file_name),
                                   None,
                                   None,
                                   None,
                                   0.0,
                                   _('Ready!'),
                                   -1,
                                   file_name
                                   ])
                
            #--- Saved current folder
            self.curr_open_folder = open_dlg.get_current_folder()
        open_dlg.destroy()
        
        #
        for row in self.store:
            while Gtk.events_pending():
                Gtk.main_iteration()
            row[C_DURA] = self.get_time(row[C_FILE])
        
    
    def on_dest_clicked(self, widget):
        save_dlg = Gtk.FileChooserDialog(_("Choose destination"), self,
                                    Gtk.FileChooserAction.SELECT_FOLDER,
                                    (Gtk.STOCK_OK, Gtk.ResponseType.OK,
                                    Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL))
        save_dlg.set_current_folder(self.curr_save_folder)
        res = save_dlg.run()
        if res == Gtk.ResponseType.OK:
            self.e_dest.set_text(save_dlg.get_filename())
        self.curr_save_folder = save_dlg.get_current_folder()
        save_dlg.destroy()
    
    def cb_split_cb(self, widget):
        is_checked = widget.get_active()
        self.tl_begin.set_sensitive(is_checked)
        self.tl_duration.set_sensitive(is_checked)
        
    def on_cmb_formats_changed(self, widget):
        self.cmb_quality.set_active(1) # return to Normal Quality
        self.fill_options()
        self.set_sensitives()
    
    def set_sensitives(self):
        section = self.cmb_formats.get_active_text()
        media_type = self.f_file.get(section, 'type')

        # sens = [AudioP, VideoP, SubtitleP, QualityC, aQuality, vQuality]
        if media_type == 'audio':
            sens = [True, False, False, True, False, False]
        elif media_type == 'video':
            sens = [True, True, False, True, False, False]
        elif media_type == 'mvideo':
            sens = [True, True, True, True, False, False]
        elif media_type == 'fixed':
            sens = [False, False, False, False, False, False]
        elif media_type == 'ogg':
            sens = [True, False, False, False, True, False]
        elif media_type == 'ogv':
            sens = [True, True, False, False, True, True]
        elif media_type == 'presets':
            sens = [False, False, False, False, False, False]

        self.vb_audio.set_sensitive(sens[0])   # Audio page
        self.vb_video.set_sensitive(sens[1])   # Video page
        self.vb_sub.set_sensitive(sens[2])     # Subtitle page
        self.cmb_quality.set_sensitive(sens[3]) # Quality combobox
        self.hb_aqual.set_sensitive(sens[4])   # Audio quality slider (ogg)
        self.hb_vqual.set_sensitive(sens[5])   # video Quality slider (ogv)
        
        self.cb_same_qual.set_active(False)
        self.cb_video_only.set_active(False)
        is_true = not(self.f_file.get(section, 'encoder') == 'm' \
                      or media_type in ['fixed', 'presets'])
        self.cb_same_qual.set_sensitive(is_true)
    
    
    #--- fill options widgets
    def fill_options(self):
        section = self.cmb_formats.get_active_text()
        
        if self.f_file.has_option(section, 'extra'):
            self.e_extra.set_text(self.f_file.get(section, 'extra'))
        else:
            self.e_extra.set_text('')
            
        # For presets
        if self.f_file.has_option(section, 'cmd'):
            self.presets_cmd = self.f_file.get(section, 'cmd').split()
            return
            
        if self.f_file.has_option(section, 'abitrate'):
            li = self.f_file.get(section, 'abitrate').split()
            self.c_abitrate.set_list(li)
        
        if self.f_file.has_option(section, 'afreq'):
            li = self.f_file.get(section, 'afreq').split()
            self.c_afreq.set_list(li)
        
        if self.f_file.has_option(section, 'ach'):    
            li = self.f_file.get(section, 'ach').split()
            self.c_ach.set_list(li)
        
        if self.f_file.has_option(section, 'acodec'):
            li = self.f_file.get(section, 'acodec').split()
            self.c_acodec.set_list(li)
        
        if self.f_file.has_option(section, 'aqual'):
            aqual = self.f_file.get(section, 'aqual').split()
            self.c_abitrate.set_text(aqual[self.cmb_quality.get_active()])
            
        if self.f_file.has_option(section, 'vbitrate'):
            li = self.f_file.get(section, 'vbitrate').split()
            self.c_vbitrate.set_list(li)
            
        if self.f_file.has_option(section, 'vbitrate'):
            li = self.f_file.get(section, 'vfps').split()
            self.c_vfps.set_list(li)
        
        if self.f_file.has_option(section, 'vcodec'):
            li = self.f_file.get(section, 'vcodec').split()
            self.c_vcodec.set_list(li)
            
        if self.f_file.has_option(section, 'vsize'):
            li = self.f_file.get(section, 'vsize').split()
            self.c_vsize.set_list(li)
        
        if self.f_file.has_option(section, 'vratio'):
            li = self.f_file.get(section, 'vratio').split()
            self.c_vratio.set_list(li)
        
        if self.f_file.has_option(section, 'vqual'):
            vqual = self.f_file.get(section, 'vqual').split()
            self.c_vbitrate.set_text(vqual[self.cmb_quality.get_active()])
        
            
        
    
    def build_avconv_cmd(self,
                         input_file, out_file,
                         start_pos= -1, part_dura= -1):
        '''
        start_pos <=> -ss, part_dura <=> -t
        '''
        section = self.cmb_formats.get_active_text()
        media_type = self.f_file.get(section, 'type')
        
        cmd = [self.encoder, '-y'] #, '-xerror']
        cmd.extend(["-i", input_file])
        
        # Force format
        if self.f_file.has_option(section, 'ff'):
            cmd.extend(['-f', self.f_file.get(section, 'ff')])
            
        # Extract Audio
        if media_type in ['audio', 'ogg']:
            cmd.append('-vn')
        
        # Use the same quality
        if self.cb_same_qual.get_active():
            cmd.append('-same_quant')
        else:
        
                
            # Video opts
            if media_type == 'video':
                # Extract video only
                if self.cb_video_only.get_active():
                    cmd.append('-an')
                
                # Video bitrate
                if self.c_vbitrate.get_text() != 'default':
                    cmd.extend(['-b', self.c_vbitrate.get_text()])
                # Video FPS
                if self.c_vfps.get_text() != 'default':
                    cmd.extend(['-r', self.c_vfps.get_text()])
                # Video codec
                if self.c_vcodec.get_text() != 'default':
                    cmd.extend(['-vcodec', self.c_vcodec.get_text()])
                # Video size
                if self.c_vsize.get_text() != 'default':
                    cmd.extend(['-s', self.c_vsize.get_text()])
                # Video aspect ratio    
                if self.c_vratio.get_text() == 'default':
                    #-- force aspect ratio
                    if self.c_vcodec.get_text() in ['libxvid', 'mpeg4', 'h263']:
                        cmd.extend(['-aspect', self.get_aspect_ratio(input_file)])
                else:
                    cmd.extend(['-aspect', self.c_vratio.get_text()])
    
            # Audio
            if media_type in ['audio', 'video', 'ogg', 'ogv']:
                # Audio bitrate
                if self.c_abitrate.get_text() != 'default':
                    cmd.extend(['-ab', self.c_abitrate.get_text()])
                # Audio Freq.
                if self.c_afreq.get_text() != 'default':
                    cmd.extend(['-ar', self.c_afreq.get_text()])
                # Audio channel
                if self.c_ach.get_text() != 'default':
                    cmd.extend(['-ac', self.c_ach.get_text()])
                
                # Audio codec
                if self.c_acodec.get_text() != 'default':
                    cmd.extend(['-acodec', self.c_acodec.get_text()])

            # Ogg format
            if media_type in ['ogg', 'ogv']:
                cmd.extend(['-aq', str(self.a_scale.get_value())])
            
            # ogv format
            if media_type == 'ogv':
                cmd.extend(['-qscale', str(self.v_scale.get_value())])
            
            #--- Extra options (add other specific options if exist)
            if self.e_extra.get_text().strip() != '':
                cmd.extend(self.e_extra.get_text().split())
        
        
        # Fixed opts
        if media_type == 'fixed':
            target = self.f_file.get(section, 'target')
            cmd.extend(['-target', target])
        
        # Presets formats
        elif media_type == 'presets':
            cmd.extend(self.presets_cmd)
        
        # Split file
        if start_pos != -1 and part_dura != -1:
            cmd.extend(['-ss', start_pos])
            cmd.extend(['-t', part_dura])
        
        # Volume (gain)
        if self.vol_scale.get_value() != 100:
            cmd.extend(['-vol', self.per_to_vol(self.vol_scale.get_value())])
        
        # 2-pass (avconv)
        if self.pass_nbr == 1:
            cmd.append('-an') # disable audio
            cmd.extend(['-pass', '1'])
            cmd.extend(['-passlogfile', PASS_LOG])
        elif self.pass_nbr == 2:
            cmd.extend(['-pass', '2'])
            cmd.extend(['-passlogfile', PASS_LOG])
            
        #--- Last
        cmd.append(out_file)
        print(' '.join(cmd)) # print command line
        return cmd
    
    
    #--- MEncoder cmd
    def build_mencoder_cmd(self, 
                           input_file, out_file,
                           start_pos= -1, part_dura= -1):

        cmd = ['mencoder']
        #--- Input and output files
        cmd.append(input_file)
        cmd.extend(['-o', out_file])
        cmd.append('-noskip')
        
        # Split file (mencoder)
        if start_pos != -1 and part_dura != -1:
            cmd.extend(['-ss', start_pos])
            cmd.extend(['-endpos', part_dura])
        
        #--- Subtitle font
        if self.cb_sub.get_active():
            cmd.extend(['-sub', self.entry_sub.get_text()]) # subtitle file
            cmd.append('-fontconfig') # configure font
            font_name = extract_font_name(self.b_font.get_font_name())
            cmd.extend(['-subfont', font_name])
            cmd.extend(['-subfont-text-scale',
                        str(self.spin_size.get_value_as_int())])
            cmd.extend(['-subpos', str(self.spin_pos.get_value_as_int())])
            cmd.extend(['-subcp', self.combo_enc.get_active_text()])
            # RTL language (Arabic)
            cmd.append('-flip-hebrew')
            cmd.append('-noflip-hebrew-commas')
        
        
        #--- Audio codec and opts
        cmd.extend(['-oac', self.c_acodec.get_text()])
        # No audio options with 'copy'
        if self.c_acodec.get_text() == 'copy':
            pass
        else:
            a_opts = []
            
            #--- For mp3lame codec
            if self.c_acodec.get_text() == 'mp3lame':
                cmd.append('-lameopts')
                # Use constant bitrate
                a_opts.append('cbr') 
                # Audio channels
                a_opts.append('mode={}'.format(self.c_ach.get_text())) 
                # Audio bitrate
                a_opts.append('br={}'.format(self.c_abitrate.get_text()))
            
            #--- For faac audio codec
            elif self.c_acodec.get_text() == 'faac':
                cmd.append('-faacopts')
                # Bitrate
                a_opts.append('br={}'.format(self.c_abitrate.get_text()))
            
            #--- For libavcodec audio (lavc)
            elif self.c_acodec.get_text() == 'lavc':
                cmd.append('-lavcopts')
                # Bitrate
                a_opts.append('abitrate={}'.format(self.c_abitrate.get_text()))
                # Codec used
                a_opts.append('acodec=mp2')
                
            #--- Append cmd with audio opts
            cmd.append(':'.join(a_opts))
            
        
        #--- Video codec and opts
        cmd.extend(['-ovc', self.c_vcodec.get_text()])
        
        #--- For XviD video codec
        v_opts = []
        if self.c_vcodec.get_text() == 'xvid':
            cmd.append('-xvidencopts')
            # Video bitrate
            v_opts.append('bitrate={}'.format(self.c_vbitrate.get_text()))
            # More...
            v_opts.append('autoaspect')
            v_opts.append('vhq=2:bvhq=1:trellis:hq_ac:chroma_me:chroma_opt')
            v_opts.append('quant_type=mpeg')
            # Pass number
            if self.pass_nbr != 0:
                v_opts.append('pass={}'.format(self.pass_nbr))        
        
        #--- For libavcodec video opts (divx)
        elif self.c_vcodec.get_text() == 'lavc':
            cmd.append('-lavcopts')
            # Bitrate
            v_opts.append('vbitrate={}'.format(self.c_vbitrate.get_text()))
            # Additional options.
            v_opts.append('vcodec=mpeg4:autoaspect')
            if self.pass_nbr != 1:
                v_opts.append('mbd=2:trell')
                
            # Pass number (1 or 2)
            if self.pass_nbr != 0:
                v_opts.append('vpass={}'.format(self.pass_nbr))
        
        #--- For H.264 video
        elif self.c_vcodec.get_text() == 'x264':
            cmd.append('-x264encopts')
            # Bitrate
            v_opts.append('bitrate={}'.format(self.c_vbitrate.get_text()))
            # Additional options.
            v_opts.append('subq=5:8x8dct:me=umh:frameref=2:bframes=3:weight_b')
            # Pass number (1 or 2)
            if self.pass_nbr != 0:
                v_opts.append('pass={}'.format(self.pass_nbr))
        
        # Append cmd with video opts
        cmd.append(':'.join(v_opts))
            
        # Add extra option if exist.
        if self.e_extra.get_text().strip() != '':
            cmd.extend(self.e_extra.get_text().split())
            
        # Add option suitable for each pass (1 or 2)
        if self.pass_nbr == 1:
            cmd.append('-nosound') # disable audio
            cmd.extend(['-passlogfile', PASS_LOG])
        elif self.pass_nbr == 2:
            cmd.extend(['-passlogfile', PASS_LOG])
        
        #--- Split file (encode part of file)
        if self.cb_split.get_active():
            cmd.extend(['-ss', self.tl_begin.get_time_str()])
            cmd.extend(['-endpos', self.tl_duration.get_time_str()])
        
        #--- Video size
        if self.c_vsize.get_text() != 'default':
            cmd.append('-vf')
            cmd.append('scale={}'.format(self.c_vsize.get_text()))
        
        #--- Video FPS
        if self.c_vfps.get_active_text() != 'default':
            cmd.append('-mf')
            cmd.append('fps={}'.format(self.c_vfps.get_active_text()))
        
        
        print(' '.join(cmd))
        return cmd

    #--- Convert funtcion
    def convert_cb(self, widget):
        if len(self.store) == 0 or self.is_converting:
            return
        
        # Return when invalid / inaccessible path
        if not isdir(self.e_dest.get_text()):
            show_message(self,
                         _('Destination path is not valid.'),
                         Gtk.MessageType.ERROR)
            self.set_focus(self.e_dest)
            return
        if not os.access(self.e_dest.get_text(), os.W_OK):
            show_message(self,
                         _('Destination path is not accessible.'),
                         Gtk.MessageType.ERROR)
            self.set_focus(self.e_dest)
            return
        
        self.Iter = self.store.get_iter_first()
        self.output_details = ''
        self.is_converting = True
        self.pass_nbr = int(self.cb_2pass.get_active())
        self.convert_file()
        

    def convert_file(self):
        ext = self.f_file.get(self.cmb_formats.get_active_text(), 'ext')
        encoder_type = self.f_file.get(self.cmb_formats.get_active_text(),
                                       'encoder')
        
        #--- Check
        if self.Iter != None:
            #--- Do not convert this file (unchecked)
            if self.store[self.Iter][C_SKIP] == False:
                self.store[self.Iter][C_STAT] = _("Skipped!")
                # Jump to next file
                self.Iter = self.store.iter_next(self.Iter)
                self.convert_file()
                return
                     
            #--- Get input file
            input_file = self.store[self.Iter][C_FILE]
            # When input file not found
            if not isfile(input_file):
                self.store[self.Iter][C_STAT] = _("Not found!")
                self.Iter = self.store.iter_next(self.Iter)
                self.convert_file()
                return
                
            part = splitext(basename(input_file))[0] + '.' + ext
            
            # Same destination as source file
            if self.cb_dest.get_active():
                out_file = join(dirname(input_file), part)
            # Use entry destination path
            else:
                out_file = join(self.e_dest.get_text(), part)
            
            #--- If output file already exist
            if os.path.exists(out_file):
                # Overwrite it.
                if self.cmb_exist.get_active() == 0:
                    #--- Rename output file if has the same name as input file
                    if input_file == out_file:
                        out_file = '{}~.{}'.format(splitext(out_file)[0], ext)
                    self.force_delete_file(out_file)
                # Choose another name.
                elif self.cmb_exist.get_active() == 1:
                    out_file = self.new_name(out_file)
                # Skip conversion.
                elif self.cmb_exist.get_active() == 2:
                    self.store[self.Iter][C_STAT] = _('Skipped!')
                    self.Iter = self.store.iter_next(self.Iter)
                    self.convert_file()
                    return
            
            self.out_file = out_file
        
            # Encoding in /tmp "temporary folder" in 1st pass
            if self.pass_nbr == 1:
                out_file = PASS_1_FILE
            
            #--- Which encoder use (avconv of mencoder)
            if encoder_type == 'f':
                if self.cb_split.get_active():
                    full_cmd = self.build_avconv_cmd(input_file, out_file,
                                            self.tl_begin.get_time_str(),
                                            self.tl_duration.get_time_str())
                else:
                    full_cmd = self.build_avconv_cmd(input_file, out_file)
                    
            elif encoder_type == 'm':
                if self.cb_split.get_active():
                    full_cmd = self.build_mencoder_cmd(input_file, out_file,
                                            self.tl_begin.get_time_str(),
                                            self.tl_duration.get_time_str()) 
                else:
                    full_cmd = self.build_mencoder_cmd(input_file, out_file)
            
            #--- Total file duration
            self.total_duration = self.get_duration(input_file)
            
            #---  To be converted duration
            if self.cb_split.get_active():
                self.total_duration = self.tl_duration.get_duration()
            
            # Stored start time
            self.begin_time = time.time()
            
            #--- deactivated controls
            self.enable_controls(False)
            
            #--- Start the process
            self.fp = Popen(full_cmd,
                            stdout=PIPE,
                            stderr=PIPE,
                            universal_newlines=True,
                            bufsize= -1)
            #--- Watch stdout and stderr
            GLib.io_add_watch(self.fp.stdout,
                              GLib.IO_IN | GLib.IO_HUP,
                              self.on_output, encoder_type, out_file)
            GLib.io_add_watch(self.fp.stderr,
                              GLib.IO_IN | GLib.IO_HUP,
                              self.on_output, encoder_type, out_file)
            #--- On end process
            GLib.child_watch_add(self.fp.pid, self.on_end, out_file)
            
        else:
            self.is_converting = False
    
    
    #--- Stop conversion cb
    def tb_stop_clicked(self, widget):        
        if self.is_converting == True:
            resp = show_message(self,
                                _('Do you want to stop conversion process?'),
                                Gtk.MessageType.QUESTION,
                                Gtk.ButtonsType.YES_NO)
            if resp == Gtk.ResponseType.YES and self.is_converting == True:
                try:
                    self.fp.kill()
                except OSError as err:
                    print(err) 
                finally:
                    self.is_converting = False
                    self.enable_controls(True)
                    
    
    def new_name(self, filename):
        """Return new filename like path/output~n.ext (n = 0,1 ...)"""
        part = splitext(filename)
        num = 1
        new_name = '{}~{}'.format(part[0], part[1])
        while os.path.exists(new_name):
            new_name = '{}~{}{}'.format(part[0], str(num), part[1])
            num += 1
        return new_name
    
    def get_duration(self, input_file):
        ''' Get duration file in seconds (float)'''
        duration = 0.0
        cmd = [self.encoder, '-i', input_file]
        Proc = Popen(cmd, stdout=PIPE, stderr=PIPE)
        out_str = Proc.stderr.read()
        try:
            time_list = self.reg_duration.findall(out_str)[0].split(':')
        except:
            return duration
        duration = int(time_list[0]) * 3600 + int(time_list[1]) * 60 + \
        float(time_list[2])
        return duration
    
    def get_time(self, input_file):
        ''' Get time duration file 0:00:00'''
        cmd = '{} -i "{}"'.format(self.encoder, input_file)
        Proc = Popen(cmd, stdout=PIPE, stderr=PIPE, shell=True)
        out_str = Proc.stderr.read()
        try:
            return self.reg_duration.findall(out_str)[0]
        except:
            return '0:00:00.00'
    
    #---- Quality callback
    def on_cmb_quality_changed(self, widget):
        quality_index = self.cmb_quality.get_active()
        section = self.cmb_formats.get_active_text()
        self.set_sensitives()
        
        if self.f_file.has_option(section, 'aqual'):
            aqual = self.f_file.get(section, 'aqual').split()
            self.c_abitrate.set_text(aqual[quality_index])
        
        if self.f_file.has_option(section, 'vqual'):
            vqual = self.f_file.get(section, 'vqual').split()
            self.c_vbitrate.set_text(vqual[quality_index])
    
    #---- Select subtitle
    def b_enc_cb(self, widget):
        dlg = Gtk.FileChooserDialog(_('Select subtitle'),
                                    self,
                                    Gtk.FileChooserAction.OPEN,
                                    (Gtk.STOCK_ADD, Gtk.ResponseType.OK,
                                     Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL)
                                     )
        dlg.set_current_folder(self.curr_open_folder)
        Filter = Gtk.FileFilter()
        Filter.set_name(_("Subtitle files"))
        Filter.add_pattern("*.[Ss][Rr][Tt]*")
        Filter.add_pattern("*.[Ss][Uu][Bb]*")
        dlg.add_filter(Filter)
        res = dlg.run()
        if res == Gtk.ResponseType.OK:
            self.entry_sub.set_text(dlg.get_filename())
        dlg.destroy()
    
    #--- Remove item
    def tb_remove_clicked(self, widget):
        iters = self.get_selected_iters()
        if not iters:
            return      
        elif self.is_converting:
            for Iter in iters:
                if self.store[Iter][:] != self.store[self.Iter][:]:
                    self.store.remove(Iter)
        else:
            map(self.store.remove, iters)
    
    def get_selected_iters(self):
        ''' Get a list contain selected iters '''
        model, tree_path = self.tree.get_selection().get_selected_rows()
        iters = []
        if not tree_path:
            return iters
        for path in tree_path:
            iters.append(model.get_iter(path))
        return iters
    
    def on_play_cb(self, widget):
        Iter = self.get_selected_iters()[0]
        call('{} -autoexit "{}"'.format(self.player, self.store[Iter][C_FILE]),
             shell=True)
        
    def on_browse_cb(self, widget):
        if self.cb_dest.get_active():
            Iter = self.get_selected_iters()[0]
            call(['xdg-open', dirname(self.store[Iter][C_FILE])])
        else:
            call(['xdg-open', self.e_dest.get_text()])
            
    def on_preview_cb(self, widget):
        if self.is_converting:
            return
        encoder_type = self.f_file.get(self.cmb_formats.get_active_text(),
                                       'encoder')
        Iter = self.get_selected_iters()[0]
        input_file = self.store[Iter][C_FILE]
        duration = self.get_duration(input_file)
        preview_begin = str(duration / 10)
        
        if encoder_type == 'f':
            cmd = self.build_avconv_cmd(input_file, PREVIEW_FILE,
                                        preview_begin, TEN_SECONDS)
        elif encoder_type == 'm':
            cmd = self.build_mencoder_cmd(input_file, PREVIEW_FILE,
                                          preview_begin, TEN_SECONDS)
    
        fp = Popen(cmd, stdout=PIPE, stderr=PIPE)
        
        # Disable main window
        self.set_sensitive(False)
        
        # Wait...
        while fp.poll() == None:
            while Gtk.events_pending():
                Gtk.main_iteration()
            self.store[Iter][C_PULS] = self.store[Iter][C_PULS] + 1
            self.store[Iter][C_STAT] = _('Wait...')
            time.sleep(0.1)
            
        # Update informations.
        self.store[Iter][C_PRGR] = 0.0
        self.store[Iter][C_STAT] = _('Ready!')
        self.store[Iter][C_PULS] = -1
        
        # Play preview file.
        fp = Popen('{} -autoexit -window_title {} "{}"'.format(self.player,
                                                         _('Preview'),
                                                         PREVIEW_FILE),
             shell=True,
             stdout=PIPE, stderr=PIPE)
        
        # Delete preview file after the end of playing
        while fp.poll() == None:
            pass
        self.force_delete_file(PREVIEW_FILE)
        
        # Enable main window
        self.set_sensitive(True)
    

    #--- Clear list    
    def tb_clear_clicked(self, widget):
        if not self.is_converting:
            self.store.clear()
        
    def tb_about_clicked(self, widget):
        a_dgl = About(self)
        a_dgl.show()
        
    def cb_sub_toggled(self, widget):
        self.hb_sub.set_sensitive(widget.get_active())
        self.hb_enc.set_sensitive(widget.get_active())
        self.hb_font.set_sensitive(widget.get_active())
        self.hb_pos.set_sensitive(widget.get_active())
        self.hb_size.set_sensitive(widget.get_active())
    
    #--- Remove selected items.
    def on_key_press(self, widget, event):
        if event.keyval == Gdk.KEY_Delete:
            self.tb_remove_clicked(None)
            
    def show_popup(self, widget, event):
        treepath = self.tree.get_selection().get_selected_rows()[1]
        if event.button == 3 and len(treepath) != 0:
            self.popup.show_all()
            self.popup.popup(None, None, None, None, 3,
                             Gtk.get_current_event_time())
        
    
    #---- On end conversion
    def on_end(self, pid, err_code, out_file):
        if self.Iter != None:
            # Converion succeed
            if err_code == 0:
                # 2pass
                if self.pass_nbr == 1:
                    self.pass_nbr = 2
                    # Remove temoprary file
                    self.force_delete_file(PASS_1_FILE)
                    self.convert_file()
                    return
                elif self.pass_nbr == 2:
                    self.pass_nbr = 1
                
                self.store[self.Iter][C_SKIP] = False
                self.store[self.Iter][C_PRGR] = 100.0
                self.store[self.Iter][C_STAT] = _("Done!")
                # Convert the next file
                self.Iter = self.store.iter_next(self.Iter)
                self.convert_file()
            
            # Converion failed
            elif err_code == 256:
                self.store[self.Iter][C_STAT] = _("Failed!")
                self.force_delete_file(out_file)
                
                # FIXME: write log
                print(self.output_details)
                
                # Convert the next file
                self.Iter = self.store.iter_next(self.Iter)
                self.convert_file()
            
            # Conversion stopped
            elif err_code == 9:
                # Remove uncompleted file
                self.force_delete_file(out_file)
                return
                    
        else:
            self.is_converting = False
        
        self.enable_controls(True)
        
    
    #--- Catch output 
    def on_output(self, source, condition, encoder_type, out_file):
        #--- Allow interaction with application widgets.
        while Gtk.events_pending():
            Gtk.main_iteration()
        
        if self.Iter == None:
            return False
        
        #--- Skipped file during conversion (unckecked file during conversion)
        if self.store[self.Iter][C_SKIP] == False:
            self.store[self.Iter][C_STAT] = _("Skipped!")
            self.store[self.Iter][C_PRGR] = 0.0
            
            # Stop conversion
            try:
                self.fp.kill()
            except OSError as detail:
                print(detail)
            
            # Delete the file
            self.force_delete_file(out_file)
            
            # Jump to next file
            self.Iter = self.store.iter_next(self.Iter)
            self.convert_file()
            return False
        
        line = source.readline()
        if len(line) > 0:
            # avconv progress
            if encoder_type == 'f':
                begin = line.find('time=')
                if begin != -1:                    
                    self.label_details.set_text(line.strip())
                    reg_avconv = self.reg_avconv_u
                    
                    # on ubuntu ... time like: time=00.00
                    if reg_avconv.findall(line) != []:
                        elapsed_time = float(reg_avconv.findall(line)[0][1])
                    
                    # on fedora ... time like this 'time=00:00:00.00'
                    else:
                        reg_avconv = self.reg_avconv_f
                        elapsed_time = reg_avconv.findall(line)[0][1]
                        elapsed_time = time_to_duration(elapsed_time)

                    try:
                        time_ratio = elapsed_time / self.total_duration
                    except ZeroDivisionError:
                        time_ratio = 0
                    
                    if time_ratio > 1: time_ratio = 1
                    
                    # Get estimated size
                    curr_size = float(reg_avconv.findall(line)[0][0])
                    try:
                        est_size = int((curr_size * self.total_duration) / elapsed_time)
                    except ZeroDivisionError: 
                        est_size = 0
                    
                    # Waiting (pluse progressbar)
                    if est_size == 0:
                        self.store[self.Iter][C_PULS] = self.store[self.Iter][C_PULS] + 1
                        self.store[self.Iter][C_STAT] = _('Wait...')
                    else:
                        # Formating estimated size
                        size_str = get_format_size(est_size)
                        
                        # Calculate remaining time.
                        cur_time = time.time() - self.begin_time
                        try:
                            rem_dur = ((cur_time * self.total_duration) / elapsed_time) - cur_time
                        except ZeroDivisionError:
                            rem_dur = 0
                        
                        # Convert duration (sec) to time (0:00:00)
                        rem_time = duration_to_time(rem_dur)
                        
                        self.store[self.Iter][C_SIZE] = size_str # estimated size
                        self.store[self.Iter][C_REMN] = rem_time # remaining time
                        self.store[self.Iter][C_PRGR] = float(time_ratio * 100) # progress value
                        if self.pass_nbr != 0:
                            self.store[self.Iter][C_STAT] = '{:.2%} (P{})'\
                            .format(time_ratio, self.pass_nbr) # progress text
                        else:
                            self.store[self.Iter][C_STAT] = '{:.2%}'\
                            .format(time_ratio) # progress text
                        self.store[self.Iter][C_PULS] = -1 # progress pusle
            
            # mencoder progress
            elif encoder_type == 'm':
                begin = line.find('Pos:')
                if begin != -1:
                    # Print details
                    self.label_details.set_text(line.strip())
                    
                    #--- Get file size
                    file_size = self.reg_menc.findall(line)[0][2]
                    
                    #--- Get remaining time
                    dur = self.reg_menc.findall(line)[0][0]
                    rem_dur = self.total_duration - float(dur)
                    rem_time = duration_to_time(rem_dur)
                    
                    #--- Progress
                    prog_value = float(self.reg_menc.findall(line)[0][1])
                    
                    self.store[self.Iter][C_SIZE] = file_size + ' MB'
                    self.store[self.Iter][C_REMN] = rem_time
                    self.store[self.Iter][C_PRGR] = prog_value
                    if self.pass_nbr != 0:
                        self.store[self.Iter][C_STAT] = '{:.2f}% (P{})'\
                        .format(prog_value, self.pass_nbr)
                    else:    
                        self.store[self.Iter][C_STAT] = '{:.2f}%'.format(prog_value)
                    self.store[self.Iter][C_PULS] = -1
            
            #--- Append conversion details 
            self.output_details += line
            return True
        # When len(line) == 0
        return False

    
    #--- Drag and drop callback
    def drop_data_cb(self, widget, dc, x, y, selection_data, info, t):
        for i in selection_data.get_uris():
            if i.startswith('file://'):
                File = unquote(i[7:])
                if isfile(File):
                    self.store.append([True, File, None, None, 0.0,
                                       _('Ready!')])
                # Save directory from dragged filename.
                self.curr_open_folder = dirname(File)
    
    def on_cb_dest_toggled(self, widget):
        Active = not widget.get_active()
        self.e_dest.set_sensitive(Active)
        self.b_dest.set_sensitive(Active)
    
    def combo_encoder_cb(self, combo):
        self.encoder = combo.get_active_text()
    
    def on_cb_video_only_toggled(self, cb):
        self.vb_audio.set_sensitive(not cb.get_active())
    
    def force_delete_file(self, file_name):
        ''' Force delete file_name '''
        while os.path.exists(file_name):
            try:
                os.unlink(file_name)
            except OSError:
                continue
    
    def per_to_vol(self, percent):
        # 100 --> 256, 200 --> 512, 300 --> 768 ...
        return '{}'.format((256 * int(percent)) / 100)

    def get_aspect_ratio(self, input_file):
        ''' extract adpect ratio from file if exist, otherwise use 4:3 
        (fix a problem) '''
        cmd = '{} -i {}'.format(self.encoder, input_file)
        Proc = Popen(cmd, stdout=PIPE, stderr=PIPE, shell=True)
        out_str = Proc.stderr.read()
        try:
            reg_aspect = re.compile('''DAR\s+(\d*:\d*)''')
            return reg_aspect.findall(out_str)[0]
        except:
            return '4:3'
    
    def enable_controls(self, sens=True):
        self.cmb_formats.set_sensitive(sens)
        self.cmb_quality.set_sensitive(sens)
        self.e_dest.set_sensitive(sens)
        self.b_dest.set_sensitive(sens)
        self.cb_dest.set_sensitive(sens)
        
        self.vb_audio.set_sensitive(sens)
        self.vb_video.set_sensitive(sens)
        self.vb_sub.set_sensitive(sens)
        self.vb_other.set_sensitive(sens)
    
    def save_options(self):
        conf = ConfigParser()
        conf.read(OPTS_FILE)
        
        if not conf.has_section('configs'):
            conf.add_section('configs')
        
        conf.set('configs', 'curr_open_folder', self.curr_open_folder)
        conf.set('configs', 'curr_save_folder', self.curr_save_folder)
        conf.set('configs', 'e_dest_text', self.e_dest.get_text())
        conf.set('configs', 'cmb_formats_ind', self.cmb_formats.get_active())
        conf.set('configs', 'cb_same_dest_on', self.cb_dest.get_active())
        conf.set('configs', 'cb_same_qual_on', self.cb_same_qual.get_active())
        conf.set('configs', 'overwrite_mode', self.cmb_exist.get_active())
        
        with open(OPTS_FILE, 'w') as configfile:
            conf.write(configfile)
        
        
    
    def load_options(self):
        conf = ConfigParser()
        conf.read(OPTS_FILE)
        
        try:
            self.curr_open_folder = conf.get('configs', 'curr_open_folder')
        except:
            self.curr_open_folder = HOME
        try:
            self.curr_save_folder = conf.get('configs', 'curr_save_folder')
        except:
            self.curr_save_folder = HOME
        try:
            self.e_dest.set_text(conf.get('configs', 'e_dest_text'))
            self.cmb_formats.set_active(conf.getint('configs', 'cmb_formats_ind'))
            self.cb_dest.set_active(conf.getboolean('configs',
                                                         'cb_same_dest_on'))
            self.cb_same_qual.set_active(conf.getboolean('configs',
                                                            'cb_same_qual_on'))
            self.cmb_exist.set_active(conf.getboolean('configs',
                                                            'overwrite_mode'))
        except NoOptionError as err:
            print(err)
        except NoSectionError as err:
            print(err)


def main():
    Curlew()
    Gtk.main()

if __name__ == '__main__':
    main()
