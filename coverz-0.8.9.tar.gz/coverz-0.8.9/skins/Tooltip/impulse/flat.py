fft = False
bar_width = 12
bar_spacing = 3
fg_color = 0.0, 0.6, 1.0, 0.8

def on_draw(audio_sample_array, cr, widget):
    cr.set_source_rgba(fg_color[0], fg_color[1], fg_color[2], fg_color[3])

    _w,_h = widget.get_width(), widget.get_height()
    _nbars = int(_w /(bar_width +bar_spacing))
    l = len(audio_sample_array)
    for i in range(0, l, l /_nbars):
        bar_amp_norm = audio_sample_array[i]
        bar_height = bar_amp_norm *_h +2
      
        cr.rectangle((bar_width +bar_spacing) *(i /(l /_nbars)),
            _h /2 -bar_height /2, bar_width, bar_height)
    cr.fill()
    cr.stroke()
