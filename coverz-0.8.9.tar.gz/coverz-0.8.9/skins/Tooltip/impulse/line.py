fft = True
num_bars = 32
bar_width = 2
fg_color = 0.0, 0.6, 1.0, 0.8

import math

def on_draw(audio_sample_array, cr, widget):
    cr.set_source_rgba(fg_color[0], fg_color[1], fg_color[2], fg_color[3])
    cr.set_line_width(bar_width)

    l = len(audio_sample_array)
    _w,_h = widget.get_width(), widget.get_height()
    fx = 0
    fy = 0
    fr = 10
    for i in range(0, l, l/num_bars):
        bar_amp_norm = audio_sample_array[i]
        bar_height = bar_amp_norm *_w

        a = (math.pi *2 /num_bars) *(i /(l /num_bars))
        x = math.sin(a) *(fr +bar_height) +(_w /2)
        y = math.cos(a) *(fr +bar_height) +(_h /2)

        if not i:
            fx, fy = x, y
            cr.move_to(x, y)
        cr.curve_to(x, y, x, y, x, y)
    cr.curve_to(fx, fy, fx, fy, fx, fy)
    cr.stroke()
