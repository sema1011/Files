fft = True
num_bars = 24
bar_width = 6
bar_spacing = 2
arc_width = 16
fg_color = 0.0, 0.6, 1.0, 0.8

import math

def on_draw(audio_sample_array, cr, widget):
    cr.set_source_rgba(fg_color[0], fg_color[1], fg_color[2], fg_color[3])
    cr.set_line_width(bar_width -2)

    _w,_h = widget.get_width(), widget.get_height()
    l = len(audio_sample_array)
    for i in range(0, l, l /num_bars):
        bar_amp_norm = audio_sample_array[i]
        bar_height = bar_amp_norm *(_h*bar_width) +5

        for j in range(0, int(bar_height /5)):
            cr.arc(_w /2, _h /2, arc_width +j*5,
                (math.pi *2 /num_bars) *(i /(l /num_bars)),
                (math.pi *2 /num_bars) *(i /(l /num_bars) +1) -.05)
            cr.stroke()
