fft = True
amp = 0.25

bar_width = 16
bar_spacing = 1

row_height = 2
row_spacing = 1

fg_color = 0.75, 0.75, 0.75, 0.65
bg_color = 0.25, 0.25, 0.25, 0.65
peak_color = 1.0, 1.0, 1.0, 0.8

peak_int = [0 for i in range(256)]
peak_float = [0.0 for i in range(256)]

def on_draw(audio_sample_array, cr, widget):
    cr.set_source_rgba(bg_color[0], bg_color[1], bg_color[2], bg_color[3])

    sw, sh = widget.get_width(), widget.get_height()
    n_bars = int(sw /(bar_width +bar_spacing))
    n_rows = int(sh /(row_height +row_spacing))
    slide = 2 #!slide array values
    len_array = len(audio_sample_array)/slide +slide
    step = len_array /(n_bars -1)

    for i in range(0, len_array, step):
        bar = i /step
        for row in range(0, int(n_rows)):
            cr.rectangle(bar *(bar_width+bar_spacing),
                sh -row *(row_height+row_spacing), bar_width, -row_height)
    cr.fill()
    cr.set_source_rgba(fg_color[0], fg_color[1], fg_color[2], fg_color[3])

    for i in range(0, len_array, step):
        rows = audio_sample_array[i+slide] *256 /n_rows
        if rows > n_rows: rows = n_rows
        elif rows < amp: rows = rows *float(n_rows) #!amplify
        bar = i /step
        for row in range(0, int(rows)):
            cr.rectangle(bar *(bar_width+bar_spacing),
                sh -row *(row_height+row_spacing), bar_width, -row_height)
    cr.fill()
    if peak_color == fg_color:
        cr.fill(); cr.stroke(); return
    cr.set_source_rgba(peak_color[0], peak_color[1], peak_color[2], peak_color[3])

    for i in range(0, len_array, step):
        rows = audio_sample_array[i+slide] *256 /n_rows
        if rows > n_rows: rows = n_rows
        elif rows < amp: rows = rows *float(n_rows) #!amplify
        bar = i /step
        if rows > peak_int[i]:
            peak_int[i] = rows -1
            peak_float[i] = 0.0
        else:
            peak_float[i]+= .1
            peak_int[i] -= peak_float[i]
        if peak_int[i] < 0:
            peak_int[i] = 0
        cr.rectangle(bar *(bar_width+ bar_spacing),
            sh -peak_int[i] *(row_height+row_spacing), bar_width, -row_height)
    cr.fill()
    cr.fill()
    cr.stroke()
