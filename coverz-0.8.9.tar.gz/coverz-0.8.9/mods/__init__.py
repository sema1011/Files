# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Logger:

    colors = {
        'reset'     : '\x1b[0m',
        'bold'      : '\x1b[01m',
        'redbold'   : '\x1b[31;01m',
        'red'       : '\x1b[31;06m',
        'greenbold' : '\x1b[32;01m',
        'green'     : '\x1b[32;06m',
        'yellowbold': '\x1b[33;01m',
        'yellow'    : '\x1b[33;06m',
        'bluebold'  : '\x1b[34;01m',
        'blue'      : '\x1b[34;06m',
        }

    def __init__(self, debug=False):
        #global self.__log
        self.__log = debug

    def lprint(self, msg, f, cl):
        if self.__log:
            print '%s[%s]\x1b[0m %s' % (self.colors[cl], f, msg)
        else:
            print msg

    def info(self, msg):
        self.lprint(msg, 'INFO', 'green')

    def debug(self, msg):
        if self.__log:
            self.lprint(msg, 'DEBUG', 'blue')

    def error(self, msg='Error'):
        if self.__log:
            import traceback
            msg = traceback.format_exc()
        self.lprint(msg, 'ERROR', 'red')
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gobject
gobject.threads_init()
import thread

#from mods import configs
from mods import cfg
configs = cfg.SafeParser()
configs.load()

#from mods import log
log = Logger(configs.getboolean('APP', 'debug'))

from players import Track

COVER, PLAYER, STATE, TIME, TRACK = range(5)
STARTED, PLAYING, PAUSED, STOPPED, CLOSED = range(5)

class Server(object):

    def __init__(self, target, callback, *args):
        super(Server, self).__init__()

        self.target = target
        self.callback = callback
        self.args = args

    def __call__(self, *args):
        if self.callback != None:
            args += self.args
            self.callback(*args)

class Thread(object):

    cover   = None
    player  = None
    state   = CLOSED
    track   = Track()
    time    = 0

    _players = []
    _plugins = []
    _servers = [], [], [], [], []
    _track   = Track()
    _lister  = 0
    _timer   = 0

    def __init__(self):
        super(Thread, self).__init__()

        log.info('D-Bus starting...')
        self.init_dbus()

        if configs.getboolean('APP', 'autoplug'):
            log.info('Players loading...')
            for p in cfg.listdir('players'):
                self._add_player(p)
            self.init_listener()
        self.init_player(configs.get('APP', 'player'))

        if configs.get('APP', 'plugins'):
            log.info('Plugins loading...')
            for p in configs.get('APP', 'plugins').split(','):
                if p != '': self.init_plugin(p)
        else:
            from plugins import CoverPlugin
            self._plugins.append(CoverPlugin(self))

        self.attach(STATE, self.update_state)
        self.attach(TRACK, self.update_track)

        log.info('Skin loading...')
        self.init_skin()

    def init_dbus(self):
        import dbus
        from dbus.mainloop.glib import DBusGMainLoop

        dbus.set_default_main_loop(DBusGMainLoop(set_as_default=True))
        self.dbus_obj = dbus.SessionBus().get_object('org.freedesktop.DBus',
            '/org/freedesktop/DBus')

    def _add_player(self, p):
        try:
            p = __import__('players.' +p, fromlist=['players']).__dict__[p]
            if p.DBUS_NAME:
                self._players.append(p)
                log.debug(p.DBUS_NAME)
        except Exception, err:
            log.error(err)

    def _check_player(self):
        for p in self._players:
            if p.DBUS_NAME in self.dbus_obj.ListNames() \
            and p.DBUS_NAME != self.player.DBUS_NAME:
                self.player.close()
                #log.debug(p.__name__)
                self.init_player(p.__name__)
                if self._lister:
                    gobject.source_remove(self._lister)
                    self._lister = 0
                break
        return True#!callback(*args) not be bool

    def init_listener(self):
         if self._players and not self._lister:
            self._lister = gobject.timeout_add(10000, self._check_player)

    def init_player(self, p):
        try:
            self.player = __import__('players.' +p,
                fromlist=['players']).__dict__[p](self)
            #self.update(PLAYER, self.player)#!exception on callback(*args) 
            gobject.idle_add(self.update_player)
            log.debug("__import__.players." +p)
        except Exception, err:
            log.error(err)

    def init_plugin(self, p):
        try:
            p = __import__('plugins.' +p, fromlist=['plugins']).__dict__[p]
            self._plugins.append(p(self))
            log.debug("__import__.plugins." +p.__name__)           
        except Exception, err:
            log.error(err)

    def init_skin(self):
        from mods.skin import Skin
        self.skin = Skin(self)
        try:
            self.skin.get_skin_xml(cfg.USR_PATH)
            log.info("Ready ;)")
        except Exception, err:
            log.error(err)
            exit()

        from mods.gui import Window
        self.window = Window(self, self.skin)

    def init_timer(self):
        if self._timer:
            gobject.source_remove(self._timer)
            self._timer = 0
            if self.state > PAUSED:
                self.time = 0
                self.update(TIME, self.time)

        if self.state < PAUSED and 'time' in self.player.capabilities and \
            len(self._servers[TIME]) > 0:
            self._timer = gobject.timeout_add(1000, self.update_time)
            self.update_time()
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def attach(self, target, callback, *args):
        ob = Server(target, callback, *args)
        self._servers[target].append(ob)

        if target == TIME:
            self.init_timer()
        return ob

    def detach(self, server):
        self._servers[server.target].remove(server)
        if server.target == TIME:
            self.init_timer()

    def update(self, target, *args):
        for callback in self._servers[target]:
            #try: print target, args
            #except: pass         
            try: callback(*args)
            except Exception, err: log.error(err)
        return False

    def update_lyric(self):
        if len(self._plugins) == 2 and self.track.path:
            thread.start_new_thread(self._plugins[1].get, (self.track,))

    def update_player(self):
        try: state = self.player.get_state()
        except: state = CLOSED

        if state in (PLAYING, PAUSED):
            track = self.player.get_track()
        else:
            track = self._track

        self.update(TRACK, track)
        self.update(STATE, state)

    def update_state(self, state):      
        if self.state != state:
            self.state = state
            if state == STARTED:
                self.update_player()                
            elif state >= STOPPED:
                self.update(TRACK, self._track)
                if state == CLOSED:
                    self.init_listener()
            self.init_timer()

    def update_time(self):
        time = self.player.get_position()
        if self.time != time:
            self.time = time
            self.update(TIME, time)
        return True

    def update_track(self, track):
        if self.track != track:
            self.track = track
            if track.cover:            
                self.update(COVER, track.cover)
            elif self._plugins and track.path:
                thread.start_new_thread(self._plugins[0].get, (track,))
            else:
                self.update(COVER, self.cover)
        return False
