# -*-coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import cairo
import gobject
from gtk import gdk

from mods.widgets import Widget

class Slider(Widget):

    __gsignals__ = {
        'value-changed': (gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, (int,)),
        }

    _val = 0
    _max = 1

    _background = None
    _foreground = None
    _thumb = None

    _bg_path = None
    _fg_path = None

    _thumb_path = None
    _thumb_size = None

    _top = 0
    _bottom = 0
    _left = 0
    _right = 0


    size = None

    def __init__(self, src, filled, size):
        super(Slider, self).__init__(size)

        if src:
            self._bg_path = src
        if filled:
            self._fg_path = filled

        self.set_size_request(self.get_width(), self.get_height())
        self._load()

    def get_x(self):
        if self._left < 0:
            return self._size.x +self._left
        return self._size.x

    def get_y(self):
        if self._top < 0:
            return self._size.y +self._top
        return self._size.y

    def _load(self):
        if self._bg_path:
            self._background = gdk.pixbuf_new_from_file_at_scale(self._bg_path,
                self._size.width, self._size.height, False)
        if self._fg_path:
            self._foreground = gdk.pixbuf_new_from_file_at_scale(self._fg_path,
                self._size.width, self._size.height, False)

    def _load_thumb(self):
        self._thumb = gdk.pixbuf_new_from_file_at_scale(self._thumb_path,
            self._thumb_size.width, self._thumb_size.height, False)

    def set_max(self, m):
        if m > 1:
            self._max = float(m)
            self._val = 0.0
            self.queue_draw()
        else:
            self._max = 1

    def set_value(self, val):
        self._val = min(val, self._max) if val >= 0 else 0
        self.queue_draw()

    def set_thumb(self, thumb, size):
        self._thumb_path = thumb
        self._top, self._left = size.x, size.y
        self._thumb_size = size
        self._load_thumb()
        self.set_size_request(self.get_width(), self.get_height())

    def do_button_press_event(self, event):
        return True

    def do_expose_event(self, event):
        raise NotImplementedError

    def do_button_release_event(self, event):
        raise NotImplementedError

class HSlider(Slider):

    def get_width(self):
        width = self._size.width
        if self._left < 0:
            width += -self._left
        return width

    def get_height(self):
        height = self._size.height
        if self._top < 0:
            height += -self._top
        if self._thumb_size and height < self._thumb_size.height:
            height = self._thumb_size.height
        return height

    def do_expose_event(self, event):
        width = int(self._val *self._size.width /self._max)
        cr = event.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        cr.clip()
        cr.save()
        cr.translate(self._size.x, self._size.y)

        if self._background:
            cr.set_source_pixbuf(self._background, 0, 0)
            cr.paint()

        if self._foreground:
            cr.rectangle(0, 0, width, self._size.height)
            cr.clip()
            cr.set_source_pixbuf(self._foreground, 0, 0)
            cr.paint()

        if self._thumb:
            cr.restore()
            w = self._size.width -self._thumb_size.width -self._left
            x = self._size.x +self._left +int(self._val *w /self._max)
            cr.translate(x, self._size.y +self._top)
            cr.set_source_pixbuf(self._thumb, 0, 0)
            cr.paint()

    def do_button_release_event(self, event):
        if event.button == 1:
            x = event.x +self._left if self._left < 0 else event.x
            if x <= self._size.width:
                self.emit('value-changed', x *self._max /self._size.width)
        return True

class VSlider(Slider):

    def get_width(self):
        width = self._size.width
        if self._left < 0:
            width += -self._left
        if self._thumb_size and width < self._thumb_size.width:
            width = self._thumb_size.width
        return width

    def get_height(self):
        height = self._size.height
        if self._top < 0:
            height += -self._top
        return height

    def do_expose_event(self, event):
        height = int(self._val *self._size.height /self._max)
        cr = event.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
                     event.area.width, event.area.height)
        cr.clip()
        cr.save()
        cr.translate(self._size.x, self._size.y)

        if self._background:
            cr.set_source_pixbuf(self._background, 0, 0)
            cr.paint()

        if self._foreground:
            cr.rectangle(0, self._size.height -height, self._size.width, height)
            cr.clip()
            cr.set_source_pixbuf(self._foreground, 0, 0)
            cr.paint()

        if self._thumb:
            cr.restore()
            h = self._size.height -self._thumb_size.height -self._top
            y = self._size.y +self._top +h -int(self._val *h /self._max)
            cr.translate(self._size.x +self._left, y)
            cr.set_source_pixbuf(self._thumb, 0, 0)
            cr.paint()

    def do_button_release_event(self, event):
        if event.button == 1:
            y = event.y +self._top if self._top < 0 else event.y
            y = self._size.height -y
            if 0 <= y <= self._size.height:
                self.emit('value-changed', y *self._max /self._size.height)
        return True

gobject.type_register(HSlider)
gobject.type_register(VSlider)
