# -*-coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import cairo
import gobject
from gtk import gdk

import pango
from pango import ALIGN_LEFT, ALIGN_CENTER, ALIGN_RIGHT

from mods.widgets import Widget

VALIGN_TOP, VALIGN_MIDDLE, VALIGN_BOTTOM = range(3)
SCROLL_GAP = 40

class Text(Widget):
    ELLIPSIZE_WORD = 1
    ELLIPSIZE_CHAR = 2

    _scroll = False
    _ellipsize = False

    _scroll_id = 0
    _scroll_timer = 70

    _offset_x = 0

    _surface = None

    _color = None
    _shadow = None

    _shadow_x = 1
    _shadow_y = 1

    _maxchars = 0
    _wrap = False

    _align = ALIGN_LEFT
    _valign = VALIGN_TOP

    _layout = None

    def __init__(self, size):
        super(Text, self).__init__(size)

        self._color = (1,1,1,1)
        self._layout = self.create_pango_layout('')
        self.set_font('monospace 12')
        self._font_size = self._layout.get_font_description().get_size()
        self._layout.set_wrap(pango.WRAP_WORD_CHAR)

        self.set_size_request(self.get_width(), self.get_height())
        #elf._load()

    def get_height(self):
        if self._reflect:
            return self._size.height +self._reflect.gap +self._reflect.height
        else:
            return self._size.height

    def set_font(self, font):
        _font = pango.FontDescription(font)
        self._layout.set_font_description(_font)
        self._font_size = _font.get_size()

    def set_color(self, color):
        self._color = color

    def set_shadow_color(self, color):
        self._shadow = color

    def set_shadow_offset(self, x, y):
        self._shadow_x = x
        self._shadow_y = y

    def set_align(self, align):
        if align == 'left':
            self._align = ALIGN_LEFT
        elif align == 'center':
            self._align = ALIGN_CENTER
        elif align == 'right':
            self._align = ALIGN_RIGHT
        self._layout.set_alignment(self._align)

    def set_valign(self, valign):
        if valign == 'top':
            self._valign = VALIGN_TOP
        elif valign == 'middle':
            self._valign = VALIGN_MIDDLE
        elif valign == 'bottom':
            self._valign = VALIGN_BOTTOM

    def set_maxchars(self, maxchars):
        if maxchars > 0:
            self._maxchars = maxchars

    def set_wrap(self, wrap):
        if wrap:
            self._wrap = True
            if self._size.width:
                self._layout.set_width(self._size.width)
        else:
            self._wrap = False
            self._layout.set_width(-1)

    def set_ellipsize(self, ellipsize):
        self._ellipsize = ellipsize

    def set_scroll(self, scroll):
        self._scroll = scroll

    def set_text(self, text):
        if self._maxchars:
            text = text.decode('utf-8')
            if len(text) > self._maxchars:
                text = text[:self._maxchars-3] +'...'
            text = text.encode('utf-8')

        self._layout.set_text(text)
        self._draw()

    def set_time(self, time):
        self.set_text('%02d:%02d' % (time/60, time%60))

    def _draw(self):
        w, h = self._layout.get_pixel_size()

        if self._size.width:
            width = self._size.width
        else:
            width = w
        if self._size.height:
            height = self._size.height
        else:
            height = h

        if self._reflect:
            self.set_size_request(width, height +self._reflect.gap +self._reflect.height)
        else:
            self.set_size_request(width, height)

        if w > width and not self._wrap:
            if self._ellipsize:
                self._ellipsize_text(width)
                w, h = self._layout.get_pixel_size()
            elif self._scroll and not self._scroll_id:
                self._scroll_id = gobject.timeout_add(self._scroll_timer, self._scroll_text)
                self._offset_x = 0
        elif self._scroll_id:
            gobject.source_remove(self._scroll_id)
            self._scroll_id = 0

        if self._wrap or self._align == ALIGN_LEFT or width <= w:
            x = 0
        elif self._align == pango.ALIGN_CENTER:
            x = (width -w) /2
        elif self._align == pango.ALIGN_RIGHT:
            x = width -w

        if self._valign == VALIGN_TOP or height <= h:
            y = 0
        elif self._valign == VALIGN_MIDDLE:
            y = (height -h) /2
        elif self._valign == VALIGN_BOTTOM:
            y = height -h

        if width > w:
            w = width
        if height > h:
            h = height

        self._surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
        cr = gdk.CairoContext(cairo.Context(self._surface))
        if self._shadow:
            self._draw_text(cr, self._shadow, x +self._shadow_x, y +self._shadow_y)
        self._draw_text(cr, self._color, x, y)

        self.queue_draw()

    def do_expose_event(self, event):
        cr = self.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
                     event.area.width, event.area.height)
        cr.clip()
        cr.translate(self._size.x, self._size.y)
        if self._scroll_id:
            width, height = self.get_size_request()
            x = -self._offset_x
            while x < width:
                cr.set_source_surface(self._surface, x, 0)
                cr.paint()
                if self._reflect:
                    self._draw_reflection(cr, x, 0)
                x += self._surface.get_width() +SCROLL_GAP
        else:
            cr.set_source_surface(self._surface, 0, 0)
            cr.paint()
            if self._reflect:
                self._draw_reflection(cr, 0, 0)
        return True

    def _draw_reflection(self, cr, x, y):
        cr.save()
        height = self._surface.get_height()
        cr.translate(0, y +height +self._reflect.gap)
        cr.scale(1, -1)
        linear = cairo.LinearGradient(0, height, 0, height -self._reflect.height)
        linear.add_color_stop_rgba(0, 0, 0, 0, self._reflect.alpha)
        linear.add_color_stop_rgba(1, 0, 0, 0, 0)
        cr.set_source_surface(self._surface, x, y)
        cr.mask(linear)
        cr.restore()

    def _draw_text(self, ctx, color, x, y):
        ctx.save()
        ctx.translate(x,y)
        ctx.set_source_rgba(color[0], color[1], color[2], color[3])
        ctx.show_layout(self._layout)
        ctx.restore()

    def _scroll_text(self):
        self._offset_x += 1
        if self._offset_x >= self._surface.get_width():
            self._offset_x -= self._surface.get_width() +SCROLL_GAP
        self.queue_draw()

        return True

    def _ellipsize_text(self, width):
        text = self._layout.get_text()
        pos = len(text)
        if self._ellipsize == Text.ELLIPSIZE_WORD:
            pos = text.rfind(' ', 0, pos)
        else:
            pos -= 1
        while pos > 0:
            tmp = text[0:pos] +'...'
            self._layout.set_text(tmp)
            w, h = self._layout.get_pixel_size()
            if w < width:
                pos = -1
            elif self._ellipsize == Text.ELLIPSIZE_WORD:
                pos = text.rfind(' ',0, pos)
            else:
                pos -= 1

    def do_destroy(self):
        if self._scroll_id:
            gobject.source_remove(self._scroll_id)

gobject.type_register(Text)
