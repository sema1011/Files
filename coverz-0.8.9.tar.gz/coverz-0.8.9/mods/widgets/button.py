# -*-coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import cairo
import gobject
from gtk import gdk

from mods.widgets import Widget

class Button(Widget):

    __gsignals__ = {
        'clicked' : (gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, [])
        }

    _current = None
    _normal = None
    _hover = None
    _hovered = False
    _pressed = None

    def __init__(self, size, normal, hover, pressed):
        super(Button, self).__init__(size)

        if normal:
            self._normal = gdk.pixbuf_new_from_file_at_scale(normal,
                self._size.width, self._size.height, False)
        if hover:
            self._hover = gdk.pixbuf_new_from_file_at_scale(hover,
                self._size.width, self._size.height, False)
        if pressed:
            self._pressed = gdk.pixbuf_new_from_file_at_scale(pressed,
                self._size.width, self._size.height, False)

        self._current = self._normal
        self.set_size_request(self.get_width(), self.get_height())
        self.queue_draw()

    def get_height(self):
        if self._reflect:
            return self._size.height +self._reflect.gap +self._reflect.height
        else:
            return self._size.height

    def do_button_press_event(self, event):
        if event.button == 1 and self._pressed:
            self._current = self._pressed
            self.queue_draw()
        return True

    def do_button_release_event(self, event):
        if event.button == 1:
            if self._pressed:
                self._current = self._normal
                self.queue_draw()
            if event.x <= self._size.width and event.y <= self._size.height:
                self.emit('clicked')
        return True

    def do_enter_notify_event(self, event):
        if self._hover:
            self._current = self._hover
            self._hovered = True
            self.queue_draw()
        return True

    def do_leave_notify_event(self, event):
        self._hovered = False
        if self._hover:
            self._current = self._normal
            self.queue_draw()
        return True

    def do_expose_event(self, event):
        if self._current:
            cr = event.window.cairo_create()
            cr.rectangle(event.area.x, event.area.y,
                         event.area.width, event.area.height)
            cr.clip()
            cr.translate(self._size.x, self._size.y)
            cr.set_source_pixbuf(self._current, 0, 0)
            cr.paint()

            if self._reflect:
                cr.translate(0, 2 *self._size.height +self._reflect.gap)
                cr.scale(1, -1)
                linear = cairo.LinearGradient(0, self._size.height,
                    0, self._size.height -self._reflect.height)
                linear.add_color_stop_rgba(0, 0, 0, 0, self._reflect.alpha)
                linear.add_color_stop_rgba(1, 0, 0, 0, 0)
                cr.set_source_pixbuf(self._current, 0, 0)
                cr.mask(linear)

        return True

class StateButton(Button):

    def __init__(self, size):
        self._state = None
        self._states = {}
        self._paths = {}
        super(StateButton, self).__init__(size, None, None, None)

    def add_state(self, state, normal, hover, pressed):
        if normal or hover or pressed:
            self._paths[state] = (normal, hover, pressed)
            if self._state is None:
                self._state = state

            self._states[state] = self._load_images(self._paths[state])

        for state, paths in self._paths.iteritems():
            imgs = self._load_images(paths)
            self._states[state] = imgs
            if self._state == state:
                self._normal, self._hover, self._pressed = imgs
                self._current = self._normal

        self.queue_draw()

    def _load_images(self, paths):
        imgs = [None, None, None]

        if paths[0]:
            imgs[0] = gdk.pixbuf_new_from_file_at_scale(paths[0],
                self._size.width, self._size.height, False)
        if paths[1]:
            imgs[1] = gdk.pixbuf_new_from_file_at_scale(paths[1],
                self._size.width, self._size.height, False)
        if paths[2]:
            imgs[2] = gdk.pixbuf_new_from_file_at_scale(paths[2],
                self._size.width, self._size.height, False)

        return imgs

    def set_state(self, state):
        if state in self._states and self._state != state:
            self._state = state
            self._normal, self._hover, self._pressed = self._states[state]
            if self._hovered and self._hover:
                self._current = self._hover
            else:
                self._current = self._normal
            self.queue_draw()

gobject.type_register(Button)
gobject.type_register(StateButton)
