# -*-coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import cairo
import gobject
from gtk import gdk

from mods.widgets import Widget

STARS = 5

class Rating(Widget):

    __gsignals__ = {
        'set_rating': (gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, (int,)),
        }

    _clickable = False

    _star = None
    _starred = None

    _star_path = None
    _starred_path = None

    _spacing = 0
    _src_spacing = 0
    _rating = 0
    _old_rating = 0

    _reflect = None

    def __init__(self, star, starred, size, spacing):
        super(Rating,self).__init__(size)

        self._star_path = star
        self._starred_path = starred
        
        #self.connect('motion_notify_event', self.motion_notify_event)
        self.set_events(gdk.BUTTON_PRESS_MASK)
        #print 'gtk.gdk.mask', self.get_events()

        self._spacing = spacing

        self.set_size_request(self.get_width(), self.get_height())
        self._load()

    def _load(self):
        self._star = gdk.pixbuf_new_from_file_at_scale(self._star_path,
            self._size.width, self._size.height, False)

        self._starred = gdk.pixbuf_new_from_file_at_scale(self._starred_path,
            self._size.width, self._size.height, False)

        self._current = self._star

        self.set_size_request(self.get_width(), self.get_height())
        self.queue_draw()

    def do_expose_event(self, event):
        raise NotImplementedError

    def do_button_press_event(self, event):
        if True:#self._clickable:
            rating = self.check_rating(event)
            self.set_rating(rating)
            self.emit('set_rating', rating)
            self.queue_draw()
        #print 'Rating do_button_press_event()'

    def do_button_release_event(self, event):
        pass
        #print 'Rating do_button_release_event()'

    def do_enter_notify_event(self, event):
        pass
        #if self._clickable:
        #self.queue_draw()
        #print 'Rating do_enter_notify_event()'

    def do_leave_notify_event(self, event):
        pass
        #if self._clickable:
        #self.queue_draw()
        #self.set_rating(self._old_rating)
        #print 'Rating do_leave_notify_event()'

    def set_rating(self, rating, tmp=False):
        if not tmp:
            self._old_rating = rating
        self._rating = rating
        self.queue_draw()

    def check_rating(self, event):
        raise NotImplementedError

    def set_clickable(self, clickable):
        self._clickable = clickable

class HRating(Rating):

    def do_expose_event(self, event):
        cr = self.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        cr.clip()
        w = 0

        for i in range(1, STARS +1):
            if i <= self._rating:
                _star = self._starred
            else:
                _star = self._star

            cr.set_source_pixbuf(_star, self._size.x +w, self._size.y)
            cr.paint()
            w += self._size.width +self._spacing

        # TODO draw reflection
        return True

    def get_width(self):
        return (self._size.width *STARS) +(self._spacing *(STARS -1))

    def get_height(self):
        if self._reflect:
            return self._size.height +self._reflect.gap +self._reflect.height
        else:
            return self._size.height

    def check_rating(self, event):
        rating = 0
        w = 0
        while event.x > w and rating < STARS:
            rating += 1
            w += self._spacing +self._size.width
        return rating

class VRating(Rating):

    def do_expose_event(self, event):
        cr = self.window.cairo_create()
        cr.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        cr.clip()
        cr.translate(self._size.x, self._size.y)
        h = 0

        for i in range(STARS, 0, -1):
            if i <= self._rating:
                _star = self._starred
            else:
                _star = self._star

            cr.set_source_pixbuf(_star, 0, h)
            cr.paint()
            h += self._size.height +self._spacing

        #TODO draw reflection
        if self._reflect:
            h -= self._spacing
            cr.translate(0, 2 *h +self._reflect.gap)
            cr.scale(1, -1)
            linear = cairo.LinearGradient(0, h, 0, h -self._reflect.height)
            linear.add_color_stop_rgba(0, 0, 0, 0, self._reflect.alpha)
            linear.add_color_stop_rgba(1, 0, 0, 0, 0)
            #h = 2 * h +self._reflect.gap
            h = 0
            for i in range(STARS, 0, -1):
                if i <= self._rating:
                    img = self._current
                else:
                    img = self._starred
                cr.set_source_pixbuf(img, 0, h)
                cr.mask(linear)
                h += self._size.height +self._spacing

        return True

    def get_width(self):
        return self._size.width

    def get_height(self):
        if self._reflect:
            return (self._size.height *STARS) +(self._spacing *(
                STARS -1)) +self._reflect.gap +self._reflect.height
        else:
            return (self._size.height *STARS) +(self._spacing *(STARS -1))

    def check_rating(self, event):
        rating = STARS +1
        h = 0
        while event.y > h:
            rating -= 1
            h += self._spacing +self._size.height
        return rating

gobject.type_register(HRating)
gobject.type_register(VRating)
