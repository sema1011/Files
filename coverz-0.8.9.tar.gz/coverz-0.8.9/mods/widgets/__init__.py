# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
#from gtk.gdk import pixbuf_get_file_info
#info, w, h = pixbuf_get_file_info(path)

class Rectangle(gtk.gdk.Rectangle):

    def __init__(self, x=0, y=0, width=0, height=0):
        super(Rectangle, self).__init__(x, y, width, height)
        self.src = gtk.gdk.Rectangle(x, y, width, height)

    def set_x(self, x):
        self.x = x
        self.src.x = x

    def set_y(self, y):
        self.y = y
        self.src.y = y

    def set_width(self, width):
        self.width = width
        self.src.width = width

    def set_height(self, height):
        self.height = height
        self.src.height = height

class Reflection:

    gap = 0
    height = 0
    alpha = 1.0
    resize = 1.0

    _src_gap = 0
    _src_height = 0
    _src_resize = 0

    def __init__(self, str):        
        ref = str.replace('-', ',').split(',')
        self.gap = int(ref[0])
        self._src_gap = int(ref[0])
        self.height = int(ref[1])
        self._src_height = int(ref[1])
        self.alpha = float(ref[2])/100
        self.resize = 1.0
        self._src_resize = 1.0

class Widget(gtk.EventBox):

    _size = None
    _reflect = None

    def __init__(self, size):
        super(Widget, self).__init__()
        self._size = size
        self.set_visible_window(False)
        self.set_size_request(size.width, size.height)

    def get_x(self):
        return self._size.x

    def get_y(self):
        return self._size.y

    def get_width(self):
        return self._size.width

    def get_height(self):
        return self._size.height

    def set_reflect(self, reflect):
        self._reflect = reflect
        self.set_size_request(self.get_width(), self.get_height())
        self.queue_draw()
