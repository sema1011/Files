# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gobject
import mpd #!depends python-mpd

from mods import configs
from mods import log
from players import Player, Track

COVER, PLAYER, STATE, TIME, TRACK = range(5)
STARTED, PLAYING, PAUSED, STOPPED, CLOSED = range(5)

class MPD(Player):

    _client = None
    _data = {}
    _state = ''
    _track = Track()
    _player = None

    def is_active(self, name=''):
        if not self._player:
            time = configs.getint('MPD', 'timeout')
            self._player = gobject.timeout_add(time *1000, self.update)
        return True

    def __connect(self):
        host = configs.get('MPD', 'host')
        port = configs.getint('MPD', 'port')
        password = configs.get('MPD', 'password')
        self._path = configs.get('MPD', 'path')
        if self._path[-1:] == '/':
            self._path = self._path[:-1]
        if self._client:
            self._client.disconnect()
        self._client = mpd.MPDClient()
        self._client.connect(host, port)
        if password != '':
            self._client.password(password)
        fade = configs.getint('MPD', 'fade')
        if fade > 0:
            self._client.crossfade(fade)
         #print self._client.status()['xfade']

    def connect(self):
        if not self._client:
            log.debug("MPD connecting...")
            try:
                self.__connect()
            except Exception, err:
                log.error(err)

    def disconnect(self):
        if self._client:
            try: self.client.disconnect()
            except: pass
        if self._player:
            gobject.source_remove(self._player)
            self._player = 0

    def update(self):
        status = self.get_state()
        if status != self._state:
            self._state = status
            self.THREAD.update(STATE, status)
            #print status
        if status == PLAYING:
            data = self._client.currentsong()
            if self._data != data:
                self._data = data
                self.THREAD.update(TRACK, self.__get_track())
                #print data
        return True

    def __get_state(self):
        if self._client:
            try: return self._client.status()['state']
            except Exception, err:
                log.error(err)
        return ''

    def get_state(self):
        status = self.__get_state()
        if status == 'play':
            return PLAYING
        if status == 'pause':
            return PAUSED
        if status == 'stop':
            return STOPPED
        return CLOSED

    def __get_track(self):
        data = {}
        vals = ('title','album','artist','genre','date','track','file')
        for key in vals:
            if key in self._data:
                data[key] = self._data[key]
            else:
                data[key] = ''
        data['url'] = '%s/%s' % (self._path, data['file'])
        return Track(data)

    def get_track(self):
        return self.__get_track()

    def previous(self):
        if self._client:
            self._client.previous()

    def next(self):
        if self._client:
            self._client.next()

    def play(self):
        if self._client:
            status = self.get_state()
            self._client.pause(1 if status == PLAYING else 0)
