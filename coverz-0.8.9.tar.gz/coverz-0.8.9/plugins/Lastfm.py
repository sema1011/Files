# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

from mods import log
from plugins import CoverPlugin

class Lastfm(CoverPlugin):

    api_url = 'http://ws.audioscrobbler.com/2.0/?method='
    api_key = '03847dec370bfcfe516815d7ff8a3da2'
    #pi_key = 'fd8dd98d26bb3f288f3e626502f9add6'

    def get(self, track):
        """ Download covers from Last.fm """
        path = self.find(track)
        self.update(path)
        if path == None:
            try:
                data = self._get_cover(track)
                path = self.save(track, data)
                self.update(path)
            except:
                log.error("URLError") 

    def _get_cover(self, track):
        artist, album = self.encode(track.artist), self.encode(track.album)

        if len(track.album) > 1:
            query = 'album.getinfo&artist=%s&album=%s&api_key=' % (artist, album)
            xml = self.read(self.api_url +query +self.api_key)
            sst = '<image size="large">'
            start = xml.find(sst)
            end = xml.find('</image>', start)
            url = xml[start+len(sst):end]
        elif len(track.artist) > 1:
            query = 'artist.getimages&artist=%s&api_key=' % artist
            xml = self.read(self.api_url +query +self.api_key)
            sst = '<size name="largesquare" width="126" height="126">'
            start = xml.find(sst)
            end = xml.find('</size>', start)
            url = xml[start+len(sst):end]
        else:
            raise ValueError

        return self.read(url)
