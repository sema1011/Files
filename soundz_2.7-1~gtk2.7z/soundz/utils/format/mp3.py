# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def getTrack(filename):
    """ Return a Track created from an mp3 file """
    from mutagen.mp3 import MP3
    from mutagen.id3 import ID3

    mp3File = MP3(filename)

    length     = int(round(mp3File.info.length))
    bitrate    = int(mp3File.info.bitrate)
    samplerate = int(mp3File.info.sample_rate)

    if mp3File.info.mode == 1: isVBR = True
    else:                      isVBR = False

    try:    id3 = ID3(filename)
    except: return filename, length, bitrate, None, None, None

    try:    artist = str(id3['TPE1'])
    except: artist = None

    try:    album = str(id3['TALB'])
    except: album = None

    try:    title = str(id3['TIT2'])
    except: title = None

    try:    number = str(id3['TRCK'])
    except: number = None

    try:    date = str(id3['TDRC'][0].year)
    except: date = None

    try:    genre = str(id3['TCON'])
    except: genre = None

    return filename, length, bitrate, artist, album, title
