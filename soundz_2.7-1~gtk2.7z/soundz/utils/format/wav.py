# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def getTrack(filename):
    """ Return a Track created from an mp3 file """
    import wave

    wavFile = wave.open(filename)

    length     = int(round(wavFile.getnframes() / float(wavFile.getframerate())))
    bitrate    = -1
    samplerate = wavFile.getframerate()

    wavFile.close()

    return filename, length, bitrate, None, None, None
