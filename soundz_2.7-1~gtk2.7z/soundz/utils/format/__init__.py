# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import os

from utils.format import asf, flac, mp3, mp4, ogg, wav, wavpack

from utils import prefs

try: TRACK_INDEX = prefs.pickleLoad(prefs.filePlayed)
except: TRACK_INDEX = {}

TRACK_EXT = {
    '.flac': flac,
    '.m4a':  mp4,
    '.mp2':  mp3,
    '.mp3':  mp3,
    '.mp4':  mp4,
    '.oga':  ogg,
    '.ogg':  ogg,
    '.wav':  wav,
    '.wma':  asf,
    '.wv':   wavpack
    }

def getTags(directory):
    if not os.access(directory, os.R_OK | os.X_OK):
        print "Error: directory not readable"
        exit()
    print "Reading files, please wait . . ."
    for root, subdirs, files in os.walk(directory):
        print root, "(%s files)" % len(files)
        setTags(files, root)

    prefs.pickleSave(prefs.filePlayed, TRACK_INDEX)
    print "Done!"
    exit()

def readTags(data):
    filename, length, bitrate, artist, album, title = data
        
    tags = {'length': length, 'bitrate': bitrate}
    if artist: tags['artist'] = artist
    if album:  tags['album'] = album
    if title:  tags['title'] = title

    return tags

def setTags(files, root=None):
    for file in files:
        if file.split('/')[-1] in TRACK_INDEX.keys():
            continue
        ext = file[file.rfind('.'):].lower()
        if ext in TRACK_EXT:
            if root != None: file = os.path.join(root, file)
            try: tags = readTags(TRACK_EXT[ext].getTrack(file))
            except: tags = {}
            TRACK_INDEX[file.split('/')[-1]] = tags
