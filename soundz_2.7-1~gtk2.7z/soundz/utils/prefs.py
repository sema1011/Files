# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
import os.path

# --- Consts
cmdLine = {}, []
gstBin  = None
Window  = None

# --- Directories
dirSrc  = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
os.chdir(dirSrc)
dirUsr  = os.path.expanduser('~')
dirCfg  = os.path.join(dirUsr, '.config', os.path.basename(dirSrc))
if not os.path.exists(dirCfg):
    os.mkdir(dirCfg)

# --- Files
appExec      = os.path.basename(dirSrc)
iconExec     = os.path.join(dirSrc, 'pix/48.png')
filePrefs    = os.path.join(dirCfg, 'prefs')
filePlaylist = os.path.join(dirCfg, 'playlist')
filePlayed   = os.path.join(dirCfg, 'played')

# --- Prefs
import cPickle

def pickleLoad(file):
    with open(file, 'r') as f:
        return cPickle.load(f)

def pickleSave(file, data):
    with open(file, 'w') as f:
        cPickle.dump(data, f, 2)

try:
    __prefs = pickleLoad(filePrefs)
except:
    __prefs = {}

def get(key, value=None):
    try: return __prefs[key]
    except: return value

def set(key, value):
    __prefs[key] = value

def save():
    pickleSave(filePrefs, __prefs)

# --- Objects
pixTheme = gtk.icon_theme_get_default()
pixTheme.prepend_search_path(os.path.join(dirSrc, 'pix'))
pixTheme.rescan_if_needed()

def pixBuf(f):
    return gtk.gdk.pixbuf_new_from_file(os.path.join(dirSrc, 'pix', f))
    #gtk.gdk.pixbuf_new_from_file_at_scale(file, 16, 16, True)

def pixEmpty(size=16):
    pix = gtk.gdk.Pixbuf(gtk.gdk.COLORSPACE_RGB, True, 8, size, size)
    pix.fill(0x00000000)
    return pix

def pixFile(f):
    return gtk.image_new_from_file(os.path.join(dirSrc, 'pix', f))

def pixIcon(i, size=gtk.ICON_SIZE_MENU):
    return gtk.Label().render_icon(i, size)

def pixName(i, size=gtk.ICON_SIZE_MENU):
    return gtk.image_new_from_icon_name(i, size)

def pixLookup(i, size=16):
    return pixTheme.load_icon(i, size, gtk.ICON_LOOKUP_NO_SVG)

def pixStock(i=gtk.STOCK_MISSING_IMAGE, size=gtk.ICON_SIZE_MENU):
    return gtk.image_new_from_stock(i, size)

# --- Widgets
def getWidget(obj='vbox1'):
    return winGlade.get_object(obj)

def getWidgetPath(name):
    return getWidget(name).path()

def getGlade(str):
    builder = gtk.Builder()
    builder.set_translation_domain(appExec)
    builder.add_from_string(str)
    return builder

def setGlade(file):
    builder = gtk.Builder()
    builder.set_translation_domain(appExec)
    builder.add_from_file(os.path.join(dirSrc, 'pix', file))
    return builder
winGlade = setGlade('glade.xml')

def setStyle(file):
    gtk.rc_parse(os.path.join(dirSrc, 'pix', file))
    style = gtk.rc_reset_styles(gtk.settings_get_default())
    return style
winStyle = setStyle('gtkrc')
