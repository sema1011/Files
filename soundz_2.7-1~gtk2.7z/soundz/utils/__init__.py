# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import os

try:
    import xdg.Mime
    xdg.Mime._cache_database()
    TYPES = [str(v) for v in xdg.Mime.exts.values()]
    def get_type(file):
        return str(xdg.Mime.get_type_by_name(file))
except:
    import mimetypes
    TYPES = mimetypes.types_map.values()
    def get_type(file):
        return mimetypes.guess_type(file)[0]

AUDIOTYPES = [v for v in TYPES if v.startswith('audio')]
VIDEOTYPES = [v for v in TYPES if v.startswith('video')]

def isAudio(file):
    """ Return True if the given file is an audio format """
    try: return get_type(file) in AUDIOTYPES
    except: False

def isVideo(file):
    """ Return True if the given file is a video format """
    try: return get_type(file) in VIDEOTYPES
    except: False

def isPlaylist(file):
    """ Return True if the given file is a playlist """
    try: return file[-4:].lower() in ('.m3u','.pls')
    except: False
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

from utils import prefs
from utils.prefs import pickleLoad, pickleSave
from utils.track import Track

try: TRACK_INDEX = pickleLoad(prefs.filePlayed)
except: TRACK_INDEX = {}

def getFiles(files, root=None):
    """ Return a list with the supported files only """
    supFiles = []
    for file in files:
        if isPlaylist(file):
            if root != None: file = os.path.join(root, file)
            supFiles += loadPlaylist(file)
        elif isAudio(file) or isVideo(file):
            if root != None: file = os.path.join(root, file)
            supFiles.append(file)
    return supFiles

def getTrack(file):
    """ Return the track object reading the tags from the index """
    track = Track(file) 
    try: track.tags = TRACK_INDEX[track.getFileName()]
    finally: return track

def getTracks(files, subdirs=True):
    """ Return the list of tracks walking in any sub directories """
    tracks = getFiles([file for file in files if os.path.isfile(file)])
    for dir in [file for file in files if os.path.isdir(file)]:
        if subdirs:
            for root, subdir, file in os.walk(dir):
                tracks += getFiles(file, root)
        else:
            tracks += getFiles([file for file in os.listdir(dir)], dir)
    return [getTrack(file) for file in sorted(set(tracks))]

def getTracksFromDnd(dragData, dndId):
    """ Return a track(s) by the given URI """
    if dndId == 0:
        return getTracks([file for file in dragData.data.split('\n')])
    elif dndId == 1:
        import urllib
        return getTracks([urllib.unquote(uri)[7:] \
            for uri in dragData.data.split('\r\n')])
    else:
        return []

def getTracksFromDisc(self):
    """ Return tracks from DVD """
    from utils import dvd

    return [dvd.loadDisc(),]

def setTracks(track=None):
    """ Update the index, if called without args, save it """
    if track and track.path.startswith('/'):
        TRACK_INDEX[track.path] = track.tags
    else:
        pickleSave(prefs.filePlayed, TRACK_INDEX)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def loadPlaylist(file):
    """ Return the tracks from the given playlist """
    with open(file, 'r') as f:
        lines = [line for line in [line.strip() for line in f] \
        if len(line) != 0 and line[0] != '#' or line.startswith('File')]

    files = []
    dirname = os.path.dirname(file)
    for f in lines:
        if os.path.isfile(f): files.append(f)
        else:
            fpath = os.path.join(dirname, f.replace('\\', '/'))
            if os.path.isfile(fpath):
                files.append(fpath)
            elif f.startswith('File') and '://' in f:
                files.append(f.split('=')[1])
            elif '://' in f:
                files.append(f)
    return files

def savePlaylist(tracks, file):
    """ Save a playlist with the given tracks """
    with open(file, 'w') as f:
        f.writelines('\n'.join(tracks))
