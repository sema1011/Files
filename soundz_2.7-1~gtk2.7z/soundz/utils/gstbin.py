# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gst
import urllib

class PlayBin2:

    _queue = 0

    def __init__(self, source, error):
        """ Initialize the player """
        self.trackStarted = source
        self.trackEnded = error
        self.queueSeek = None
        self.lastMsg = None

        self.player = gst.element_factory_make('playbin2', 'player')
        self.player.set_property('flags', 0x0002)

        def __makeAudioSink():
            self.audiosink = gst.element_factory_make('autoaudiosink', 'sink') 
            self.player.set_property('audio-sink', self.audiosink)

        def __makeFakeSink():
            self.videosink = gst.element_factory_make('fakesink')
            self.videosink.set_property('sync', True)
            self.player.set_property('video-sink', self.videosink)

        __makeAudioSink()#; __makeFakeSink()

        self.player.connect('about-to-finish', self.__aboutToFinish)

        bus = self.player.get_bus()
        bus.add_signal_watch()
        bus.connect('message', self.__newBusMessage)

        #def syncMessage(self, bus, msg): print bus, msg
        #bus.enable_sync_message_emission()
        #bus.connect('sync-message::element', self.syncMessage)
        #self.player.connect('about-to-finish', self.__aboutToFinish)
        #self.player.connect('notify::source', self.__newSource)

    def __aboutToFinish(self, bus):
        self.trackEnded(False)

    def __newBusMessage(self, bus, msg):
        if msg.type == gst.MESSAGE_EOS:
            self.trackEnded(False)
        elif msg.type == gst.MESSAGE_ERROR:
            self.trackEnded(True)
        elif msg.type == gst.MESSAGE_ASYNC_DONE:
            if self.uri: self.trackStarted(True)
            self.uri = None

    def __newSource(self, playbin, params):
        if self.uri.startswith('cdda:'): 
            source = self.player.get_by_name('source')
            source.get_property('paranoia-mode')
            source.set_property('read-speed', 1)

    def add_paranoia_mode(self):
        """ Set cdda reading properties when the source change """
        self.player.connect('notify::source', self.__newSource)

    def add_equalizer(self):
        """Link the equalizer and replaygain elements """
        self.equalizer = gst.element_factory_make('equalizer-10bands')
        rgvolume = gst.element_factory_make('rgvolume')
        elements = (rgvolume, self.equalizer, self.audiosink)

        bin = gst.Bin()
        bin.add(*elements)
        pad = gst.GhostPad('sink', self.audiosink.get_pad('sink'))
        bin.add_pad(pad)
        pad.set_target(self.equalizer.get_pad('sink'))
        pad.set_target(rgvolume.get_pad('sink'))
        gst.element_link_many(*elements)

        self.player.set_property('audio-sink', bin)

    def audio_tags(self):
        """ Return the audio tags """
        try: return dict(self.player.emit('get-audio-tags', 0))
        except: return {}

    def samplerate(self):
        """ Return the sample rate """
        pads = list(self.audiosink.pads())
        caps = pads[0].get_negotiated_caps()
        try: return int(caps[0]['rate'])
        except: return 0

    def duration(self):
        """ Return the duration of the stream """
        try: return int(self.player.query_duration(gst.FORMAT_TIME)[0]/1000000000)
        except: return 0

    def position(self):
        """ Return the current position """
        try: return int(self.player.query_position(gst.FORMAT_TIME)[0]/1000000000)
        except: return 0

    def state(self):
        """ Return the player state """
        #gst.STATE_VOID_PENDING=0, gst.STATE_NULL=1, gst.STATE_READY=2,
        #gst.STATE_PAUSED=3, gst.STATE_PLAYING=4
        return int(self.player.get_state()[1])

    def set_uri(self, uri):
        """ Set a new source """
        self.player.set_property('uri', self.__quote(uri))
        self.uri = uri

    def __quote(self, uri):
        if uri.startswith('/'):
            try: return urllib.quote('file://' +uri.encode('utf-8'), ':/')
            except: return 'file://' +uri
        return uri

    def play(self):
        """ Play """
        self.player.set_state(gst.STATE_PLAYING)
        if self._queue:
            self.seek(self._queue)
            self._queue = 0

    def pause(self):
        """ Pause """
        self.player.set_state(gst.STATE_PAUSED)

    def stop(self):
        """ Stop """
        self.player.set_state(gst.STATE_READY)

    def seek(self, seconds):
        """ Seek to the given seconds """
        if self.state() == 4: 
            self.player.seek(1, gst.FORMAT_TIME,
                gst.SEEK_FLAG_FLUSH | gst.SEEK_FLAG_ACCURATE,
                gst.SEEK_TYPE_SET, int(seconds)*1000000000,
                gst.SEEK_TYPE_NONE, 0)
        else:
            self._queue = seconds

    def volume(self, level):
        """ Set the volume to the given level """
        if level >= 0.0 and level <= 1.0:
            self.player.set_property('volume', level)
