# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

from gtk import gdk
from gobject import signal_new
from gobject import TYPE_INT, TYPE_STRING, TYPE_BOOLEAN, TYPE_PYOBJECT, TYPE_NONE, SIGNAL_RUN_LAST

DND_REORDERING_ID   = 1024
DND_INTERNAL_TARGET = ('extListview-internal',
    gtk.TARGET_SAME_WIDGET, DND_REORDERING_ID)
DND_TARGETS = [('app/tracklist', gtk.TARGET_SAME_APP, 0),
    ('text/uri-list', 0, 1),]

signal_new('extlistview-dnd',
gtk.TreeView, SIGNAL_RUN_LAST, TYPE_NONE,
(gdk.DragContext, TYPE_INT, TYPE_INT, gtk.SelectionData, TYPE_INT, TYPE_PYOBJECT))

signal_new('extlistview-modified',
gtk.TreeView, SIGNAL_RUN_LAST, TYPE_NONE,
())

signal_new('extlistview-button-pressed',
gtk.TreeView, SIGNAL_RUN_LAST, TYPE_NONE,
(gdk.Event, TYPE_PYOBJECT))

signal_new('extlistview-column-visibility-changed',
gtk.TreeView, SIGNAL_RUN_LAST, TYPE_NONE,
(TYPE_STRING, TYPE_BOOLEAN))

signal_new('button-press-event',
gtk.TreeViewColumn, SIGNAL_RUN_LAST, TYPE_NONE,
(gdk.Event,))

signal_new('extlistview-selection-changed',
gtk.TreeView, SIGNAL_RUN_LAST, TYPE_NONE,
(TYPE_PYOBJECT,))
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class ListViewColumn(gtk.TreeViewColumn):
    """ TreeViewColumn not has right-click, this subclass adds this events """

    def __init__(self, title=None, cell_renderer=None, **args):
        gtk.TreeViewColumn.__init__(self, title, cell_renderer, **args)
        label = gtk.Label(title)
        #label.set_use_markup(True)
        label.show()
        label.__realize = label.connect('realize', self.onRealize)
        self.set_widget(label)

    def onRealize(self, widget):
        widget.disconnect(widget.__realize)
        del widget.__realize
        button = widget.get_ancestor(gtk.Button)
        if button != None:
            button.connect('button-press-event', self.onButtonPressed)

    def onButtonPressed(self, widget, event):
        self.emit('button-press-event', event)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class ListView(gtk.TreeView):

    def __init__(self, columns, hidden=True, sortable=True, markup=False):
        gtk.TreeView.__init__(self)

        self.select = self.get_selection()

        self.sortLastCol = None
        self.sortAscending = True
        self.sortColCriteria = {}

        self.set_rules_hint(True)
        self.set_headers_visible(True)
        self.set_enable_search(False)

        self.select.set_mode(gtk.SELECTION_MULTIPLE)

        nbEntries = 0
        dataTypes = []
        for (title, renderers, sortIndexes, expandable, visible) in columns:
            if title == None:
                nbEntries += len(renderers)
                dataTypes += [renderer[1] for renderer in renderers]
            else:
                column = ListViewColumn(title)
                column.set_sizing(gtk.TREE_VIEW_COLUMN_AUTOSIZE)
                column.set_expand(expandable)
                column.set_visible(visible)
                if hidden:
                    column.connect('button-press-event', self.onColumnHeaderClicked)
                self.append_column(column)

                if sortable:
                    column.set_clickable(True)
                    column.connect('clicked', self.__sortRows)
                    self.sortColCriteria[column] = sortIndexes

                for (renderer, type) in renderers:
                    nbEntries += 1
                    dataTypes.append(type)
                    column.pack_start(renderer, False)
                    if isinstance(renderer, gtk.CellRendererToggle):
                        column.add_attribute(renderer, 'active', nbEntries -1)
                    elif isinstance(renderer, gtk.CellRendererPixbuf):
                        column.add_attribute(renderer, 'pixbuf', nbEntries -1)
                    elif isinstance(renderer, gtk.CellRendererText):
                        if markup:
                            column.add_attribute(renderer, 'markup', nbEntries -1)
                        else:
                            column.add_attribute(renderer, 'text', nbEntries -1)

        self.markedRow = None
        self.markColumn = len(dataTypes)
        dataTypes.append(TYPE_BOOLEAN)

        self.store = gtk.ListStore(*dataTypes)
        self.set_model(self.store)

        self.dndContext    = None
        self.motionEvtId   = None
        self.dndStartPos   = None
        self.dndReordering = False

        if len(DND_TARGETS) != 0:
            self.enable_model_drag_dest(DND_TARGETS, gdk.ACTION_DEFAULT)

        self.connect('drag-begin',           self.onDragBegin)
        self.connect('drag-motion',          self.onDragMotion)
        self.connect('button-press-event',   self.onButtonPressed)
        self.connect('drag-data-received',   self.onDragDataReceived)
        self.connect('button-release-event', self.onButtonReleased)

        self.select.connect('changed', self.onSelectionChanged)

        self.show()

    def __getIterOnSelectedRows(self):
        """ Return a list of iterators pointing to the selected rows """
        return [self.store.get_iter(path) \
            for path in self.select.get_selected_rows()[1]]

    def __resizeColumns(self):
        """ That's the only way I could find to resize columns """
        for column in self.get_columns():
            column.queue_resize()

    def addColumnAttribute(self, colIndex, renderer, attribute, value):
        """ Add a new attribute to the given column """
        self.get_column(colIndex).add_attribute(renderer, attribute, value)

    def setColumnLabel(self, colIndex, colTitle):
        """ Add a new attribute to the given column """
        self.get_column(colIndex).get_widget().set_label(colTitle)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def clearMark(self):
        """ Remove the mark """
        if self.markedRow != None:
            self.setItem(self.markedRow, self.markColumn, False)
            self.markedRow = None

    def getMark(self):
        """ Return the index of the marked row """
        return self.markedRow

    def setMark(self, rowIndex):
        """ Put the mark on the given row, will moved with the row itself """
        self.clearMark()
        self.markedRow = rowIndex
        self.setItem(rowIndex, self.markColumn, True)

    def __findMark(self):
        """ Linear search for the marked row
            To be used only when there's no other solution
        """
        iter = self.store.get_iter_first()

        while iter != None:
            if self.store.get_value(iter, self.markColumn) == True:
                self.markedRow = self.store.get_path(iter)[0]
                break
            iter = self.store.iter_next(iter)

    def hasMark(self):
        """ True if a mark has been set """
        return self.markedRow != None

    def hasMarkAbove(self, index):
        """ True if a mark is set and is above the given index """
        return self.markedRow != None and self.markedRow > index

    def hasMarkUnder(self, index):
        """ True if a mark is set and is undex the given index """
        return self.markedRow != None and self.markedRow < index
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def __cmpRows(self, row1, row2, criteria, ascending):
        criterion = criteria[0]
        result    = cmp(row1[criterion], row2[criterion])

        if result != 0:
            if ascending: return result
            else: return -result
        for criterion in criteria[1:]:
            result = cmp(row1[criterion], row2[criterion])
            if result != 0:
                return result
        return 0

    def __sortRows(self, column):
        if len(self.store) == 0:
            return

        if self.sortLastCol != None:
            self.sortLastCol.set_sort_indicator(False)

        if self.sortLastCol == column:
            self.sortAscending = not self.sortAscending
        else:
            self.sortLastCol   = column
            self.sortAscending = True

        rows = [tuple(r) + (i,) for i, r in enumerate(self.store)]
        criteria = self.sortColCriteria[column]
        rows.sort(lambda r1, r2: self.__cmpRows(r1, r2, criteria, self.sortAscending))
        self.store.reorder([r[-1] for r in rows])

        if self.markedRow != None:
            self.__findMark()

        column.set_sort_indicator(True)
        if self.sortAscending: column.set_sort_order(gtk.SORT_ASCENDING)
        else:                  column.set_sort_order(gtk.SORT_DESCENDING)

        self.emit('extlistview-modified')

    def __resetSorting(self):
        if self.sortLastCol != None:
            self.sortLastCol.set_sort_indicator(False)
            self.sortLastCol = None
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def selectAll(self):
        """ Select all rows """
        self.select.select_all()

    def unselectAll(self):
        """ Unselect all rows """
        self.select.unselect_all()

    def selectRows(self, paths):
        """ Select the given rows """
        self.unselectAll()
        for path in paths:
            self.select.select_path(path)

    def selectRow(self, path):
        self.select.select_path(path)

    def unselectRow(self, path):
        self.select.unselect_path(path)

    def getSelectedRowsCount(self):
        """ Return how many rows are currently selected """
        return self.select.count_selected_rows()

    def getSelectedRows(self):
        """ Return all selected row(s) """
        return [tuple(self.store[path])[:-1] \
            for path in self.select.get_selected_rows()[1]]

    def getFirstSelectedRow(self):
        """ Return only the first selected row """
        return tuple(self.store[self.select.get_selected_rows()[1][0]])[:-1]

    def getFirstSelectedRowIndex(self):
        """ Return the index of the first selected row """
        return self.select.get_selected_rows()[1][0][0]

    def iterSelectedRows(self):
        """ Iterate on all selected row(s) """
        for path in self.select.get_selected_rows()[1]:
            yield tuple(self.store[path])[:-1]
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def __len__(self):
        """ Return how many rows are stored in the list """
        return len(self.store)

    def getCount(self):
        """ Return how many rows are stored in the list """
        return len(self.store)

    def __iter__(self):
        """ Iterate on all rows """
        for row in self.store:
            yield tuple(row)[:-1]

    def iterAllRows(self):
        """ Iterate on all rows """
        for row in self.store:
            yield tuple(row)[:-1]

    def getRow(self, rowIndex):
        """ Return the given row """
        return tuple(self.store[rowIndex])[:-1]

    def getAllRows(self):
        """ Return all rows """
        return [tuple(row)[:-1] for row in self.store]

    def getItem(self, rowIndex, colIndex):
        """ Return the value of the given item """
        return self.store.get_value(self.store.get_iter(rowIndex), colIndex)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def appendRows(self, rows):
        """ Helper function, equivalent to insertRows(rows, None) """
        self.insertRows(rows, None)

    def insertRows(self, rows, position=None):
        """ Insert or append (if position == None) some rows to the list """
        self.freeze_child_notify()

        if self.markedRow != None and position != None \
        and position <= self.markedRow:
            self.markedRow += len(rows)

        if type(rows[0]) != tuple:
            rows = [tuple(row) for row in rows]

        if position == None:
            for row in rows:
                self.store.append(row +(False,))
        else:
            for row in rows:
                self.store.insert(position, row +(False,))
                position += 1

        self.thaw_child_notify()
        self.__resetSorting()

        self.emit('extlistview-modified')

    def replaceContent(self, rows):
        """ Replace the content of the list with the given rows """
        self.freeze_child_notify()
        self.set_model(None)
        self.clear()
        self.appendRows(rows)
        self.set_model(self.store)
        self.thaw_child_notify()

    def setItem(self, rowIndex, colIndex, value):
        """ Change the value of the given item """
        if self.sortLastCol != None \
        and colIndex in self.sortColCriteria[self.sortLastCol]:
            self.__resetSorting()
        self.store.set_value(self.store.get_iter(rowIndex), colIndex, value)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def clear(self):
        """ Remove all rows from the list """
        self.__resetSorting()
        self.clearMark()
        self.store.clear()
        self.__resizeColumns()
        self.emit('extlistview-modified')

    def cropSelectedRows(self):
        """ Remove all rows but the selected ones """
        pathsList = self.select.get_selected_rows()[1]
        self.freeze_child_notify()
        self.select.select_all()

        for path in pathsList:
            self.select.unselect_path(path)
        self.removeSelectedRows()

        self.select.select_all()
        self.thaw_child_notify()

    def removeRows(self, paths):
        """ Remove the given rows """
        self.freeze_child_notify()

        for iter in [self.store.get_iter(path) for path in paths]:
            path = self.store.get_path(iter)[0]

            if self.markedRow != None:
                if path < self.markedRow:
                    self.markedRow -= 1
                elif path == self.markedRow:
                    self.markedRow = None

            if self.store.remove(self.store.get_iter(path)):
                self.set_cursor(path)
            elif len(self.store) != 0:
                self.set_cursor(len(self.store)-1)

        self.thaw_child_notify()
        if len(self.store) == 0:
            self.set_cursor(0)
            self.__resetSorting()
        self.__resizeColumns()
        self.emit('extlistview-modified')

    def removeRow(self, path):
        """ Remove the given row """
        self.removeRows((path, ))

    def removeSelectedRows(self):
        """ Remove the selected row(s) """
        self.removeRows(self.select.get_selected_rows()[1])
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def enableDNDReordering(self):
        """ Enable the use of Drag'n'Drop to reorder the list """
        self.dndReordering = True
        DND_TARGETS.append(DND_INTERNAL_TARGET)
        self.enable_model_drag_dest(DND_TARGETS, gdk.ACTION_DEFAULT)

    def __isDropAfter(self, pos):
        return pos == gtk.TREE_VIEW_DROP_AFTER \
            or pos == gtk.TREE_VIEW_DROP_INTO_OR_AFTER

    def __moveSelectedRows(self, x, y):
        iterList = self.__getIterOnSelectedRows()
        dropInfo = self.get_dest_row_at_pos(int(x), int(y))

        if dropInfo == None:
            pos, path = gtk.TREE_VIEW_DROP_INTO_OR_AFTER, len(self.store) - 1
        else:
            pos, path = dropInfo[1], dropInfo[0][0]
            if self.__isDropAfter(pos) and path < len(self.store)-1:
                pos   = gtk.TREE_VIEW_DROP_INTO_OR_BEFORE
                path += 1

        self.freeze_child_notify()
        for srcIter in iterList:
            srcPath = self.store.get_path(srcIter)[0]

            if self.__isDropAfter(pos):
                dstIter = self.store.insert_after(self.store.get_iter(path),
                    self.store[srcIter])
            else:
                dstIter = self.store.insert_before(self.store.get_iter(path),
                    self.store[srcIter])
                if path == srcPath:
                    path += 1

            self.store.remove(srcIter)
            dstPath = self.store.get_path(dstIter)[0]

            if srcPath > dstPath:
                path += 1

            if self.markedRow is not None:
                if srcPath == self.markedRow:
                    self.markedRow  = dstPath
                elif srcPath < self.markedRow and dstPath >= self.markedRow:
                    self.markedRow -= 1
                elif srcPath > self.markedRow and dstPath <= self.markedRow:
                    self.markedRow += 1

        self.thaw_child_notify()
        self.__resetSorting()
        self.emit('extlistview-modified')
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onButtonPressed(self, tree, event):
        """ A mouse button has been pressed """
        retVal   = False
        pathInfo = self.get_path_at_pos(int(event.x), int(event.y))

        if pathInfo == None: path = None
        else:                path = pathInfo[0]

        if event.button == 1 or event.button == 3:
            if path == None:
                self.select.unselect_all()
                if len(self.store) != 0:
                    tree.set_cursor(len(self.store))

            elif event.type == gtk.gdk._2BUTTON_PRESS \
            and self.motionEvtId:
                self.disconnect(self.motionEvtId)
                self.motionEvtId = None
            else:
                if self.dndReordering and self.motionEvtId == None \
                and event.button == 1:
                    self.dndStartPos = (int(event.x), int(event.y))
                    self.motionEvtId = gtk.TreeView.connect(self,
                        'motion-notify-event', self.onMouseMotion)

                stateClear = not (event.state & (gdk.SHIFT_MASK | gdk.CONTROL_MASK))
                if stateClear and not self.select.path_is_selected(path):
                    self.select.handler_block_by_func(self.onSelectionChanged)
                    self.select.unselect_all()
                    self.select.select_path(path)
                    self.select.handler_unblock_by_func(self.onSelectionChanged)
                else:
                    retVal = (stateClear and self.getSelectedRowsCount() > 1 \
                        and self.select.path_is_selected(path))
            self.emit('extlistview-button-pressed', event, path)

        return retVal

    def onButtonReleased(self, tree, event):
        """ A mouse button has been released """
        if self.motionEvtId != None:
            self.disconnect(self.motionEvtId)
            self.dndContext  = None
            self.motionEvtId = None

            if len(DND_TARGETS) != 0:
                self.enable_model_drag_dest(DND_TARGETS, gdk.ACTION_DEFAULT)

        stateClear = not (event.state & (gdk.SHIFT_MASK | gdk.CONTROL_MASK))

        if stateClear and event.state & gdk.BUTTON1_MASK \
        and self.getSelectedRowsCount() > 1:
            pathInfo = self.get_path_at_pos(int(event.x), int(event.y))
            if pathInfo != None:
                self.select.unselect_all()
                self.select.select_path(pathInfo[0][0])

    def onMouseMotion(self, tree, event):
        """ The mouse has been moved """
        if self.dndContext == None \
        and self.drag_check_threshold(self.dndStartPos[0], self.dndStartPos[1],
            int(event.x), int(event.y)):
            self.dndContext = self.drag_begin([DND_INTERNAL_TARGET],
                gdk.ACTION_COPY, 1, event)

    def onSelectionChanged(self, selection):
        """ The selection has changed """
        self.emit('extlistview-selection-changed', self.getSelectedRows())
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onDragBegin(self, tree, context):
        """ A drag'n'drop operation has begun """
        if self.getSelectedRowsCount() == 1:
            context.set_icon_stock(gtk.STOCK_DND, 0, 0)
        else:
            context.set_icon_stock(gtk.STOCK_DND_MULTIPLE, 0, 0)

    def onDragDataReceived(self, tree, context, x, y, selection, dndId, time):
        """ Some data has been dropped into the list """
        if dndId == DND_REORDERING_ID:
            self.__moveSelectedRows(x, y)
        else:
            self.emit('extlistview-dnd', context, int(x), int(y), selection,
                dndId, time)

    def onDragMotion(self, tree, context, x, y, time):
        """ Prevent rows from being dragged *into* other rows """
        drop = self.get_dest_row_at_pos(int(x), int(y))

        if drop != None and (drop[1] == gtk.TREE_VIEW_DROP_INTO_OR_AFTER \
        or drop[1] == gtk.TREE_VIEW_DROP_INTO_OR_BEFORE):
            self.enable_model_drag_dest([('invalid-position', 0, -1)],
                gdk.ACTION_DEFAULT)
        else:
            self.enable_model_drag_dest(DND_TARGETS, gdk.ACTION_DEFAULT)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onColumnHeaderClicked(self, column, event):
        """ A column header has been clicked """
        if event.button == 3:
            menu            = gtk.Menu()
            nbVisibleItems  = 0
            lastVisibleItem = None

            for column in self.get_columns():
                item = gtk.CheckMenuItem(column.get_title())
                item.set_active(column.get_visible())
                item.connect('toggled', self.onShowHideColumn, column)
                item.show()
                menu.append(item)

                if item.get_active():
                    nbVisibleItems  += 1
                    lastVisibleItem  = item

            if nbVisibleItems == 1:
                lastVisibleItem.set_sensitive(False)

            menu.popup(None, None, None, event.button, event.get_time())

    def onShowHideColumn(self, menuItem, column):
        """ Switch the visibility of the given column """
        column.set_visible(not column.get_visible())
        self.__resizeColumns()
        self.emit('extlistview-column-visibility-changed', column.get_title(),
            column.get_visible())
