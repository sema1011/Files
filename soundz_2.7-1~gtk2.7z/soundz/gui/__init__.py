# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import os

dirSrc = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
dirUsr = os.path.expanduser('~')

__cols = {
    'reset' : '\x1b[0m',
    'bold'  : '\x1b[01m',
    'blue'  : '\x1b[34;06m',
    'green' : '\x1b[32;06m',
    'red'   : '\x1b[31;06m',
    'yellow': '\x1b[33;06m',
    }
def debug():
    """ Print the last error when called after except: """
    import traceback
    print '%s%s\x1b[0m' % (__cols['red'], traceback.format_exc())

__dirs = {}

def listDir(directory, listHiddenFiles=False):
    """ Return a list of tuples (filename, path) with the directory content """
    if directory in __dirs: cachedMTime, lsDir = __dirs[directory]
    else:  cachedMTime, lsDir = None, None

    if os.path.exists(directory): mTime = os.stat(directory).st_mtime
    else: mTime = 0

    if mTime != cachedMTime:
        if os.access(directory, os.R_OK | os.X_OK): lsDir = os.listdir(directory)
        else: lsDir = []

        __dirs[directory] = (mTime, lsDir)

    return [(filename, os.path.join(directory, filename))
        for filename in lsDir if listHiddenFiles or filename[0] != '.']

def listFiles(directory, exts=('.',)):
    """ Return a list of files that match the given extensions """
    _files = [file for (file, path) in listDir(directory) \
        if os.path.isfile(path)]
    files = []
    for file in sorted(_files):
        dot = file.rfind('.')+1
        ext = file[dot:].lower()
        if ext in exts:
            files.append((file,ext))

    return [file for (file, ext) in sorted(files, key=lambda i: i[1])]
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def fileSize(file):
    """ Return a file size """
    try: return os.stat(file).st_size
    except: return 0

def splitPath(file):
    """ Return a tuple with (dirname, filename) """
    s = file.rfind('/')
    return file[:s], file[s+1:]

def findString(string, data):
    """ Find the given string """
    if len(string) == 1:
        return string[0] == data[0]
    elif len(string) <= len(data):
        return string in data
    return False

def htmlEscape(string):
    """ Replace characters &, <, and > by their equivalent HTML code """
    output = ''
    for c in string:
        if c == '&':   output += '&amp;'
        elif c == '<': output += '&lt;'
        elif c == '>': output += '&gt;'
        else: output += c
    return output

def percentEncode(string):
    """ Percent-encode all the bytes in the given string
        Couldn't find a Python method to do that
    """
    mask  = '%%%X' * len(string)
    bytes = tuple([ord(c) for c in string])
    return mask % bytes

def dict2str(dic):
    """ Return the tags dictionary in a printable format """
    import pprint

    [dic.pop(k) for k in dic.keys() if not pprint.isreadable(dic[k])]
    return str(dic)[1:-1]

def niceString(string):
    """ Replace underscores with spaces and capitalize each word """
    return ' '.join([w.capitalize() for w in string.split('_')])

def str2hash(string):
    """ Return the hash of a string """
    return str(abs(hash(string.lower())))

def sec2str(seconds, showHours=False):
    """ Return a formatted string based on the given duration in seconds """
    hours, seconds   = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds,   60)
    if showHours or hours != 0:
        return '%u:%02u:%02u' % (hours, minutes, seconds)
    else:
        return '%u:%02u' % (minutes, seconds)

def size2str(size):
    """ Turn an integer size value into something human-readable """
    if size >= 1024*1024*1024:
        return "%.1fGB" % (float(size) / (1024*1024*1024))
    elif size >= 1024*1024 * 100:
        return "%.0fMB" % (float(size) / (1024*1024))
    elif size >= 1024*1024 * 10:
        return "%.1fMB" % (float(size) / (1024*1024))
    elif size >= 1024*1024:
        return "%.2fMB" % (float(size) / (1024*1024))
    elif size >= 1024 * 10:
        return "%dKB" % int(size / 1024)
    elif size >= 1024:
        return "%.2fKB" % (float(size) / 1024)
    else:
        return "%dB" % size
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

__lastDir = dirUsr
__parent = None

def openFile(selection=False, dir=None):
    """ Return a file path, or a dir path if 'select' is True """
    global __lastDir

    dlg = gtk.FileChooserDialog(
        __stock(gtk.STOCK_OPEN), __parent,
        gtk.FILE_CHOOSER_ACTION_OPEN \
        if not selection else gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER,
        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK))
    dlg.set_current_folder(__lastDir if dir == None else dir)
    dlg.set_select_multiple(False)

    file = None
    if dlg.run() == gtk.RESPONSE_OK:
        file = dlg.get_filename()
    __lastDir = dlg.get_current_folder()
    dlg.destroy()
    return file

def openURI():
    """ Return a pathname from an entry widget """
    dlg = gtk.Dialog(__stock(gtk.STOCK_OPEN), __parent,
        gtk.DIALOG_MODAL,
        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OK, gtk.RESPONSE_OK))

    entry = gtk.Entry()
    try: entry.set_text(gtk.clipboard_get().wait_for_text())
    except: pass
    hbox = gtk.HBox()
    hbox.pack_start(entry, True, True, 6)

    dlg.get_content_area().pack_start(hbox, True, True, 6)
    dlg.set_default_size(300, 1)
    if dlg.run() == gtk.RESPONSE_OK:
        file = entry.get_text()    
    dlg.destroy()
    return file

def saveFile(file):
    """ Return a file path """
    dlg = gtk.FileChooserDialog(
        __stock(gtk.STOCK_SAVE_AS), __parent,
        gtk.FILE_CHOOSER_ACTION_SAVE,
        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_SAVE, gtk.RESPONSE_OK))
    dlg.set_do_overwrite_confirmation(True)
    dlg.set_select_multiple(False)
    dlg.set_current_folder(file[:file.rfind('/')])
    dlg.set_current_name(file[file.rfind('/')+1:])

    file = None
    if dlg.run() == gtk.RESPONSE_OK:
        file = dlg.get_filename()
    __lastDir = dlg.get_current_folder()
    dlg.destroy()
    return file

def __stock(stockid):
    """ Return the translated label of a stock id """
    return gtk.stock_lookup(stockid)[1].replace('_', '')

def __msgBox(dlgtype, buttons, header, text):
    """ Show a message dialog box
        if dlgtype == gtk.MESSAGE_INFO or dlgtype == gtk.MESSAGE_ERROR,
        gtk.BUTTONS_OK,
        elif dlgtype == gtk.MESSAGE_QUESTION,
        gtk.BUTTONS_YES_NO,
    """
    dlg = gtk.MessageDialog(__parent,
        gtk.DIALOG_MODAL, dlgtype, buttons, header)
    dlg.set_border_width(12)
    dlg.set_title('')

    if text: dlg.format_secondary_markup(text)
    else: dlg.set_markup(header)

    response = dlg.run()
    dlg.destroy()

def saveImage(data, file):
    """ Save the raw data of images to a jpg file """
    pbl = gtk.gdk.PixbufLoader()
    #pbl.set_size(126, 126)
    pbl.write(data)
    pbuf = pbl.get_pixbuf()
    #pbuf.scale_simple(126, 126, gtk.gdk.INTERP_BILINEAR)
    pbl.close()
    pbuf.save(file, 'jpeg', {'quality':'100'})
