# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
import gobject

import mods
from gui import htmlEscape, sec2str
from utils import prefs

MOD_INFO = (__name__, '', False, False)

TITLE = '{title}'
BODY = '{artist}'
TIMEOUT = 4

class Notify(mods.ThreadedModule):

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:  self.onAppStarted,
            mods.MSG_APP_QUIT:     self.onStopped,
            mods.MSG_MOD_LOADED:   self.onAppStarted,
            mods.MSG_MOD_UNLOADED: self.onStopped,
            mods.MSG_NEW_TRACK:    self.onNewTrack,
            mods.MSG_STOPPED:      self.onStopped,
                   }
        mods.ThreadedModule.__init__(self, handlers)

    def onAppStarted(self):
        """ Application has been started """
        self.window = prefs.Window
        self.widget = prefs.pixFile(prefs.iconExec)
        self.delay = None
        self.notif = None

    def onNewTrack(self, track):
        """ A new track is being played """        
        if self.delay:
            gobject.source_remove(self.delay)
        #f self.window.window.get_state() == gtk.gdk.WINDOW_STATE_ICONIFIED:
        self.delay = gobject.timeout_add(1000, self.showNotification, track)

    def onStopped(self):
        """ The playback has been stopped """
        if self.notif: self.notif.close()
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def __format(self, track, fmtString):
        """ Return the Track information by the given string """
        result = fmtString

        result = result.replace('{artist}', track.getArtist())
        result = result.replace('{album}',  track.getAlbum())
        result = result.replace('{title}',  track.getTitle())
        result = result.replace('{time}',   sec2str(track.getLength()))
        result = result.replace('{pos}',    str(track.ppos))

        return result

    def __createNotification(self, title, body):
        """ Create the Notification object """
        import pynotify

        if pynotify.init(prefs.appExec):
            self.notif = pynotify.Notification(title, body)
            self.notif.set_urgency(pynotify.URGENCY_LOW)
            self.notif.set_timeout(TIMEOUT *1000)

    def showNotification(self, track):
        """ Show the notification for the current track """
        gobject.source_remove(self.delay)

        title = self.__format(track, TITLE).replace('~ - ', '')
        body = htmlEscape(self.__format(track, BODY))

        if not self.notif: self.__createNotification(title, body)
        else: self.notif.update(title, body)

        self.notif.set_icon_from_pixbuf(self.widget.get_pixbuf())
        self.notif.show()
