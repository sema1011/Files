# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gobject
import pprint

import mods, utils
from utils import gstbin, prefs

MOD_INFO = (__name__, '', True, False)

PENDING, NULL, READY, PAUSED, PLAYING = range(5)

class Player(mods.ThreadedModule):

    pos = 0
    _timer = None
    track = None
    tracks = []

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:   self.onAppStarted,
            mods.MSG_APP_QUIT:      self.onAppQuit,
            mods.MSG_NEW_TRACKS:    self.onNewTracklist,
            mods.CMD_PLAY:          self.onPlay,
            mods.CMD_STOP:          self.onStop,
            mods.CMD_PLAY_PAUSE:    self.onTogglePause,
            mods.CMD_SEEK:          self.onSeek,
            mods.CMD_VOLUME:        self.onVolumeChanged,
                   }
        mods.ThreadedModule.__init__(self, handlers)

        self.__initPlayBin()

    def __initPlayBin(self):
        self.playBin = gstbin.PlayBin2(self.__trackStarted, self.__trackEnded)
        prefs.gstBin = self.playBin

    def __startTimer(self):
        if not self._timer:
            self._timer = gobject.timeout_add(1000, self.__updateTimer)

    def __stopTimer(self):
        if self._timer:
            gobject.source_remove(self._timer)
        self._timer = None

    def __updateTimer(self):       
        pos = self.playBin.position()
        if pos != self.pos:
            self.pos = pos
            mods.postMsg(mods.MSG_NEW_POSITION, {'seconds': pos})
        return True

    def __trackEnded(self, error):
        if error and self.pos >= 0:
            self.pos = -1
            mods.postMsg(mods.MSG_ERROR)
        elif self.pos > 0:
            self.pos = 0
            mods.postMsg(mods.MSG_ENDED)

        if not self.track.path.startswith('/'):
            prefs.Window.wait(False)

    def __trackStarted(self, msg):
        tags = self.playBin.audio_tags()
        tags['length'] = self.playBin.duration()       
        tags['samplerate'] = self.playBin.samplerate()

        if 'image' in tags.keys():
            data = tags['image']
            _data = data[0] if type(data) == list else data
            path = self.track.path
            _file = '%s/.jpg' +path[:path.rfind('/')]
            try:
                from gui import saveImage
                saveImage(_data, _file)
                tags['image'] = _file                
            except:
                tags.pop('image')

        if not self.track.path.startswith('/'):
            try: tags['title'] = tags['organization']
            except: pass
            tags['length'] = 0

            prefs.Window.wait(False)

        if int(tags['length']) > 0:
            self.__startTimer()
        else:
            self.__stopTimer()

        for k in tags.keys():
            if not pprint.isreadable(tags[k]): tags.pop(k)
        self.track.tags = tags
        utils.setTracks(self.track)
        print '<gst.tags> %s' % str(tags)[1:-1]

        mods.postMsg(mods.MSG_NEW_TRACK, {'track': self.track})
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onAppStarted(self):
        opts, args = prefs.cmdLine
        playnow = True
        if args:
            self.tracks = utils.getTracks(args)
        elif not opts.new:
            playnow = False
            try: self.tracks = prefs.pickleLoad(prefs.filePlaylist)
            except: return

        if self.tracks:
            mods.postMsg(mods.CMD_TRACKS_SET,
                {'tracks': self.tracks, 'playnow': playnow})
            if not playnow:
                track, secs = prefs.get('playing-track', (0, 0))
                if track and track <= len(self.tracks) and secs:
                    mods.postMsg(mods.CMD_TRACKS_PLAY, {'trackIdx': track -1})
                    mods.postMsg(mods.CMD_SEEK, {'seconds': secs})
        prefs.set('playing-track', (0, 0))

    def onAppQuit(self):
        prefs.set('playing-track', (self.track.ppos, self.pos) \
            if self.track and self.track.path.startswith('/') else (0, 0))

    def onNewTracklist(self, tracks):
        self.tracks = tracks

        prefs.pickleSave(prefs.filePlaylist, self.tracks)
        utils.setTracks()

    def onPlay(self, track):
        self.pos = 0
        self.track = track

        self.playBin.stop()
        self.playBin.set_uri(track.path)
        self.playBin.play()

        if not self.track.path.startswith('/'):
            prefs.Window.wait(True)

    def onStop(self):
        self.pos = 0
        self.__stopTimer()

        self.playBin.stop()
        mods.postMsg(mods.MSG_STOPPED)

    def onTogglePause(self):
        state = self.playBin.state()
        if state == PAUSED:
            self.playBin.play()
            mods.postMsg(mods.MSG_UNPAUSED)

        elif state == PLAYING:
            self.playBin.pause()
            mods.postMsg(mods.MSG_PAUSED)

    def onSeek(self, seconds):
        self.playBin.seek(seconds)

    def onVolumeChanged(self, level):
        self.playBin.volume(level)
