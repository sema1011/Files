# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk
gtk.gdk.threads_init()

import gobject
gobject.threads_init()

import os
import sys
import threading

from utils import prefs

(
    MODINFO_NAME,           # module name
    MODINFO_DESC,           # description of module
    MODINFO_MANDATORY,      # if module cannot be disabled
    MODINFO_CONFIGURABLE,   # if module can be configured
) = range(4)

(
    MOD_PMODULE,            # python object
    MOD_CLASSNAME,          # classname of module
    MOD_INSTANCE,           # instance, None if not enabled
    MOD_INFO                # tuple exported by module
) = range(4)

(
    # Player
    CMD_PLAY,               # 'uri'
    CMD_PLAY_PAUSE,         #
    CMD_STOP,               #
    CMD_SEEK,               # 'seconds'
    CMD_VOLUME,             # 'level'
    CMD_NEXT,               #
    CMD_PREVIOUS,           #
    # Tracklist
    CMD_TRACKS_SET,         # 'tracks', 'playnow'
    CMD_TRACKS_ADD,         # 'tracks', 'playnow'
    CMD_TRACKS_CLR,         #
    CMD_TRACKS_DEL,         # 'idx'
    CMD_TRACKS_PLAY,        # 'idx', 'seconds'
    # Misc
    CMD_THREAD_EXECUTE,     # 'n/a' internal thread
    # Application
    MSG_APP_QUIT,           #
    MSG_APP_STARTED,        #
    # Modules
    MSG_MOD_LOADED,         #
    MSG_MOD_UNLOADED,       #
    # Player
    MSG_NEW_TRACK,          # 'track'
    MSG_NEW_POSITION,       # 'seconds'
    MSG_ERROR,              #
    MSG_ENDED,              # 'error'
    MSG_PAUSED,             #
    MSG_UNPAUSED,           #
    MSG_STOPPED,            #
    # Tracklist
    MSG_NEW_TRACKS,         # 'tracks', 'playtime'
    MSG_TRACK_SELECTED,     # 'track'
    MSG_TRACK_MOVED,        # 'hasPrevious', 'hasNext'
    # End value
    MSG_END_VALUE
) = range(28)

def load(name):
    """ Load the given module """
    mModulesLock.acquire()
    module = mModules[name]
    mModulesLock.release()

    module[MOD_INSTANCE] = getattr(module[MOD_PMODULE], module[MOD_CLASSNAME])()
    module[MOD_INSTANCE].start()

    mHandlersLock.acquire()
    if module[MOD_INSTANCE] in mHandlers[MSG_MOD_LOADED]:
        module[MOD_INSTANCE].postMsg(MSG_MOD_LOADED)
    mHandlersLock.release()

    mEnabledModules.append(name)
    prefs.set(__name__, mEnabledModules)

def unload(name):
    """ Unload the given module """
    mModulesLock.acquire()
    module = mModules[name]
    instance = module[MOD_INSTANCE]
    module[MOD_INSTANCE] = None
    mModulesLock.release()

    if instance is not None:
        mHandlersLock.acquire()
        instance.postMsg(MSG_MOD_UNLOADED)
        for handlers in [handler for handler in mHandlers.itervalues()
            if instance in handler]:
            handlers.remove(instance)
        mHandlersLock.release()

        mEnabledModules.remove(name)
        prefs.set(__name__, mEnabledModules)

def getModules():
    """ Return a copy of all known modules """
    mModulesLock.acquire()
    copy = mModules.items()
    mModulesLock.release()
    return copy

def register(module, msgList):
    """ Register the module for all messages in the list/tuple """
    mHandlersLock.acquire()
    for msg in msgList:
        mHandlers[msg].add(module)
    mHandlersLock.release()

def __postMsg(msg, params={}):
    """ The postMsg function, which must be executed in the GTK main loop """
    mHandlersLock.acquire()
    for module in mHandlers[msg]:
        module.postMsg(msg, params)
    mHandlersLock.release()

def postMsg(msg, params={}):
    """ Post a message to the queue of modules that registered """
    # we need to ensure that posting messages will be done by the gtk main loop
    # otherwise, the code of threaded modules could be executed in the caller's
    # thread, which could cause problems when calling gtk functions
    gobject.idle_add(__postMsg, msg, params)

def __postQuitMsg():
    """ The postQuitMsg function, which must be executed in the GTK main loop """
    __postMsg(MSG_APP_QUIT)
    for modData in mModules.itervalues():
        if modData[MOD_INSTANCE] is not None:
            modData[MOD_INSTANCE].join()
    # let modules do their job before save prefs
    gobject.idle_add(prefs.save)
    gobject.idle_add(gtk.main_quit)

def postQuitMsg():
    """ Post a MSG_APP_QUIT in each module's queue and exit the application """
    gobject.idle_add(__postQuitMsg)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class ModuleBase:
    """ This class makes sure that all modules have some mandatory functions """

    def join(self):
        pass
    def start(self):
        pass
    def configure(self, parent):
        pass
    def handleMsg(self, msg, params):
        pass        
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class Module(ModuleBase):
    """ The base class for non-threaded modules """

    def __init__(self, handlers):
        self.handlers = handlers
        register(self, handlers.keys())

    def postMsg(self, msg, params={}):
        gobject.idle_add(self.__dispatch, msg, params)

    def __dispatch(self, msg, params):
        self.handlers[msg](**params)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

class ThreadedModule(threading.Thread, ModuleBase):
    """ The base class for threaded modules """

    def __init__(self, handlers):
        """ Constructor """
        import Queue

        self.queue        = Queue.Queue(0) # list of queued messages
        self.gtkResult    = None # value returned by function executed
        self.gtkSemaphore = threading.Semaphore(1) # execute some code

        # initializating thread
        threading.Thread.__init__(self)

        self.__thread = None

        # add QUIT and UNLOADED messages, required to exit the thread's loop
        if MSG_APP_QUIT not in handlers:
            handlers[MSG_APP_QUIT] = lambda: None
        if MSG_MOD_UNLOADED not in handlers:
            handlers[MSG_MOD_UNLOADED] = lambda: None

        self.handlers = handlers
        register(self, handlers.keys())

    def __gtkExecute(self, func):
        """ Private function, must be executed in the GTK main loop """
        self.gtkResult = func()
        self.gtkSemaphore.release()

    def gtkExecute(self, func):
        """ Execute func in the GTK main loop,
            block the execution of the thread until done
        """
        gobject.idle_add(self.__gtkExecute, func)
        self.gtkSemaphore.acquire()
        return self.gtkResult

    def threadStartNew(self, func, *args):
        """ Start a new thread, call gtk.gdk.threads_enter() inside the function
            before touching any gtk functions or widgets
        """
        if not self.__thread:
            import thread; self.__thread = thread.start_new_thread
        self.__thread(func, args)

    def threadExecute(self, func, *args):
        """ Schedule func(*args) to be called by the thread
            This is used to avoid func to be executed in the GTK main loop
        """
        self.postMsg(CMD_THREAD_EXECUTE, (func, args))

    def postMsg(self, msg, params={}):
        """ Enqueue a message in this threads's message queue """
        self.queue.put_nowait((msg, params))

    def run(self):
        """ Wait for messages and handle them """
        msg = None

        while msg != MSG_APP_QUIT and msg != MSG_MOD_UNLOADED:
            (msg, params) = self.queue.get(True)
            #print params
            if msg == CMD_THREAD_EXECUTE:
                (func, args) = params
                func(*args)
            else:
                self.handlers[msg](**params)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

mModDir = os.path.dirname(__file__) # where modules are located
mModules = {} # all known modules associated to an 'active' boolean
mHandlers = dict([(msg, set()) for msg in xrange(MSG_END_VALUE)])
mModulesLock = threading.Lock() # protects the modules list from concurrent access
mHandlersLock = threading.Lock() # protects the handlers list from concurrent access
mEnabledModules = prefs.get(__name__, []) # list of modules enabled

# find modules, instantiate those that are mandatory or previously enabled by user
sys.path.append(mModDir)

for file in [os.path.splitext(file)[0] for file in os.listdir(mModDir) \
if file.endswith('.py') and not file.startswith('_')]:
    pModule = __import__(file)
    modInfo = getattr(pModule, 'MOD_INFO')

    instance = None
    if modInfo[MODINFO_MANDATORY] or modInfo[MODINFO_NAME] in mEnabledModules:
        instance = getattr(pModule, file)()
        instance.start()

    # add it to the dictionary
    mModules[modInfo[MODINFO_NAME]] = [pModule, file, instance, modInfo]

# remove enabled modules that are no longer available
mEnabledModules[:] = [module for module in mEnabledModules if module in mModules]
prefs.set(__name__, mEnabledModules)
