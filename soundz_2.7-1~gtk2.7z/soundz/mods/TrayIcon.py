# -*- coding: utf-8 -*-
#
# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

import gtk

import mods
from utils import prefs

MOD_INFO = (__name__, '', False, False)#!True

class TrayIcon(mods.Module):

    icons = ('gtk-tray-notplay','gtk-tray',)
    playing = False
    statusIcon = None

    def __init__(self):
        handlers = {
            mods.MSG_APP_STARTED:     self.onAppStarted,
            #ods.MSG_APP_QUIT:        self.onAppQuit,
            mods.MSG_MOD_LOADED:      self.onAppStarted,
            mods.MSG_MOD_UNLOADED:    self.onAppQuit,
            mods.MSG_PAUSED:          self.onPaused,
            mods.MSG_STOPPED:         self.onStopped,
            mods.MSG_UNPAUSED:        self.onUnpaused,
            mods.MSG_NEW_TRACK:       self.onNewTrack,
                   }
        mods.Module.__init__(self, handlers)

    def onAppStarted(self):
        if not self.statusIcon:
            self.statusIcon = gtk.StatusIcon()
            self.statusIcon.connect('size-changed', self.__renderIcon)
            self.statusIcon.connect('popup-menu', self.onShowMenu)
            self.statusIcon.connect('activate',
                lambda i: prefs.Window.onIconify())
            self.statusIcon.set_tooltip(prefs.appExec.title())
        self.statusIcon.set_visible(True)

    def __renderIcon(self, statusIcon, size):
        statusIcon.set_from_icon_name(self.icons[int(self.playing)])

    def onAppQuit(self):
        self.statusIcon.set_visible(False)
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

    def onNewTrack(self, track):
        self.playing = True
        self.statusIcon.set_from_icon_name(self.icons[1])
        self.statusIcon.set_tooltip(track.getTitle())

    def onPaused(self):
        self.playing = False
        self.statusIcon.set_from_icon_name(self.icons[0])

    def onUnpaused(self):
        self.playing = True
        self.statusIcon.set_from_icon_name(self.icons[1])

    def onStopped(self):
        self.playing = False
        self.statusIcon.set_from_icon_name(self.icons[0])
        self.statusIcon.set_tooltip(prefs.appExec.title())

    def onShowMenu(self, widget, button, time):
        menu = gtk.Menu()

        #next = gtk.ImageMenuItem(gtk.STOCK_MEDIA_NEXT)
        #next.connect('activate', lambda btn: mods.postMsg(mods.CMD_NEXT))
        #menu.append(next)
        play = gtk.ImageMenuItem(gtk.STOCK_MEDIA_PLAY) \
            if not self.playing else gtk.ImageMenuItem(gtk.STOCK_MEDIA_PAUSE)
        play.connect('activate', lambda btn: mods.postMsg(mods.CMD_PLAY_PAUSE))
        menu.append(play)
        #prev = gtk.ImageMenuItem(gtk.STOCK_MEDIA_PREVIOUS)
        #prev.connect('activate', lambda btn: mods.postMsg(mods.CMD_PREVIOUS))
        #menu.append(prev)

        menu.append(gtk.SeparatorMenuItem())
        quit = gtk.ImageMenuItem(gtk.STOCK_QUIT)
        quit.connect('activate', lambda btn: prefs.Window.emit('delete-event',
            gtk.gdk.Event(gtk.gdk.DESTROY)))
        menu.append(quit)

        menu.show_all()
        menu.popup(None, None, None, 0, time)
