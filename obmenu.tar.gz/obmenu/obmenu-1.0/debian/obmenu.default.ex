# Defaults for obmenu initscript
# sourced by /etc/init.d/obmenu
# installed at /etc/default/obmenu by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
