?package(obmenu):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="obmenu" command="/usr/bin/obmenu"
